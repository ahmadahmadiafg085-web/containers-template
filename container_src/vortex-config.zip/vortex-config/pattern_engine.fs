// pattern_engine.fs

module Types =
    type Pattern =
        | Literal of string
        | Regex of string
        | Composite of Pattern list

    type Action =
        | Log of string
        | Alert of string
        | Custom of (string -> unit)

    type Rule = {
        Pattern: Pattern
        Action: Action
    }

module Parser =
    open Types

    let parsePattern (input:string) : Pattern =
        Literal(input)

    let parseRule (input:string) : Rule =
        {
            Pattern = parsePattern input
            Action = Log("Action not implemented")
        }

module Matcher =
    open Types

    let rec matchPattern (pattern: Pattern) (input: string) : bool =
        match pattern with
        | Literal s -> input.Contains(s)
        | Regex r -> System.Text.RegularExpressions.Regex.IsMatch(input, r)
        | Composite patterns -> patterns |> List.exists (fun p -> matchPattern p input)

    let matchRule (rule: Rule) (input: string) : bool =
        matchPattern rule.Pattern input

module Executor =
    open Types

    let execute (action: Action) (input:string) =
        match action with
        | Log msg -> printfn "LOG: %s - Input: %s" msg input
        | Alert msg -> printfn "ALERT: %s - Input: %s" msg input
        | Custom f -> f input

    let executeRule (rule: Rule) (input: string) =
        if Matcher.matchRule rule input then
            execute rule.Action input

module Engine =
    open Types
    open Executor

    let mutable rules : Rule list = []

    let addRule (rule: Rule) =
        rules <- rule :: rules

    let run (input: string) =
        rules |> List.iter (fun r -> executeRule r input)

module Utils =
    let loadRulesFromFile (filePath:string) : Types.Rule list =
        []

module TagsAndTasks =
    open System
    open Types

    type Tag = {
        Id: Guid
        Name: string
        Category: string
        Priority: int
        Description: string
    }

    type TaskStatus = Pending | Running | Completed | Failed

    type Task = {
        Id: Guid
        Title: string
        Description: string
        Status: TaskStatus
        CreatedAt: DateTime
        DueDate: DateTime option
        Assignee: string option
        RelatedTags: Tag list
    }

    let mutable Tags: Tag list = []
    let mutable Tasks: Task list = []

    let addTag (tag: Tag) = Tags <- tag :: Tags
    let addTask (task: Task) = Tasks <- task :: Tasks

    let findTagByName (name: string) =
        Tags |> List.tryFind (fun t -> t.Name = name)

    let updateTaskStatus (taskId: Guid) (newStatus: TaskStatus) =
        Tasks <- Tasks |> List.map (fun t -> if t.Id = taskId then { t with Status = newStatus } else t)

    let filterTasks (tagName: string option) (status: TaskStatus option) =
        Tasks |> List.filter (fun t ->
            let tagMatch = match tagName with Some n -> t.RelatedTags |> List.exists(fun tag -> tag.Name = n) | None -> true
            let statusMatch = match status with Some s -> t.Status = s | None -> true
            tagMatch && statusMatch)

    let initializeSampleData () =
        let tagSecurity = { Id = Guid.NewGuid(); Name = "Security"; Category = "Cyber"; Priority = 1; Description = "Related to cybersecurity tasks" }
        let tagAutomation = { Id = Guid.NewGuid(); Name = "Automation"; Category = "DevOps"; Priority = 2; Description = "Automation related" }
        let tagCompliance = { Id = Guid.NewGuid(); Name = "Compliance"; Category = "Legal"; Priority = 3; Description = "Regulatory and legal tasks" }
        addTag tagSecurity; addTag tagAutomation; addTag tagCompliance

        let task1 = {
            Id = Guid.NewGuid()
            Title = "Run penetration test on marketplace"
            Description = "Execute automated pen testing scenario version 3"
            Status = Pending
            CreatedAt = DateTime.UtcNow.AddDays(-1.0)
            DueDate = Some (DateTime.UtcNow.AddDays(3.0))
            Assignee = Some "Team Alpha"
            RelatedTags = [tagSecurity; tagAutomation]
        }

        let task2 = {
            Id = Guid.NewGuid()
            Title = "Verify compliance with GDPR"
            Description = "Audit marketplace user data protection compliance"
            Status = Running
            CreatedAt = DateTime.UtcNow.AddDays(-2.0)
            DueDate = None
            Assignee = Some "Legal Team"
            RelatedTags = [tagCompliance]
        }

        addTask task1
        addTask task2

    let runRulesForTasks input =
        filterTasks (Some "Security") (Some Pending)
        |> List.iter (fun task -> Engine.run ("Executing task: " + task.Title + " Input: " + input))

module Config =
    open Engine
    open TagsAndTasks

    let initialize () =
        let exampleRule = { Pattern = Types.Literal "test"; Action = Types.Log "Test pattern matched" }
        addRule exampleRule
        initializeSampleData ()

module Main =
    open Config
    open Engine

    [<EntryPoint>]
    let main argv =
        initialize()
        run "this is a test input"
        0

module Integration =
    open System.Diagnostics

    let callPython (scriptPath: string) (args: string) =
        let proc = new Process()
        proc.StartInfo.FileName <- "python"
        proc.StartInfo.Arguments <- sprintf "\"%s\" %s" scriptPath args
        proc.StartInfo.RedirectStandardOutput <- true
        proc.StartInfo.UseShellExecute <- false
        proc.Start()
        let output = proc.StandardOutput.ReadToEnd()
        proc.WaitForExit()
        output

    let callNodeJs (scriptPath: string) (args: string) =
        let proc = new Process()
        proc.StartInfo.FileName <- "node"
        proc.StartInfo.Arguments <- sprintf "\"%s\" %s" scriptPath args
        proc.StartInfo.RedirectStandardOutput <- true
        proc.StartInfo.UseShellExecute <- false
        proc.Start()
        let output = proc.StandardOutput.ReadToEnd()
        proc.WaitForExit()
        output

// ============================================================
// 🌐 VortexHub Pattern Engine -- Enhanced & Unified Edition
// Author: Dr. S. M. H. Sadat / VortexHub Labs
// Version: 2.0-UNIFIED-CYBER-AI
// Purpose: Universal pattern/rule execution layer linked with multi-language nodes
// Compatible with: Python, Node.js, Lisp, Rust (WASM)
// ============================================================

open System
open System.IO
open System.Diagnostics
open System.Threading.Tasks
open System.Text.RegularExpressions

// ============================================================
// MODULE: Types
// ============================================================
module Types =
    type Pattern =
        | Literal of string
        | Regex of string
        | Composite of Pattern list

    type Action =
        | Log of string
        | Alert of string
        | Custom of (string -> unit)
        | CrossCall of string * string  // <runtime> <path>

    type Rule = {
        Id: Guid
        Priority: int
        Pattern: Pattern
        Action: Action
        Description: string option
    }

// ============================================================
// MODULE: Parser
// ============================================================
module Parser =
    open Types

    let parsePattern (input: string) =
        if input.StartsWith("regex:") then
            Regex(input.Substring(6))
        else
            Literal input

    let parseRule (input: string) =
        {
            Id = Guid.NewGuid()
            Priority = 1
            Pattern = parsePattern input
            Action = Log "Auto-parsed rule executed"
            Description = Some "Generated dynamically"
        }

// ============================================================
// MODULE: Matcher
// ============================================================
module Matcher =
    open Types

    let rec matchPattern (pattern: Pattern) (input: string) : bool =
        match pattern with
        | Literal s -> input.Contains(s)
        | Regex r -> Regex.IsMatch(input, r)
        | Composite patterns -> patterns |> List.exists (fun p -> matchPattern p input)

// ============================================================
// MODULE: Executor
// ============================================================
module Executor =
    open Types

    let execute (action: Action) (input: string) =
        try
            match action with
            | Log msg -> printfn "[LOG] %s | Input: %s" msg input
            | Alert msg -> printfn "[ALERT] %s | Input: %s" msg input
            | Custom f -> f input
            | CrossCall (runtime, path) ->
                match runtime.ToLower() with
                | "python" ->
                    Integration.callPythonAsync(path, input) |> Async.Start
                | "node" ->
                    Integration.callNodeAsync(path, input) |> Async.Start
                | "lisp" ->
                    printfn "Lisp bridge placeholder → %s" path
                | "rust" ->
                    printfn "Rust WASM bridge placeholder → %s" path
                | _ -> printfn "Unknown runtime: %s" runtime
        with ex ->
            Diagnostics.logError $"Execution failed: {ex.Message}"

// ============================================================
// MODULE: Engine
// ============================================================
module Engine =
    open Types
    open Executor

    let mutable rules : Rule list = []

    let addRule (rule: Rule) =
        rules <- rule :: rules |> List.sortByDescending (fun r -> r.Priority)

    let run (input: string) =
        try
            rules |> List.iter (fun rule ->
                if Matcher.matchPattern rule.Pattern input then
                    execute rule.Action input)
        with ex ->
            Diagnostics.logError $"Engine error: {ex.Message}"

// ============================================================
// MODULE: Integration (Async Cross Runtime Bridge)
// ============================================================
and Integration =
    let private runProcessAsync (file: string, args: string) =
        async {
            let psi = new ProcessStartInfo()
            psi.FileName <- file
            psi.Arguments <- args
            psi.RedirectStandardOutput <- true
            psi.RedirectStandardError <- true
            psi.UseShellExecute <- false
            psi.CreateNoWindow <- true

            use proc = new Process()
            proc.StartInfo <- psi
            proc.Start() |> ignore
            let! output = proc.StandardOutput.ReadToEndAsync() |> Async.AwaitTask
            let! err = proc.StandardError.ReadToEndAsync() |> Async.AwaitTask
            proc.WaitForExit()
            if err <> "" then Diagnostics.logError err
            return output
        }

    let callPythonAsync (path: string, args: string) = runProcessAsync ("python", $"{path} {args}")
    let callNodeAsync (path: string, args: string) = runProcessAsync ("node", $"{path} {args}")

// ============================================================
// MODULE: Diagnostics (Logs, Errors, Telemetry Hooks)
// ============================================================
and Diagnostics =
    let mutable logs: string list = []

    let log (msg: string) =
        logs <- msg :: logs
        printfn "[Telemetry] %s" msg

    let logError (msg: string) =
        logs <- msg :: logs
        printfn "[Error] %s" msg
        File.AppendAllText("./logs/error.log", $"{DateTime.UtcNow}: {msg}\n")

// ============================================================
// MODULE: Registry (File & Module Index Map)
// ============================================================
and Registry =
    type FileMap = { Name: string; Path: string; Runtime: string }

    let files : FileMap list = [
        { Name = "Anomaly Detector"; Path = "./03_anomaly_detector.py"; Runtime = "python" }
        { Name = "Telemetry Core"; Path = "./04_vortex_telemetry.v01.py"; Runtime = "python" }
        { Name = "Auto Debugger"; Path = "./05_auto_debugger.v01.py"; Runtime = "python" }
        { Name = "Health Monitor"; Path = "./05_health_monitor.v01.js"; Runtime = "node" }
        { Name = "Meta Reasoner"; Path = "./03_meta_reasoner.lisp"; Runtime = "lisp" }
        { Name = "Secure Bridge"; Path = "./06_secure_bridge.rs.wasm"; Runtime = "rust" }
    ]

    let printRegistry () =
        files |> List.iter (fun f -> printfn "🔗 %s [%s] → %s" f.Name f.Runtime f.Path)

// ============================================================
// MODULE: Scheduler (Future Integration Placeholder)
// ============================================================
and Scheduler =
    open System.Threading

    let runInterval (intervalSec: int) (callback: unit -> unit) =
        let timer = new Timer((fun _ -> callback()), null, 0, intervalSec * 1000)
        printfn "[Scheduler] Interval every %ds initialized." intervalSec
        timer

// ============================================================
// MODULE: Config
// ============================================================
module Config =
    open Types
    open Engine

    let initialize () =
        Diagnostics.log "Initializing Pattern Engine..."
        Registry.printRegistry()

        addRule { Id = Guid.NewGuid(); Priority = 5; Pattern = Literal "test"; Action = Log "Pattern matched ✅"; Description = Some "Default test rule" }
        addRule { Id = Guid.NewGuid(); Priority = 9; Pattern = Regex "error|failed"; Action = Alert "⚠️ System anomaly detected"; Description = Some "Error alert" }
        addRule { Id = Guid.NewGuid(); Priority = 10; Pattern = Literal "telemetry"; Action = CrossCall ("python", "./04_vortex_telemetry.v01.py"); Description = Some "Telemetry sync trigger" }

        Diagnostics.log "Rules loaded successfully."

// ============================================================
// MODULE: Main
// ============================================================
module Main =
    open Config
    open Engine

    [<EntryPoint>]
    let main argv =
        initialize()
        Diagnostics.log "Running unified engine..."
        run "test input with telemetry"
        0
        
// Types
module Types =
    type Pattern =
        | Literal of string
        | Regex of string
        | Composite of Pattern list
    
    type Action =
        | Log of string
        | Alert of string
        | Custom of (string -> unit)
        | CrossCall of string * string  // runtime * script path
    
    type Rule = {
        Id: System.Guid
        Priority: int
        Pattern: Pattern
        Action: Action
        Description: string option
    }

// Matcher
module Matcher =
    open System.Text.RegularExpressions
    let rec matchPattern pattern input =
        match pattern with
        | Literal s -> input.Contains s
        | Regex r -> Regex.IsMatch(input, r)
        | Composite ps -> ps |> List.exists (fun p -> matchPattern p input)

// Executor
module Executor =
    open System.Diagnostics
    let execute action input =
        match action with
        | Log msg -> printfn "[LOG] %s | Input: %s" msg input
        | Alert msg -> printfn "[ALERT] %s | Input: %s" msg input
        | Custom f -> f input
        | CrossCall (rt, path) ->
            let psi = new ProcessStartInfo()
            psi.FileName <- rt
            psi.Arguments <- path + " " + input
            psi.RedirectStandardOutput <- true
            psi.UseShellExecute <- false
            psi.CreateNoWindow <- true
            use proc = new Process()
            proc.StartInfo <- psi
            proc.Start() |> ignore
            let! output = proc.StandardOutput.ReadToEndAsync() |> Async.AwaitTask
            printfn "[CrossCall output] %s" output

// Engine
module Engine =
    let mutable rules = []
    let addRule r = rules <- r :: rules |> List.sortByDescending (fun x -> x.Priority)
    let run input =
        rules |> List.iter (fun r ->
            if Matcher.matchPattern r.Pattern input then
                Executor.execute r.Action input
        )

// نمونه قاعده و اجرا
let rule1 = {
    Id = System.Guid.NewGuid()
    Priority = 10
    Pattern = Types.Literal "telemetry"
    Action = Types.CrossCall("python", "./telemetry.py")
    Description = Some "Trigger telemetry sync"
}

Engine.addRule rule1
Engine.run "incoming telemetry data"


