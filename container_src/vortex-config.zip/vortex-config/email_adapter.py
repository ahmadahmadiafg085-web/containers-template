import smtplib, asyncio, logging, datetime, traceback, time, random
from typing import Dict, List, Callable, Any, Optional
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from adapters.adapter_internal_to_admin import DistributedInternalToAdminAdapter
from orchestrator.orchestrator_adapter import AdapterOrchestratorToAdmin
from loader.loader_adapter import LoaderToAdminAdapter

# -————— CONFIG -—————
class EmailAdapterConfig:
    def __init__(self,smtp_server:str,smtp_port:int,username:str,password:str,use_tls:bool=True,
                 default_sender:Optional[str]=None,allowed_recipients:Optional[List[str]]=None,
                 max_retries:int=3,retry_delay:int=2,enable_metrics:bool=True,
                 enable_context_tracking:bool=True,enable_html_emails:bool=True,
                 enable_dag_execution:bool=True,enable_bulk_send:bool=True,
                 enable_template_support:bool=True,enable_interactive_feedback:bool=True,
                 enable_scheduled_tasks:bool=True,enable_admin_dashboard:bool=True):
        self.smtp_server=smtp_server
        self.smtp_port=smtp_port
        self.username=username
        self.password=password
        self.use_tls=use_tls
        self.default_sender=default_sender or username
        self.allowed_recipients=allowed_recipients or []
        self.max_retries=max_retries
        self.retry_delay=retry_delay
        self.enable_metrics=enable_metrics
        self.enable_context_tracking=enable_context_tracking
        self.enable_html_emails=enable_html_emails
        self.enable_dag_execution=enable_dag_execution
        self.enable_bulk_send=enable_bulk_send
        self.enable_template_support=enable_template_support
        self.enable_interactive_feedback=enable_interactive_feedback
        self.enable_scheduled_tasks=enable_scheduled_tasks
        self.enable_admin_dashboard=enable_admin_dashboard

# -————— ADAPTER -—————
class EmailAdapter:
    def __init__(self,config:EmailAdapterConfig,backend_execute:Callable,
                 loader_adapter:LoaderToAdminAdapter,internal_adapter:DistributedInternalToAdminAdapter,
                 orchestrator_adapter:AdapterOrchestratorToAdmin):
        self.config=config
        self.backend_execute=backend_execute
        self.loader_adapter=loader_adapter
        self.internal_adapter=internal_adapter
        self.orchestrator_adapter=orchestrator_adapter
        self.logger=logging.getLogger(“EmailAdapter”)
        logging.basicConfig(level=logging.INFO)
        self.module_states:Dict[str,str]={}
        self.module_dependencies:Dict[str,List[str]]={}
        self.execution_history:Dict[str,List[Dict[str,Any]]]={}
        self.retry_counts:Dict[str,int]={}
        self._executing_modules:Dict[str,asyncio.Lock]={}
        self.message_context:Dict[str,List[str]]={}
        self.metrics:Dict[str,List[float]]={}
        self._scheduled_task:Optional[asyncio.Task]=None

    # -——— Context -———
    def add_message_context(self,recipient:str,content:str):
        if not self.config.enable_context_tracking:return
        self.message_context.setdefault(recipient,[]).append(content)
        self.message_context[recipient]=self.message_context[recipient][-50:]

    # -——— Send Email -———
    async def send_email(self,to:str,subject:str,body:str,html:bool=False):
        if self.config.allowed_recipients and to not in self.config.allowed_recipients:
            self.logger.warning(f”Recipient {to} not allowed”);return False
        msg=MIMEMultipart();msg[‘From’]=self.config.default_sender;msg[‘To’]=to;msg[‘Subject’]=subject
        msg.attach(MIMEText(body,’html’ if html and self.config.enable_html_emails else ‘plain’))
        retries=0
        while retries<=self.config.max_retries:
            try:
                server=smtplib.SMTP(self.config.smtp_server,self.config.smtp_port)
                if self.config.use_tls:server.starttls()
                server.login(self.config.username,self.config.password)
                server.sendmail(self.config.default_sender,to,msg.as_string())
                server.quit()
                self.logger.info(f”Email sent to {to}”)
                self.add_message_context(to,body)
                if self.config.enable_metrics:self.metrics.setdefault(“send_email”,[]).append(time.time())
                return True
            except Exception as e:
                retries+=1;self.retry_counts[to]=retries
                self.logger.error(f”Failed to send email to {to} attempt {retries}: {e}”);traceback.print_exc()
                if retries>self.config.max_retries:return False
                await asyncio.sleep(self.config.retry_delay)

    async def send_bulk_email(self,recipients:List[str],subject:str,body:str,html:bool=False):
        if not self.config.enable_bulk_send:self.logger.warning(“Bulk send disabled”);return
        for r in recipients:await self.send_email(r,subject,body,html)

    # -——— Module Execution -———
    async def execute_module_safe(self,module_name:str,args:List[str]):
        if module_name not in self._executing_modules:self._executing_modules[module_name]=asyncio.Lock()
        async with self._executing_modules[module_name]:
            for d in self.module_dependencies.get(module_name,[]):await self.execute_module_safe(d,[])
            retries=0
            while retries<=self.config.max_retries:
                try:
                    self.module_states[module_name]=“running”
                    await self.backend_execute(“email”,module_name,[“—pre-hook”]+args)
                    await self.backend_execute(“email”,module_name,args)
                    await self.backend_execute(“email”,module_name,[“—post-hook”]+args)
                    self.module_states[module_name]=“completed”
                    record={“timestamp”:datetime.datetime.utcnow().isoformat(),”args”:args,”status”:”completed”}
                    self.execution_history.setdefault(module_name,[]).append(record)
                    await self.internal_adapter.record_execution(module_name,record)
                    return
                except Exception as e:
                    retries+=1;self.retry_counts[module_name]=retries
                    self.module_states[module_name]=“failed”
                    record={“timestamp”:datetime.datetime.utcnow().isoformat(),”args”:args,”status”:”failed”,”error”:str(e)}
                    self.execution_history.setdefault(module_name,[]).append(record)
                    self.logger.error(f”[EmailAdapter] Module {module_name} failed attempt {retries}: {e}”);traceback.print_exc()
                    if retries>self.config.max_retries:return
                    await asyncio.sleep(self.config.retry_delay)

    # -——— Hot Reload / Dry Run -———
    async def hot_reload_module(self,module_name:str):
        try:await self.backend_execute(“email”,module_name,[“—reload”]);self.logger.info(f”[EmailAdapter] Module {module_name} hot reloaded”)
        except Exception as e:self.logger.error(f”[EmailAdapter] Hot reload failed for {module_name}: {e}”);traceback.print_exc()

    async def dry_run_module(self,module_name:str):
        try:await self.backend_execute(“email”,module_name,[“—dry-run”])
        except Exception as e:self.logger.error(f”[EmailAdapter] Dry run failed for {module_name}: {e}”);traceback.print_exc()

    # -——— Scheduled Modules -———
    async def run_scheduled_modules(self):
        if not self.config.enable_scheduled_tasks:return
        while True:
            for module_name,state in self.module_states.items():
                if state==“scheduled”:await self.execute_module_safe(module_name,[])
            await asyncio.sleep(60)

# -——— Factory -———
def create_email_adapter(config:EmailAdapterConfig,backend_execute:Callable,
                         loader_adapter:LoaderToAdminAdapter,internal_adapter:DistributedInternalToAdminAdapter,
                         orchestrator_adapter:AdapterOrchestratorToAdmin):
    adapter=EmailAdapter(config,backend_execute,loader_adapter,internal_adapter,orchestrator_adapter)
    if config.enable_scheduled_tasks:adapter._scheduled_task=asyncio.create_task(adapter.run_scheduled_modules())
    return adapter
    