#!/bin/bash
# ============================================================
# VORTEXHUB UNIVERSAL ORCHESTRATOR v0.5-HYBRID-FUSION
# Core: v0.4 + Meta-Fusion Intelligence Layer
# Author: Dr. S.M.H. Sadat / VortexHub Labs
# ============================================================
set -euo pipefail;IFS=$'\n\t'
HYBRID_CONTEXT_VERSION="2025-FUSION-RESILIENCE";HYBRID_INTELLIGENCE_TAGS=("sandbox" "browser_agent_bridge" "cdnsync" "lifeguard_relay" "r2_selfheal" "meta_attestation")
ANTI_REVERSE_POLICY(){grep -qi "vbox\|vmware\|qemu" /proc/cpuinfo 2>/dev/null&&{echo"[DEFENSE]Virtualization detected→adaptive lock engaged.";sleep2;exit133;};}
obfuscate_paths(){export VX_TASK_DIR_HASH=$(echo -n "$TASK_DIR"|sha256sum|cut -c1-8);export VX_LOG_HASH=$(echo -n "$LOG_FILE"|sha256sum|cut -c1-6);export VX_MANIFEST_SEED=$(date +%s|sha1sum|cut -c1-10);log"[OBFUSCATION]Path entropy seeds→$VX_TASK_DIR_HASH $VX_MANIFEST_SEED";}
browser_bridge(){local port="${BRIDGE_PORT:-8730}";local endpoint="http://127.0.0.1:${port}/ping";if curl -s --max-time 1 "$endpoint"|grep -q "pong";then log"[BRIDGE]Browser-Agent active on $port";else log"[BRIDGE]No active local bridge.";fi;}
meta_autorescue(){local f="$CLOUD_ENDPOINT/fallback/$(hostname)";curl -fs -X POST -d '{"node":"'"$(hostname)"'"}' "$f" >/dev/null 2>&1||log"[RESCUE]offline recovery waiting(manifest_cache)";}
quantum_shield(){[ -f "$ECDSA_PRIV" ]&&{openssl rand -hex 32|openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$(hostname)">/tmp/qshield.key;log"[QSHIELD]Quantum-safe ephemeral key(RAM-only)";};}
CONFIG_PATH="/etc/vortexhub/config.json";TASK_DIR="/var/vortexhub/tasks";LOG_FILE="/var/log/vortexhub_scheduler.log";LOCK_FILE="/tmp/vortexhub_scheduler.lock";MAX_PARALLEL_TASKS=4;META_REASONER_URL="https://api.vortexhub.app/meta_reasoner";LIFEGUARD_URL="https://api.vortexhub.app/lifeguard/ping";WRAPPER_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.py";WRAPPER_REGISTRY_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.js";TELEMETRY_URL="https://api.vortexhub.app/telemetry/scheduler";TAG_REGISTRY="/etc/vortexhub/tag_registry.json";MANIFEST_GLOBAL="/etc/vortexhub/manifest_global.yml";CLIENT_MANIFEST_DIR="/etc/vortexhub/client_manifests";OFFLINE_MODE=false;CLOUD_ENDPOINT="${CLOUD_ENDPOINT:-https://r2.cloudflare.com}";CLOUD_BUCKET="${CLOUD_BUCKET:-vortex-drone-bucket}";RCLONE_REMOTE="${RCLONE_REMOTE:-remote:drone-bucket}";ECDSA_PUB="/etc/vortexhub/keys/device_pub.pem";ECDSA_PRIV="/etc/vortexhub/keys/device_priv.pem";USE_ECDSA=true;WS_MONITOR_URL="${WS_MONITOR_URL:-}"
log(){echo"[$(date -u +"%Y-%m-%dT%H:%M:%SZ")]$*";}
AI_AUTOFILL=true;AI_BEHAVIOR_MODE="sandbox_forced_safe";AI_CONFIDENCE_THRESHOLD="0.9";AI_SELF_VERIFY=true;AI_REVIEW_REQUIRED=true;AI_CONTEXT="Autonomous AI-driven scheduler reasoning";AI_MEMORY_PATH="/etc/vortexhub/ai_memory/vortex_feedback.json";AI_REGION_POLICY="dynamic";AI_TASK_TYPES=("AI" "Hardware" "Network" "Logic" "SQL" "API" "Encryption" "Firmware")
detect_task_type(){local tag="$1";case"$tag"in*AI_*)echo"AI";;*HW_*|*HARDWARE*)echo"Hardware";;*NET_*)echo"Network";;*SQL_*)echo"SQL";;*ENC_*|*CRYPTO*)echo"Encryption";;*API_*)echo"API";;*LOGIC_*)echo"Logic";;*)echo"General";;esac;}
sandbox_detect(){grep -qi"Virtual"/proc/cpuinfo 2>/dev/null&&{log"[⚠️]Sandbox detected.Safe mode.";export SANDBOX_DETECTED=true;}||SANDBOX_DETECTED=false;}
sandbox_override(){[["${SANDBOX_OVERRIDE:-0}"=="1"]]&&log"[⚙️]Sandbox override active."||{[["$SANDBOX_DETECTED"==true]]&&log"[SAFE]Restricted IO,encrypted logs,limited net.";};}
AI_MODULES=("PolicyFusionLayer" "EncryptedCapsule" "DynamicTagOverlays" "AIBehaviorDNA" "PredictiveLoader" "SelfSignatureEnforcer" "RegionAwareMirror" "IntegrityBeacon" "WrapperAutonomousPatch" "AIRepairNetwork" "BehaviorThrottler" "LegalScopeController" "AdaptiveEncryption" "AI_OfflineResilience" "DynamicCommandWhitelist" "TemporalRollback" "MultiAI_Strategy" "AutoManifestFusion" "CustomPersonaEngine" "FeedbackEncryptor");for m in"${AI_MODULES[@]}";do log"[AI-MODULE]$m";done
check_environment(){log"Checking environment...";for c in jq curl timeout bash awk sort head ping openssl rclone;do command -v"$c">/dev/null2>&1||log"[WARN]Missing:$c";done;mkdir -p"$TASK_DIR""$CLIENT_MANIFEST_DIR""/etc/vortexhub/keys";touch"$LOG_FILE";init_registry;log"Environment ready.";}
init_registry(){log"Init Tag Registry...";[ ! -f "$TAG_REGISTRY" ]&&{log"[WARN]Registry missing;fetching...";curl -s -L "$META_REASONER_URL/registry" -o "$TAG_REGISTRY";};[ -s "$TAG_REGISTRY" ]&&log"[OK]Tags:$(jq 'keys|length' "$TAG_REGISTRY"2>/dev/null)"||log"[ERR]No registry.";}
load_manifests(){log"Load manifests...";local TMP="/tmp/manifest_$(date +%s).json";for s in"https://cdn.vortexhub.app/tasks/manifest.json""https://render.vortexhub.app/backup/manifest.json""/var/vortexhub/local_manifest.json";do log"Try$s";curl -s -L"$s"-o"$TMP"&&[ -s "$TMP" ]&&break;done;[ ! -s "$TMP" ]&&{log"[ERR]Manifest load fail";return1;};jq -r'.tasks[]|.id+" "+.priority+" "+.script_url+" "+(.signature//"")'"$TMP">/tmp/task_list.txt;log"Manifest:$(wc -l</tmp/task_list.txt)tasks.";}
verify_signature(){local M="$1"S="$2";[ "$USE_ECDSA"!=true ]&&return0;[ ! -f "$ECDSA_PUB" ]&&{log"[WARN]ECDSA pub missing";return1;};jq -c -S."$M">/tmp/payload.json;echo"$S"|base64-d>/tmp/sig.bin2>/dev/null;openssl dgst -verify"$ECDSA_PUB"-sha256-signature/tmp/sig.bin/tmp/payload.json>/dev/null2>&1;}
select_task(){log"Select task...";local F;F=$(curl -s"$META_REASONER_URL?node=$(hostname)"|jq -r'.recommendation.priority_boost//0'2>/dev/null||echo0);awk -v b="$F"'{print$1,$2-b,$3,$4}'/tmp/task_list.txt|sort-k2-n|head-1;}
run_task(){local ID="$1"U="$2"SIGN="$3"TMP="/tmp/${ID}.sh"MAN="/tmp/${ID}_manifest.json";log"[TASK:$ID]DL&Run";curl -s -L"$U"-o"$TMP"||{log"[ERR]DLfail";return1;};chmod+x"$TMP";if[ -n "$SIGN" ]&&[ -f "$ECDSA_PUB" ];then local MU="${U}.manifest.json";curl -s -L"$MU"-o"$MAN";[ -s "$MAN" ]&&verify_signature"$MAN""$SIGN"||log"[WARN]Sig unver.";fi;timeout300bash"$TMP">>"$LOG_FILE"2>&1||true;local ST=$?TS=$(date -u+"%Y-%m-%dT%H:%M:%SZ");if[ $ST -eq 0 ];then jq -n--arg id"$ID"--arg ts"$TS"'{"id":$id,"status":"success","timestamp":$ts}'|curl -s -X POST -H"Content-Type:application/json"-d@-"$TELEMETRY_URL";else echo"$ID">>/tmp/retry_queue.txt;jq -n--arg id"$ID"--arg ts"$TS"--arg err"$ST"'{"id":$id,"status":"failed","code":$err,"timestamp":$ts}'|curl -s -X POST -H"Content-Type:application/json"-d@-"$LIFEGUARD_URL";fi;}
wrapper_invoke(){local M=$1;if[ -x "$WRAPPER_HOOK" ];then python3"$WRAPPER_HOOK"--mode="$M"--registry="$TAG_REGISTRY"--manifest="$MANIFEST_GLOBAL"--telemetry="$TELEMETRY_URL";elif[ -f "$WRAPPER_REGISTRY_HOOK" ];then node"$WRAPPER_REGISTRY_HOOK""$M""$TAG_REGISTRY";fi;}
registry_feedback(){jq -n--arg n"$(hostname)"--arg t"$(jq 'keys|length' "$TAG_REGISTRY"2>/dev/null||echo0)"--arg ts"$(date -u+"%Y-%m-%dT%H:%M:%SZ")"'{"node":$n,"registered_tags":($t|tonumber),"timestamp":$ts}'|curl -s -X POST -H"Content-Type:application/json"-d@-"$TELEMETRY_URL/registry";}
self_heal(){[ -s /tmp/retry_queue.txt ]&&while read -r ID;do URL=$(grep"$ID"/tmp/task_list.txt|awk'{print$3}');[ -n "$URL" ]&&run_task"$ID""$URL";done</tmp/retry_queue.txt;> /tmp/retry_queue.txt;wrapper_invoke"heal";registry_feedback;}
ai_feedback(){jq -n--arg n"$(hostname)"--arg s"active"--argjson u"$(awk '{print int($1)}'/proc/uptime2>/dev/null||echo0)"'{"node":$n,"status":$s,"uptime":$u,"timestamp":(now|todate)}'|curl -s -X POST -H"Content-Type:application/json"-d@-"$META_REASONER_URL/feedback";}
checkpoint(){echo"$(date)|Tasks:$(wc -l</tmp/task_list.txt2>/dev/null)">>/var/log/vortexhub_checkpoint.log;cp/tmp/task_list.txt/var/vortexhub/last_task_snapshot.txt2>/dev/null||true;}
network_resilience(){ping -c1 api.vortexhub.app>/dev/null2>&1||OFFLINE_MODE=true;}
upload_chunk(){local P="$1"R="$2";if command -v rclone>/dev/null2>&1;then log"[UPLOAD]$P->$RCLONE_REMOTE/$R";rclone copyto"$P""$RCLONE_REMOTE/$R"--transfers=4--checkers=8--s3-chunk-size=64M;return$?;fi;[ -n "$PRESIGNED_UPLOAD_URL" ]&&curl -s -X PUT -T"$P""$PRESIGNED_UPLOAD_URL"&&return0;log"[WARN]No upload";return2;}
ws_send_telemetry(){local p="$1";if command -v websocat>/dev/null2>&1&&[ -n "$WS_MONITOR_URL" ];then echo"$p"|websocat -1"$WS_MONITOR_URL">/dev/null2>&1;else echo"$p"|curl -s -X POST -H"Content-Type:application/json"-d@-"$TELEMETRY_URL/stream">/dev/null2>&1;fi;}
start_local_monitor(){[ -f /home/pi/vortex/monitor/monitor.py ]&&(cd/home/pi/vortex/monitor&&nohup python3 monitor.py>/var/log/vortex_local_monitor.log2>&1&);}
main_loop(){log"[SCHEDULER]Start loop...";local i=0;while true;do((i++));log"----Loop#$i----";network_resilience;load_manifests||{log"[ERR]Manifest fail";sleep120;continue;};local T ID U S;T=$(select_task);ID=$(echo"$T"|awk'{print$1}');U=$(echo"$T"|awk'{print$3}');S=$(echo"$T"|awk'{print$4}');[ -n "$ID" ]&&run_task"$ID""$U""$S";self_heal;ai_feedback;checkpoint;log"[LOOP]Sleep60s";sleep60;done;}
post_loop_intelligence(){local u=$(awk '{print int($1)}'/proc/uptime2>/dev/null||echo0);local m=$(jq -n--arg host"$(hostname)"--argjson up"$u"'{"node":$host,"uptime":$up,"entropy":"'${VX_MANIFEST_SEED}'"}');ws_send_telemetry"$m";log"[META]Hybrid snapshot sent.";}
startup(){[ -f "$LOCK_FILE" ]&&{log"[WARN]Already running.";exit0;};echo$$>"$LOCK_FILE";trap'rm -f"$LOCK_FILE";log"Lock removed";post_loop_intelligence'EXIT;sandbox_detect;sandbox_override;check_environment;start_local_monitor;main_loop;}
ANTI_REVERSE_POLICY;obfuscate_paths;browser_bridge;quantum_shield;startup
# ============================================================
# END OF UNIVERSAL ORCHESTRATOR v0.5-HYBRID-FUSION [MINIFIED]
# ============================================================


#!/bin/bash
# ============================================================
#  VORTEXHUB TASK SCHEDULER v0.2-FUSION (CLEAN + DEPLOY READY)
#  Author: Dr. S.M.H. Sadat / VortexHub Labs
#  Purpose: AI-aware, self-healing, multi-tenant task orchestrator
#  Extensions: Meta-Reasoner + LifeGuard + Tag Registry + Telemetry
# ============================================================

# ---------- CORE CONFIGURATION ----------
CONFIG_PATH="/etc/vortexhub/config.json"
TASK_DIR="/var/vortexhub/tasks"
LOG_FILE="/var/log/vortexhub_scheduler.log"
LOCK_FILE="/tmp/vortexhub_scheduler.lock"
MAX_PARALLEL_TASKS=4
META_REASONER_URL="https://api.vortexhub.app/meta_reasoner"
LIFEGUARD_URL="https://api.vortexhub.app/lifeguard/ping"
WRAPPER_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.py"
WRAPPER_REGISTRY_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.js"
TELEMETRY_URL="https://api.vortexhub.app/telemetry/scheduler"
TAG_REGISTRY="/etc/vortexhub/tag_registry.json"
MANIFEST_GLOBAL="/etc/vortexhub/manifest_global.yml"
CLIENT_MANIFEST_DIR="/etc/vortexhub/client_manifests"

# ---------- ENVIRONMENT VALIDATION ----------
check_environment() {
  echo "[INFO] Checking environment..."
  for cmd in jq curl timeout bash awk sort head ping; do
    command -v "$cmd" >/dev/null 2>&1 || { echo "[ERROR] Missing dependency: $cmd"; exit 1; }
  done
  mkdir -p "$TASK_DIR" "$CLIENT_MANIFEST_DIR"
  touch "$LOG_FILE"
  init_registry
  echo "[INFO] Environment ready. $(date)" >>"$LOG_FILE"
}

# ---------- TAG REGISTRY INITIALIZATION ----------
init_registry() {
  echo "[INFO] Initializing Tag Registry..."
  if [ ! -f "$TAG_REGISTRY" ]; then
    echo "[WARN] Registry missing; requesting from Meta-Reasoner..."
    curl -s -L "$META_REASONER_URL/registry" -o "$TAG_REGISTRY"
  fi
  if [ -s "$TAG_REGISTRY" ]; then
    echo "[OK] Registry ready. Tags: $(jq 'keys|length' "$TAG_REGISTRY")"
  else
    echo "[ERROR] Tag Registry unavailable." >>"$LOG_FILE"
  fi
}

# ---------- LOAD MANIFESTS ----------
load_manifests() {
  echo "[INFO] Loading task manifests..."
  local TMP="/tmp/manifest_$(date +%s).json"
  for src in \
    "https://cdn.vortexhub.app/tasks/manifest.json" \
    "https://render.vortexhub.app/backup/manifest.json" \
    "/var/vortexhub/local_manifest.json"; do
    echo "[INFO] Trying $src ..."
    curl -s -L "$src" -o "$TMP" && [ -s "$TMP" ] && break
  done
  [ ! -s "$TMP" ] && { echo "[ERROR] Manifest load failed"; return 1; }
  jq -r '.tasks[] | .id + " " + .priority + " " + .script_url' "$TMP" >/tmp/task_list.txt
  echo "[INFO] Manifest loaded: $(wc -l < /tmp/task_list.txt) tasks."
}

# ---------- TASK SELECTION (AI-Aware) ----------
select_task() {
  echo "[INFO] Selecting next task..."
  local FEEDBACK=$(curl -s "$META_REASONER_URL?node=$(hostname)" | jq -r '.recommendation.priority_boost // 0')
  awk -v boost="$FEEDBACK" '{print $1, $2 - boost, $3}' /tmp/task_list.txt | sort -k2 -n | head -1
}

# ---------- EXECUTION WRAPPER ----------
run_task() {
  local ID="$1" URL="$2" TMP="/tmp/${ID}.sh"
  echo "[TASK:$ID] Downloading & executing..."
  curl -s -L "$URL" -o "$TMP" && chmod +x "$TMP"
  timeout 300 bash "$TMP" >>"$LOG_FILE" 2>&1
  local STATUS=$? TS
  TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  if [ $STATUS -eq 0 ]; then
    echo "[OK] Task $ID done."
    jq -n --arg id "$ID" --arg ts "$TS" '{id:$id,status:"success",timestamp:$ts}' \
      | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL"
  else
    echo "[WARN] Task $ID failed ($STATUS)."
    echo "$ID" >>/tmp/retry_queue.txt
    jq -n --arg id "$ID" --arg ts "$TS" --arg err "$STATUS" \
      '{id:$id,status:"failed",code:$err,timestamp:$ts}' \
      | curl -s -X POST -H "Content-Type: application/json" -d @- "$LIFEGUARD_URL"
  fi
}

# ---------- WRAPPER INVOCATION ----------
wrapper_invoke() {
  local MODE=$1
  echo "[INFO] Invoking Vortex Wrapper ($MODE)..."
  if [ -x "$WRAPPER_HOOK" ]; then
    python3 "$WRAPPER_HOOK" --mode="$MODE" --registry="$TAG_REGISTRY" \
      --manifest="$MANIFEST_GLOBAL" --telemetry="$TELEMETRY_URL"
  elif [ -f "$WRAPPER_REGISTRY_HOOK" ]; then
    node "$WRAPPER_REGISTRY_HOOK" "$MODE" "$TAG_REGISTRY"
  else
    echo "[WARN] No Wrapper executable found." >>"$LOG_FILE"
  fi
}

# ---------- REGISTRY TELEMETRY ----------
registry_feedback() {
  jq -n --arg node "$(hostname)" \
    --arg tags "$(jq 'keys|length' "$TAG_REGISTRY")" \
    --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    '{node:$node,registered_tags:($tags|tonumber),timestamp:$ts}' \
    | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL/registry"
}

# ---------- SELF-HEAL ----------
self_heal() {
  echo "[INFO] Running self-heal..."
  if [ -s /tmp/retry_queue.txt ]; then
    echo "[INFO] Retrying failed tasks..."
    while read -r ID; do
      URL=$(grep "$ID" /tmp/task_list.txt | awk '{print $3}')
      [ -n "$URL" ] && run_task "$ID" "$URL"
    done </tmp/retry_queue.txt
    > /tmp/retry_queue.txt
  fi
  wrapper_invoke "heal"
  registry_feedback
}

# ---------- AI FEEDBACK ----------
ai_feedback() {
  jq -n --arg node "$(hostname)" \
    --arg status "active" \
    --argjson uptime "$(awk '{print int($1)}' /proc/uptime)" \
    '{node:$node,status:$status,uptime:$uptime,timestamp:now|todate}' \
    | curl -s -X POST -H "Content-Type: application/json" -d @- "$META_REASONER_URL/feedback"
}

# ---------- CHECKPOINT ----------
checkpoint() {
  echo "[INFO] Creating checkpoint..."
  echo "$(date) | Tasks run: $(wc -l < /tmp/task_list.txt)" >>/var/log/vortexhub_checkpoint.log
  cp /tmp/task_list.txt /var/vortexhub/last_task_snapshot.txt 2>/dev/null
}

# ---------- NETWORK RESILIENCE ----------
network_resilience() {
  echo "[INFO] Checking network..."
  ping -c1 api.vortexhub.app >/dev/null 2>&1 || {
    echo "[WARN] Network down, switching offline..."
    OFFLINE_MODE=true
  }
}

# ---------- MAIN LOOP ----------
main_loop() {
  echo "[SCHEDULER] Starting orchestrator loop..."
  local iteration=0
  while true; do
    ((iteration++))
    echo "-------- Loop #$iteration --------"
    network_resilience
    load_manifests || { echo "[ERROR] Manifest not loaded."; sleep 120; continue; }
    local TASK_INFO ID URL
    TASK_INFO=$(select_task)
    ID=$(echo "$TASK_INFO" | awk '{print $1}')
    URL=$(echo "$TASK_INFO" | awk '{print $3}')
    [ -n "$ID" ] && run_task "$ID" "$URL"
    self_heal
    ai_feedback
    checkpoint
    echo "[LOOP] Sleep 60s..."
    sleep 60
  done
}

# ---------- STARTUP ----------
startup() {
  if [ -f "$LOCK_FILE" ]; then
    echo "[WARN] Scheduler already running."
    exit 0
  fi
  echo $$ >"$LOCK_FILE"
  trap 'rm -f "$LOCK_FILE"' EXIT
  check_environment
  main_loop
}

# ---------- EXECUTE ----------
startup
# ============================================================
# END OF VORTEXHUB TASK SCHEDULER v0.2-FUSION (CLEAN BUILD)
# ============================================================

#!/bin/bash
# ============================================================
#  VORTEXHUB TASK SCHEDULER v0.2-FUSION (EXTENDED CLEAN BUILD)
#  Author: Dr. S.M.H. Sadat / VortexHub Labs
#  Purpose: AI-aware, self-healing, multi-tenant task orchestrator
#  Extensions: Meta-Reasoner + LifeGuard + Tag Registry + Telemetry + ECDSA + Upload + WS + Local-Monitor
# ============================================================

# ---------- CORE CONFIGURATION ----------
CONFIG_PATH="/etc/vortexhub/config.json"
TASK_DIR="/var/vortexhub/tasks"
LOG_FILE="/var/log/vortexhub_scheduler.log"
LOCK_FILE="/tmp/vortexhub_scheduler.lock"
MAX_PARALLEL_TASKS=4
META_REASONER_URL="https://api.vortexhub.app/meta_reasoner"
LIFEGUARD_URL="https://api.vortexhub.app/lifeguard/ping"
WRAPPER_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.py"
WRAPPER_REGISTRY_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.js"
TELEMETRY_URL="https://api.vortexhub.app/telemetry/scheduler"
TAG_REGISTRY="/etc/vortexhub/tag_registry.json"
MANIFEST_GLOBAL="/etc/vortexhub/manifest_global.yml"
CLIENT_MANIFEST_DIR="/etc/vortexhub/client_manifests"
OFFLINE_MODE=false

# ---------- EXTENSION CONFIG ----------
CLOUD_ENDPOINT="${CLOUD_ENDPOINT:-https://r2.cloudflare.com}"
CLOUD_BUCKET="${CLOUD_BUCKET:-vortex-drone-bucket}"
RCLONE_REMOTE="${RCLONE_REMOTE:-remote:drone-bucket}"
ECDSA_PUB="/etc/vortexhub/keys/device_pub.pem"
ECDSA_PRIV="/etc/vortexhub/keys/device_priv.pem"
USE_ECDSA=true
WS_MONITOR_URL="${WS_MONITOR_URL:-}"

# ---------- ENVIRONMENT VALIDATION ----------
check_environment() {
  echo "[INFO] Checking environment..."
  for cmd in jq curl timeout bash awk sort head ping openssl rclone; do
    command -v "$cmd" >/dev/null 2>&1 || echo "[WARN] Missing dependency: $cmd"
  done
  mkdir -p "$TASK_DIR" "$CLIENT_MANIFEST_DIR" "/etc/vortexhub/keys"
  touch "$LOG_FILE"
  init_registry
  echo "[INFO] Environment ready. $(date)" >>"$LOG_FILE"
}

# ---------- TAG REGISTRY ----------
init_registry() {
  echo "[INFO] Initializing Tag Registry..."
  if [ ! -f "$TAG_REGISTRY" ]; then
    echo "[WARN] Registry missing; requesting from Meta-Reasoner..."
    curl -s -L "$META_REASONER_URL/registry" -o "$TAG_REGISTRY"
  fi
  if [ -s "$TAG_REGISTRY" ]; then
    echo "[OK] Registry ready. Tags: $(jq 'keys|length' "$TAG_REGISTRY" 2>/dev/null)"
  else
    echo "[ERROR] Tag Registry unavailable." >>"$LOG_FILE"
  fi
}

# ---------- LOAD MANIFESTS ----------
load_manifests() {
  echo "[INFO] Loading task manifests..."
  local TMP="/tmp/manifest_$(date +%s).json"
  for src in \
    "https://cdn.vortexhub.app/tasks/manifest.json" \
    "https://render.vortexhub.app/backup/manifest.json" \
    "/var/vortexhub/local_manifest.json"; do
    echo "[INFO] Trying $src ..."
    curl -s -L "$src" -o "$TMP" && [ -s "$TMP" ] && break
  done
  [ ! -s "$TMP" ] && { echo "[ERROR] Manifest load failed"; return 1; }
  jq -r '.tasks[] | .id + " " + .priority + " " + .script_url + " " + (.signature // "")' "$TMP" >/tmp/task_list.txt
  echo "[INFO] Manifest loaded: $(wc -l < /tmp/task_list.txt) tasks."
}

# ---------- SIGNATURE VERIFY (ECDSA) ----------
verify_signature() {
  local manifest_path="$1" signature_b64="$2"
  [ "$USE_ECDSA" != true ] && return 0
  [ ! -f "$ECDSA_PUB" ] && { echo "[WARN] ECDSA pub key missing"; return 1; }
  jq -c -S . "$manifest_path" >"/tmp/payload.json"
  echo "$signature_b64" | base64 -d >/tmp/sig.bin 2>/dev/null
  openssl dgst -verify "$ECDSA_PUB" -sha256 -signature /tmp/sig.bin /tmp/payload.json >/dev/null 2>&1
}

# ---------- TASK SELECTION ----------
select_task() {
  echo "[INFO] Selecting next task..."
  local FEEDBACK
  FEEDBACK=$(curl -s "$META_REASONER_URL?node=$(hostname)" | jq -r '.recommendation.priority_boost // 0' 2>/dev/null)
  awk -v boost="$FEEDBACK" '{print $1, $2 - boost, $3, $4}' /tmp/task_list.txt | sort -k2 -n | head -1
}

# ---------- EXECUTION WRAPPER ----------
run_task() {
  local ID="$1" URL="$2" SIGN="$3" TMP="/tmp/${ID}.sh" MAN="/tmp/${ID}_manifest.json"
  echo "[TASK:$ID] Downloading & executing..."
  curl -s -L "$URL" -o "$TMP" || { echo "[ERROR] Failed to download $URL"; return 1; }
  chmod +x "$TMP"
  if [ -n "$SIGN" ] && [ -f "$ECDSA_PUB" ]; then
    local MAN_URL="${URL}.manifest.json"
    curl -s -L "$MAN_URL" -o "$MAN"
    [ -s "$MAN" ] && verify_signature "$MAN" "$SIGN" || echo "[WARN] Signature not verified"
  fi
  timeout 300 bash "$TMP" >>"$LOG_FILE" 2>&1
  local STATUS=$? TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  if [ $STATUS -eq 0 ]; then
    jq -n --arg id "$ID" --arg ts "$TS" '{id:$id,status:"success",timestamp:$ts}' \
      | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL"
  else
    echo "$ID" >>/tmp/retry_queue.txt
    jq -n --arg id "$ID" --arg ts "$TS" --arg err "$STATUS" \
      '{id:$id,status:"failed",code:$err,timestamp:$ts}' \
      | curl -s -X POST -H "Content-Type: application/json" -d @- "$LIFEGUARD_URL"
  fi
}

# ---------- WRAPPER INVOKE ----------
wrapper_invoke() {
  local MODE=$1
  if [ -x "$WRAPPER_HOOK" ]; then
    python3 "$WRAPPER_HOOK" --mode="$MODE" --registry="$TAG_REGISTRY" --manifest="$MANIFEST_GLOBAL" --telemetry="$TELEMETRY_URL"
  elif [ -f "$WRAPPER_REGISTRY_HOOK" ]; then
    node "$WRAPPER_REGISTRY_HOOK" "$MODE" "$TAG_REGISTRY"
  fi
}

# ---------- REGISTRY FEEDBACK ----------
registry_feedback() {
  jq -n --arg node "$(hostname)" --arg tags "$(jq 'keys|length' "$TAG_REGISTRY" 2>/dev/null || echo 0)" \
    --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    '{node:$node,registered_tags:($tags|tonumber),timestamp:$ts}' \
    | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL/registry"
}

# ---------- SELF-HEAL ----------
self_heal() {
  if [ -s /tmp/retry_queue.txt ]; then
    while read -r ID; do
      URL=$(grep "$ID" /tmp/task_list.txt | awk '{print $3}')
      [ -n "$URL" ] && run_task "$ID" "$URL"
    done </tmp/retry_queue.txt
    > /tmp/retry_queue.txt
  fi
  wrapper_invoke "heal"
  registry_feedback
}

# ---------- AI FEEDBACK ----------
ai_feedback() {
  jq -n --arg node "$(hostname)" --arg status "active" \
    --argjson uptime "$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)" \
    '{node:$node,status:$status,uptime:$uptime,timestamp:now|todate}' \
    | curl -s -X POST -H "Content-Type: application/json" -d @- "$META_REASONER_URL/feedback"
}

# ---------- CHECKPOINT ----------
checkpoint() {
  echo "$(date) | Tasks run: $(wc -l < /tmp/task_list.txt 2>/dev/null)" >>/var/log/vortexhub_checkpoint.log
  cp /tmp/task_list.txt /var/vortexhub/last_task_snapshot.txt 2>/dev/null
}

# ---------- NETWORK RESILIENCE ----------
network_resilience() {
  ping -c1 api.vortexhub.app >/dev/null 2>&1 || OFFLINE_MODE=true
}

# ---------- UPLOAD CHUNK ----------
upload_chunk() {
  local path="$1" remote="$2"
  if command -v rclone >/dev/null 2>&1; then
    echo "[UPLOAD] rclone uploading $path -> $RCLONE_REMOTE/$remote"
    rclone copyto "$path" "$RCLONE_REMOTE/$remote" --transfers=4 --checkers=8 --s3-chunk-size=64M
    return $?
  fi
  [ -n "$PRESIGNED_UPLOAD_URL" ] && curl -s -X PUT -T "$path" "$PRESIGNED_UPLOAD_URL" && return 0
  echo "[WARN] No upload method available."; return 2
}

# ---------- WS TELEMETRY ----------
ws_send_telemetry() {
  local payload="$1"
  if command -v websocat >/dev/null 2>&1 && [ -n "$WS_MONITOR_URL" ]; then
    echo "$payload" | websocat -1 "$WS_MONITOR_URL" >/dev/null 2>&1 && return 0
  fi
  echo "$payload" | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL/stream" >/dev/null 2>&1
}

# ---------- LOCAL MONITOR ----------
start_local_monitor() {
  if [ -f /home/pi/vortex/monitor/monitor.py ]; then
    (cd /home/pi/vortex/monitor && nohup python3 monitor.py >/var/log/vortex_local_monitor.log 2>&1 &)
  fi
}

# ---------- MAIN LOOP ----------
main_loop() {
  echo "[SCHEDULER] Starting orchestrator loop..."
  local iteration=0
  while true; do
    ((iteration++))
    echo "-------- Loop #$iteration --------"
    network_resilience
    load_manifests || { echo "[ERROR] Manifest not loaded." >>"$LOG_FILE"; sleep 120; continue; }
    local TASK_INFO ID URL SIGN
    TASK_INFO=$(select_task)
    ID=$(echo "$TASK_INFO" | awk '{print $1}')
    URL=$(echo "$TASK_INFO" | awk '{print $3}')
    SIGN=$(echo "$TASK_INFO" | awk '{print $4}')
    [ -n "$ID" ] && run_task "$ID" "$URL" "$SIGN"
    self_heal
    ai_feedback
    checkpoint
    echo "[LOOP] Sleep 60s..."; sleep 60
  done
}

# ---------- STARTUP ----------
startup() {
  [ -f "$LOCK_FILE" ] && { echo "[WARN] Scheduler already running."; exit 0; }
  echo $$ >"$LOCK_FILE"
  trap 'rm -f "$LOCK_FILE"' EXIT
  check_environment
  start_local_monitor
  main_loop
}

# ---------- EXECUTE ----------
startup
# ============================================================
# END OF VORTEXHUB TASK SCHEDULER v0.2-FUSION (EXTENDED CLEAN)
# ============================================================


#!/bin/bash
# ============================================================
# VORTEXHUB TASK SCHEDULER v0.3-FUSION (EXTENDED CLEAN MINIFIED)
# Author: Dr. S.M.H. Sadat / VortexHub Labs
# ============================================================
set -euo pipefail;IFS=$'\n\t';CONFIG_PATH="/etc/vortexhub/config.json";TASK_DIR="/var/vortexhub/tasks";LOG_FILE="/var/log/vortexhub_scheduler.log";LOCK_FILE="/tmp/vortexhub_scheduler.lock";MAX_PARALLEL_TASKS=4;META_REASONER_URL="https://api.vortexhub.app/meta_reasoner";LIFEGUARD_URL="https://api.vortexhub.app/lifeguard/ping";WRAPPER_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.py";WRAPPER_REGISTRY_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.js";TELEMETRY_URL="https://api.vortexhub.app/telemetry/scheduler";TAG_REGISTRY="/etc/vortexhub/tag_registry.json";MANIFEST_GLOBAL="/etc/vortexhub/manifest_global.yml";CLIENT_MANIFEST_DIR="/etc/vortexhub/client_manifests";OFFLINE_MODE=false;CLOUD_ENDPOINT="${CLOUD_ENDPOINT:-https://r2.cloudflare.com}";CLOUD_BUCKET="${CLOUD_BUCKET:-vortex-drone-bucket}";RCLONE_REMOTE="${RCLONE_REMOTE:-remote:drone-bucket}";ECDSA_PUB="/etc/vortexhub/keys/device_pub.pem";ECDSA_PRIV="/etc/vortexhub/keys/device_priv.pem";USE_ECDSA=true;WS_MONITOR_URL="${WS_MONITOR_URL:-}";log(){echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $*";}

check_environment(){log "Checking environment...";for cmd in jq curl timeout bash awk sort head ping openssl rclone;do command -v "$cmd">/dev/null 2>&1||log "[WARN] Missing dependency: $cmd";done;mkdir -p "$TASK_DIR" "$CLIENT_MANIFEST_DIR" "/etc/vortexhub/keys";touch "$LOG_FILE";init_registry;log "Environment ready.";}

init_registry(){log "Initializing Tag Registry...";[ ! -f "$TAG_REGISTRY" ]&&{log "[WARN] Registry missing; requesting from Meta-Reasoner...";curl -s -L "$META_REASONER_URL/registry" -o "$TAG_REGISTRY";};[ -s "$TAG_REGISTRY" ]&&log "[OK] Registry ready. Tags: $(jq 'keys|length' "$TAG_REGISTRY" 2>/dev/null)"||log "[ERROR] Tag Registry unavailable.";}

load_manifests(){log "Loading task manifests...";local TMP="/tmp/manifest_$(date +%s).json";for src in "https://cdn.vortexhub.app/tasks/manifest.json" "https://render.vortexhub.app/backup/manifest.json" "/var/vortexhub/local_manifest.json";do log "Trying $src ...";curl -s -L "$src" -o "$TMP"&&[ -s "$TMP" ]&&break;done;[ ! -s "$TMP" ]&&{log "[ERROR] Manifest load failed";return 1;};jq -r '.tasks[]|.id+" "+.priority+" "+.script_url+" "+(.signature//"")' "$TMP">/tmp/task_list.txt;log "Manifest loaded: $(wc -l< /tmp/task_list.txt) tasks.";}

verify_signature(){local M="$1" S="$2";[ "$USE_ECDSA"!=true ]&&return 0;[ ! -f "$ECDSA_PUB" ]&&{log "[WARN] ECDSA pub key missing";return 1;};jq -c -S . "$M">/tmp/payload.json;echo "$S"|base64 -d>/tmp/sig.bin 2>/dev/null;openssl dgst -verify "$ECDSA_PUB" -sha256 -signature /tmp/sig.bin /tmp/payload.json>/dev/null 2>&1;}

select_task(){log "Selecting next task...";local F;F=$(curl -s "$META_REASONER_URL?node=$(hostname)"|jq -r '.recommendation.priority_boost//0'2>/dev/null||echo 0);awk -v b="$F" '{print $1,$2-b,$3,$4}'/tmp/task_list.txt|sort -k2 -n|head -1;}

run_task(){local ID="$1"URL="$2"SIGN="$3"TMP="/tmp/${ID}.sh"MAN="/tmp/${ID}_manifest.json";log "[TASK:$ID] Downloading & executing...";curl -s -L "$URL"-o"$TMP"||{log "[ERROR] Failed $URL";return 1;};chmod +x "$TMP";if[ -n "$SIGN" ]&&[ -f "$ECDSA_PUB" ];then local MU="${URL}.manifest.json";curl -s -L "$MU"-o"$MAN";[ -s "$MAN" ]&&verify_signature "$MAN" "$SIGN"||log "[WARN] Signature not verified";fi;timeout 300 bash "$TMP">>"$LOG_FILE"2>&1||true;local S=$?T=$(date -u +"%Y-%m-%dT%H:%M:%SZ");if[ $S -eq 0 ];then jq -n --arg id"$ID"--arg ts"$T"'{"id":$id,"status":"success","timestamp":$ts}'|curl -s -X POST -H "Content-Type: application/json"-d @- "$TELEMETRY_URL";else echo "$ID">>/tmp/retry_queue.txt;jq -n --arg id"$ID"--arg ts"$T"--arg err"$S"'{"id":$id,"status":"failed","code":$err,"timestamp":$ts}'|curl -s -X POST -H "Content-Type: application/json"-d @- "$LIFEGUARD_URL";fi;}

wrapper_invoke(){local M=$1;if[ -x "$WRAPPER_HOOK" ];then python3 "$WRAPPER_HOOK"--mode="$M"--registry="$TAG_REGISTRY"--manifest="$MANIFEST_GLOBAL"--telemetry="$TELEMETRY_URL";elif[ -f "$WRAPPER_REGISTRY_HOOK" ];then node "$WRAPPER_REGISTRY_HOOK"$M"$TAG_REGISTRY";fi;}

registry_feedback(){jq -n --arg n"$(hostname)"--arg t"$(jq 'keys|length' "$TAG_REGISTRY"2>/dev/null||echo 0)"--arg ts"$(date -u +"%Y-%m-%dT%H:%M:%SZ")"'{"node":$n,"registered_tags":($t|tonumber),"timestamp":$ts}'|curl -s -X POST -H"Content-Type: application/json"-d @- "$TELEMETRY_URL/registry";}

self_heal(){[ -s /tmp/retry_queue.txt ]&&while read -r ID;do URL=$(grep "$ID"/tmp/task_list.txt|awk'{print$3}');[ -n "$URL" ]&&run_task"$ID""$URL";done</tmp/retry_queue.txt;> /tmp/retry_queue.txt;wrapper_invoke"heal";registry_feedback;}

ai_feedback(){jq -n --arg n"$(hostname)"--arg s"active"--argjson u"$(awk '{print int($1)}'/proc/uptime2>/dev/null||echo 0)"'{"node":$n,"status":$s,"uptime":$u,"timestamp":(now|todate)}'|curl -s -X POST -H"Content-Type: application/json"-d @- "$META_REASONER_URL/feedback";}

checkpoint(){echo"$(date)|Tasks:$(wc -l< /tmp/task_list.txt 2>/dev/null)">>/var/log/vortexhub_checkpoint.log;cp /tmp/task_list.txt/var/vortexhub/last_task_snapshot.txt2>/dev/null;}

network_resilience(){ping -c1 api.vortexhub.app>/dev/null2>&1||OFFLINE_MODE=true;}

upload_chunk(){local P="$1"R="$2";if command -v rclone>/dev/null2>&1;then echo"[UPLOAD]rclone $P->$RCLONE_REMOTE/$R";rclone copyto"$P""$RCLONE_REMOTE/$R"--transfers=4--checkers=8--s3-chunk-size=64M;return$?;fi;[ -n "$PRESIGNED_UPLOAD_URL" ]&&curl -s -X PUT -T"$P""$PRESIGNED_UPLOAD_URL"&&return0;echo"[WARN]No upload method";return2;}

ws_send_telemetry(){local p="$1";if command -v websocat>/dev/null2>&1&&[ -n "$WS_MONITOR_URL" ];then echo"$p"|websocat -1"$WS_MONITOR_URL">/dev/null2>&1;else echo"$p"|curl -s -X POST -H"Content-Type: application/json"-d @- "$TELEMETRY_URL/stream">/dev/null2>&1;fi;}

start_local_monitor(){[ -f /home/pi/vortex/monitor/monitor.py ]&& (cd /home/pi/vortex/monitor&&nohup python3 monitor.py>/var/log/vortex_local_monitor.log2>&1&);}

main_loop(){log "[SCHEDULER]Start loop...";local i=0;while true;do((i++));log"----Loop#$i----";network_resilience;load_manifests||{log"[ERROR]Manifest load failed";sleep120;continue;};local T ID U S;T=$(select_task);ID=$(echo"$T"|awk'{print$1}');U=$(echo"$T"|awk'{print$3}');S=$(echo"$T"|awk'{print$4}');[ -n "$ID" ]&&run_task"$ID""$U""$S";self_heal;ai_feedback;checkpoint;log"[LOOP]Sleep60s...";sleep60;done;}

startup(){[ -f "$LOCK_FILE" ]&&{log"[WARN]Already running.";exit0;};echo$$>"$LOCK_FILE";trap'rm -f"$LOCK_FILE";log"Lock removed"'EXIT;check_environment;start_local_monitor;main_loop;}

startup
# ============================================================
# END OF VORTEXHUB TASK SCHEDULER v0.3-FUSION (CLEAN MINIFIED)
# ============================================================



#!/bin/bash
# ============================================================
# VORTEXHUB UNIVERSAL ORCHESTRATOR v0.4-FUSION-DYNAMIC-AI
# Core: Task Scheduler v0.3 + VUIF v1.2-DYNAMIC+FUSION Layer
# Author: Dr. S.M.H. Sadat / VortexHub Labs
# ============================================================

set -euo pipefail
IFS=$'\n\t'

# ---------- [ CORE CONFIGURATION ] ----------
CONFIG_PATH="/etc/vortexhub/config.json"
TASK_DIR="/var/vortexhub/tasks"
LOG_FILE="/var/log/vortexhub_scheduler.log"
LOCK_FILE="/tmp/vortexhub_scheduler.lock"
MAX_PARALLEL_TASKS=4
META_REASONER_URL="https://api.vortexhub.app/meta_reasoner"
LIFEGUARD_URL="https://api.vortexhub.app/lifeguard/ping"
WRAPPER_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.py"
WRAPPER_REGISTRY_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.js"
TELEMETRY_URL="https://api.vortexhub.app/telemetry/scheduler"
TAG_REGISTRY="/etc/vortexhub/tag_registry.json"
MANIFEST_GLOBAL="/etc/vortexhub/manifest_global.yml"
CLIENT_MANIFEST_DIR="/etc/vortexhub/client_manifests"
OFFLINE_MODE=false
CLOUD_ENDPOINT="${CLOUD_ENDPOINT:-https://r2.cloudflare.com}"
CLOUD_BUCKET="${CLOUD_BUCKET:-vortex-drone-bucket}"
RCLONE_REMOTE="${RCLONE_REMOTE:-remote:drone-bucket}"
ECDSA_PUB="/etc/vortexhub/keys/device_pub.pem"
ECDSA_PRIV="/etc/vortexhub/keys/device_priv.pem"
USE_ECDSA=true
WS_MONITOR_URL="${WS_MONITOR_URL:-}"

# ---------- [ LOGGING FUNCTION ] ----------
log(){ echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $*"; }

# ============================================================
#  SECTION 1 -- INTELLIGENT META-LAYER (FROM VUIF)
# ============================================================

AI_AUTOFILL=true
AI_BEHAVIOR_MODE="sandbox_forced_safe"
AI_CONFIDENCE_THRESHOLD="0.9"
AI_SELF_VERIFY=true
AI_REVIEW_REQUIRED=true
AI_CONTEXT="Autonomous AI-driven scheduler reasoning"
AI_MEMORY_PATH="/etc/vortexhub/ai_memory/vortex_feedback.json"
AI_REGION_POLICY="dynamic"
AI_TASK_TYPES=("AI" "Hardware" "Network" "Logic" "SQL" "API" "Encryption" "Firmware")

detect_task_type(){
  local tag="$1"
  case "$tag" in
    *AI_* ) echo "AI" ;;
    *HW_* | *HARDWARE* ) echo "Hardware" ;;
    *NET_* ) echo "Network" ;;
    *SQL_* ) echo "SQL" ;;
    *ENC_* | *CRYPTO* ) echo "Encryption" ;;
    *API_* ) echo "API" ;;
    *LOGIC_* ) echo "Logic" ;;
    * ) echo "General" ;;
  esac
}

sandbox_detect(){
  if grep -qi "Virtual" /proc/cpuinfo 2>/dev/null; then
    log "[⚠️] Sandbox detected. Switching to safe mode."
    export SANDBOX_DETECTED=true
  else
    SANDBOX_DETECTED=false
  fi
}

sandbox_override(){
  if [[ "${SANDBOX_OVERRIDE:-0}" == "1" ]]; then
    log "[⚙️] Sandbox override active (simulation mode)."
  elif [[ "$SANDBOX_DETECTED" == true ]]; then
    log "[SAFE] Running with restricted IO, encrypted logs, and limited network."
    # fallback to safe execution
  fi
}

# ---------- AI CUSTOMIZATION ENGINE (FUSION OF 40 IDEAS) ----------
AI_MODULES=(
  "PolicyFusionLayer"
  "EncryptedCapsule"
  "DynamicTagOverlays"
  "AIBehaviorDNA"
  "PredictiveLoader"
  "SelfSignatureEnforcer"
  "RegionAwareMirror"
  "IntegrityBeacon"
  "WrapperAutonomousPatch"
  "AIRepairNetwork"
  "BehaviorThrottler"
  "LegalScopeController"
  "AdaptiveEncryption"
  "AI_OfflineResilience"
  "DynamicCommandWhitelist"
  "TemporalRollback"
  "MultiAI_Strategy"
  "AutoManifestFusion"
  "CustomPersonaEngine"
  "FeedbackEncryptor"
)
for mod in "${AI_MODULES[@]}"; do log "[AI-MODULE] Loaded: $mod"; done

# ============================================================
#  SECTION 2 -- ORIGINAL TASK SCHEDULER (UNCHANGED CORE)
# ============================================================

check_environment(){
  log "Checking environment..."
  for cmd in jq curl timeout bash awk sort head ping openssl rclone; do
    command -v "$cmd" >/dev/null 2>&1 || log "[WARN] Missing dependency: $cmd"
  done
  mkdir -p "$TASK_DIR" "$CLIENT_MANIFEST_DIR" "/etc/vortexhub/keys"
  touch "$LOG_FILE"
  init_registry
  log "Environment ready."
}

init_registry(){
  log "Initializing Tag Registry..."
  [ ! -f "$TAG_REGISTRY" ] && {
    log "[WARN] Registry missing; requesting from Meta-Reasoner..."
    curl -s -L "$META_REASONER_URL/registry" -o "$TAG_REGISTRY"
  }
  [ -s "$TAG_REGISTRY" ] && log "[OK] Registry ready. Tags: $(jq 'keys|length' "$TAG_REGISTRY" 2>/dev/null)" || log "[ERROR] Tag Registry unavailable."
}

load_manifests(){
  log "Loading task manifests..."
  local TMP="/tmp/manifest_$(date +%s).json"
  for src in \
    "https://cdn.vortexhub.app/tasks/manifest.json" \
    "https://render.vortexhub.app/backup/manifest.json" \
    "/var/vortexhub/local_manifest.json"; do
    log "Trying $src ..."
    curl -s -L "$src" -o "$TMP" && [ -s "$TMP" ] && break
  done
  [ ! -s "$TMP" ] && { log "[ERROR] Manifest load failed"; return 1; }
  jq -r '.tasks[] | .id+" "+.priority+" "+.script_url+" "+(.signature//"")' "$TMP" > /tmp/task_list.txt
  log "Manifest loaded: $(wc -l < /tmp/task_list.txt) tasks."
}

verify_signature(){
  local M="$1" S="$2"
  [ "$USE_ECDSA" != true ] && return 0
  [ ! -f "$ECDSA_PUB" ] && { log "[WARN] ECDSA pub key missing"; return 1; }
  jq -c -S . "$M" > /tmp/payload.json
  echo "$S" | base64 -d > /tmp/sig.bin 2>/dev/null
  openssl dgst -verify "$ECDSA_PUB" -sha256 -signature /tmp/sig.bin /tmp/payload.json >/dev/null 2>&1
}

select_task(){
  log "Selecting next task..."
  local F
  F=$(curl -s "$META_REASONER_URL?node=$(hostname)" | jq -r '.recommendation.priority_boost//0' 2>/dev/null || echo 0)
  awk -v b="$F" '{print $1,$2-b,$3,$4}' /tmp/task_list.txt | sort -k2 -n | head -1
}

run_task(){
  local ID="$1" URL="$2" SIGN="$3"
  local TMP="/tmp/${ID}.sh" MAN="/tmp/${ID}_manifest.json"
  log "[TASK:$ID] Downloading & executing..."
  curl -s -L "$URL" -o "$TMP" || { log "[ERROR] Failed $URL"; return 1; }
  chmod +x "$TMP"
  if [ -n "$SIGN" ] && [ -f "$ECDSA_PUB" ]; then
    local MU="${URL}.manifest.json"
    curl -s -L "$MU" -o "$MAN"
    [ -s "$MAN" ] && verify_signature "$MAN" "$SIGN" || log "[WARN] Signature not verified"
  fi
  timeout 300 bash "$TMP" >> "$LOG_FILE" 2>&1 || true
  local S=$? T=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  if [ $S -eq 0 ]; then
    jq -n --arg id "$ID" --arg ts "$T" '{"id":$id,"status":"success","timestamp":$ts}' | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL"
  else
    echo "$ID" >> /tmp/retry_queue.txt
    jq -n --arg id "$ID" --arg ts "$T" --arg err "$S" '{"id":$id,"status":"failed","code":$err,"timestamp":$ts}' | curl -s -X POST -H "Content-Type: application/json" -d @- "$LIFEGUARD_URL"
  fi
}

wrapper_invoke(){
  local M=$1
  if [ -x "$WRAPPER_HOOK" ]; then
    python3 "$WRAPPER_HOOK" --mode="$M" --registry="$TAG_REGISTRY" --manifest="$MANIFEST_GLOBAL" --telemetry="$TELEMETRY_URL"
  elif [ -f "$WRAPPER_REGISTRY_HOOK" ]; then
    node "$WRAPPER_REGISTRY_HOOK" "$M" "$TAG_REGISTRY"
  fi
}

registry_feedback(){
  jq -n --arg n "$(hostname)" --arg t "$(jq 'keys|length' "$TAG_REGISTRY" 2>/dev/null || echo 0)" --arg ts "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" \
  '{"node":$n,"registered_tags":($t|tonumber),"timestamp":$ts}' | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL/registry"
}

self_heal(){
  [ -s /tmp/retry_queue.txt ] && while read -r ID; do
    URL=$(grep "$ID" /tmp/task_list.txt | awk '{print $3}')
    [ -n "$URL" ] && run_task "$ID" "$URL"
  done < /tmp/retry_queue.txt
  > /tmp/retry_queue.txt
  wrapper_invoke "heal"
  registry_feedback
}

ai_feedback(){
  jq -n --arg n "$(hostname)" --arg s "active" --argjson u "$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)" \
  '{"node":$n,"status":$s,"uptime":$u,"timestamp":(now|todate)}' | curl -s -X POST -H "Content-Type: application/json" -d @- "$META_REASONER_URL/feedback"
}

checkpoint(){
  echo "$(date) | Tasks: $(wc -l < /tmp/task_list.txt 2>/dev/null)" >> /var/log/vortexhub_checkpoint.log
  cp /tmp/task_list.txt /var/vortexhub/last_task_snapshot.txt 2>/dev/null || true
}

network_resilience(){ ping -c1 api.vortexhub.app >/dev/null 2>&1 || OFFLINE_MODE=true; }

upload_chunk(){
  local P="$1" R="$2"
  if command -v rclone >/dev/null 2>&1; then
    log "[UPLOAD] rclone $P -> $RCLONE_REMOTE/$R"
    rclone copyto "$P" "$RCLONE_REMOTE/$R" --transfers=4 --checkers=8 --s3-chunk-size=64M; return $?
  fi
  [ -n "$PRESIGNED_UPLOAD_URL" ] && curl -s -X PUT -T "$P" "$PRESIGNED_UPLOAD_URL" && return 0
  log "[WARN] No upload method"; return 2
}

ws_send_telemetry(){
  local p="$1"
  if command -v websocat >/dev/null 2>&1 && [ -n "$WS_MONITOR_URL" ]; then
    echo "$p" | websocat -1 "$WS_MONITOR_URL" >/dev/null 2>&1
  else
    echo "$p" | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL/stream" >/dev/null 2>&1
  fi
}

start_local_monitor(){
  [ -f /home/pi/vortex/monitor/monitor.py ] && (cd /home/pi/vortex/monitor && nohup python3 monitor.py >/var/log/vortex_local_monitor.log 2>&1 &)
}

main_loop(){
  log "[SCHEDULER] Start loop..."
  local i=0
  while true; do
    ((i++))
    log "---- Loop #$i ----"
    network_resilience
    load_manifests || { log "[ERROR] Manifest load failed"; sleep 120; continue; }
    local T ID U S
    T=$(select_task)
    ID=$(echo "$T" | awk '{print $1}')
    U=$(echo "$T" | awk '{print $3}')
    S=$(echo "$T" | awk '{print $4}')
    [ -n "$ID" ] && run_task "$ID" "$U" "$S"
    self_heal
    ai_feedback
    checkpoint
    log "[LOOP] Sleep 60s..."
    sleep 60
  done
}

startup(){
  [ -f "$LOCK_FILE" ] && { log "[WARN] Already running."; exit 0; }
  echo $$ > "$LOCK_FILE"
  trap 'rm -f "$LOCK_FILE"; log "Lock removed"' EXIT
  sandbox_detect
  sandbox_override
  check_environment
  start_local_monitor
  main_loop
}

startup
# ============================================================
# END OF VORTEXHUB UNIVERSAL ORCHESTRATOR v0.4-FUSION-DYNAMIC-AI
# ============================================================


#!/bin/bash
# ============================================================
#  VORTEXHUB UNIVERSAL ORCHESTRATOR v0.4-HYBRID+AI+SELF-HEALING
#  Part 1/3 -- CORE + META-REASONER + REGISTRY + INTEGRITY LAYER
#  Author: Dr. S.M.H. Sadat / VortexHub Labs
# ============================================================

set -euo pipefail
IFS=$'\n\t'

# ---------- CORE CONFIGURATION (ORIGINAL PRESERVED) ----------
CONFIG_PATH="${CONFIG_PATH:-/etc/vortexhub/config.json}"
TASK_DIR="${TASK_DIR:-/var/vortexhub/tasks}"
LOG_FILE="${LOG_FILE:-/var/log/vortexhub_scheduler.log}"
LOCK_FILE="${LOCK_FILE:-/tmp/vortexhub_scheduler.lock}"
MAX_PARALLEL_TASKS="${MAX_PARALLEL_TASKS:-4}"
META_REASONER_URL="${META_REASONER_URL:-https://api.vortexhub.app/meta_reasoner}"
LIFEGUARD_URL="${LIFEGUARD_URL:-https://api.vortexhub.app/lifeguard/ping}"
WRAPPER_HOOK="${WRAPPER_HOOK:-/usr/local/vortexhub/vortex_wrapper_ai.py}"
WRAPPER_REGISTRY_HOOK="${WRAPPER_REGISTRY_HOOK:-/usr/local/vortexhub/vortex_wrapper_ai.js}"
TELEMETRY_URL="${TELEMETRY_URL:-https://api.vortexhub.app/telemetry/scheduler}"
TAG_REGISTRY="${TAG_REGISTRY:-/etc/vortexhub/tag_registry.json}"
MANIFEST_GLOBAL="${MANIFEST_GLOBAL:-/etc/vortexhub/manifest_global.yml}"
CLIENT_MANIFEST_DIR="${CLIENT_MANIFEST_DIR:-/etc/vortexhub/client_manifests}"

EDGE_NODE_UUID="${EDGE_NODE_UUID:-EDGE-UUID-HERE}"
CLOUD_REGION="${CLOUD_REGION:-EU}"
ENVIRONMENT_KIND="${ENVIRONMENT_KIND:-hybrid}"

# ---------- EXTENDED META DATA (added, not replaced) ----------
SYSTEM_SIGNATURE="VORTEXHUB_LIFEGUARD_FUSION"
SELF_VERSION="0.4"
VUIF_SCHEMA="https://cdn.vortexhub.app/vuif_schema.json"
INTEGRITY_HASH_FILE="/etc/vortexhub/integrity.hash"
PHILOSOPHY_MAP="https://cdn.vortexhub.app/philosophy_map.json"

# Logging helper (original preserved)
log() { echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $*"; }

# ============================================================
# 🔐 ENVIRONMENT VALIDATION + LIFEGUARD INTEGRATION
# ============================================================
check_environment() {
  log "Checking environment..."
  local missing=0
  for cmd in jq curl timeout bash awk sort head ping openssl rclone base64; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      log "WARN: Missing dependency: $cmd (some features may be disabled)"
      missing=$((missing+1))
    fi
  done
  mkdir -p "$TASK_DIR" "$CLIENT_MANIFEST_DIR" "$(dirname "$LOG_FILE")"
  touch "$LOG_FILE"
  init_registry

  # 🔁 LifeGuard health ping
  if command -v curl >/dev/null 2>&1; then
    curl -s -X POST -H "Content-Type: application/json" \
      -d "{\"node\":\"$(hostname)\",\"uuid\":\"$EDGE_NODE_UUID\",\"status\":\"ok\"}" \
      "$LIFEGUARD_URL" >/dev/null || log "LifeGuard: offline mode"
  fi

  log "Environment ready. Missing deps: $missing"
}

# ============================================================
# 🧩 TAG REGISTRY INITIALIZATION (VUIF-Aware + Safe Mode)
# ============================================================
init_registry() {
  log "Initializing Tag Registry..."
  if [ ! -f "$TAG_REGISTRY" ]; then
    log "Registry missing; requesting from Meta-Reasoner..."
    if command -v curl >/dev/null 2>&1; then
      curl -s -L "${META_REASONER_URL}/registry" -o "$TAG_REGISTRY" || true
    fi
  fi

  if [ ! -f "$TAG_REGISTRY" ] || [ ! -s "$TAG_REGISTRY" ]; then
    log "WARN: Tag Registry unavailable, creating minimal local registry."
    cat >"$TAG_REGISTRY" <<'JSON'
{}
JSON
  fi

  # New addition: self-describing registry link
  if ! grep -q "vuif_schema" "$TAG_REGISTRY" 2>/dev/null; then
    log "Embedding VUIF schema reference..."
    jq --arg schema "$VUIF_SCHEMA" '. + {"vuif_schema_ref": $schema}' "$TAG_REGISTRY" >"${TAG_REGISTRY}.tmp" 2>/dev/null || true
    mv -f "${TAG_REGISTRY}.tmp" "$TAG_REGISTRY" 2>/dev/null || true
  fi

  # Quick health check
  if command -v jq >/dev/null 2>&1; then
    local count
    count=$(jq 'keys | length' "$TAG_REGISTRY" 2>/dev/null || echo 0)
    log "Registry ready. Tags: $count"
  fi
}

# ============================================================
# 📦 MANIFEST LOADER (with fallback chain)
# ============================================================
load_manifests() {
  log "Loading task manifests..."
  local TMP="/tmp/manifest_$(date +%s).json"
  local sources=(
    "https://cdn.vortexhub.app/tasks/manifest.json"
    "https://render.vortexhub.app/backup/manifest.json"
    "/var/vortexhub/local_manifest.json"
  )
  local src
  for src in "${sources[@]}"; do
    log "Trying $src ..."
    if command -v curl >/dev/null 2>&1; then
      curl -s -L "$src" -o "$TMP" || true
    else
      if [ -f "$src" ]; then
        cp "$src" "$TMP" || true
      fi
    fi
    if [ -s "$TMP" ]; then
      log "Loaded manifest from $src"
      break
    fi
  done

  if [ ! -s "$TMP" ]; then
    log "ERROR: Manifest load failed"
    return 1
  fi

  # 🔒 Integrity hash save
  if command -v openssl >/dev/null 2>&1; then
    openssl dgst -sha256 "$TMP" | awk '{print $2}' >"$INTEGRITY_HASH_FILE" || true
  fi

  if command -v jq >/dev/null 2>&1; then
    jq -r '.tasks[] | .id + " " + (.priority|tostring) + " " + .script_url + " " + (.signature // "")' "$TMP" >/tmp/task_list.txt
    log "Manifest loaded: $(wc -l < /tmp/task_list.txt) tasks."
  else
    log "WARN: jq not available -- cannot parse manifest"
    return 1
  fi
}

# ============================================================
# 🧠 META-REASONER HANDSHAKE + PHILOSOPHY MAP LINKAGE
# ============================================================
meta_reasoner_query() {
  local endpoint="${META_REASONER_URL}"
  local payload
  payload=$(jq -n --arg node "$(hostname)" --arg env "$ENVIRONMENT_KIND" \
    --arg region "$CLOUD_REGION" \
    --arg version "$SELF_VERSION" \
    '{node:$node,environment:$env,region:$region,version:$version,timestamp:(now|todate)}')
  if command -v curl >/dev/null 2>&1; then
    curl -s -X POST -H "Content-Type: application/json" -d "$payload" "$endpoint" || echo "{}"
  else
    echo "{}"
  fi
}

# ============================================================
# 🎯 TASK SELECTION (with adaptive reasoning)
# ============================================================
select_task() {
  log "Selecting next task..."
  local FEEDBACK=0
  if command -v curl >/dev/null 2>&1; then
    local resp
    resp=$(curl -s "${META_REASONER_URL}?node=$(hostname)" 2>/dev/null || echo "{}")
    FEEDBACK=$(echo "$resp" | jq -r '.recommendation.priority_boost // 0' 2>/dev/null || echo 0)
  fi
  awk -v boost="$FEEDBACK" '{print $1, $2 - boost, $3, $4}' /tmp/task_list.txt | sort -k2 -n | head -1
}

# ============================================================
# 🧾 SIGNATURE / INTEGRITY STUB (Part 3: full verification)
# ============================================================
verify_manifest_signature_stub() {
  return 0
}

# ============================================================
# 🩺 SELF-HEALING WATCHDOG (new addition)
# ============================================================
lifeguard_self_heal() {
  log "Running LifeGuard self-heal scan..."
  if [ ! -s "$TAG_REGISTRY" ]; then
    log "⚠️ Registry corruption detected -- reloading..."
    init_registry
  fi
  if [ ! -s "$INTEGRITY_HASH_FILE" ]; then
    log "⚠️ Integrity hash missing -- recalculating..."
    if [ -f "/tmp/manifest_latest.json" ]; then
      openssl dgst -sha256 "/tmp/manifest_latest.json" | awk '{print $2}' >"$INTEGRITY_HASH_FILE"
    fi
  fi
  log "Self-heal complete."
}

# ============================================================
# 🚀 EXECUTION ENTRYPOINT
# ============================================================
log "Part 1 loaded: CORE + META-REASONER + REGISTRY + SELF-HEALING"
export -f check_environment init_registry load_manifests select_task meta_reasoner_query verify_manifest_signature_stub lifeguard_self_heal log

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  check_environment || exit 1
  if load_manifests; then
    log "Core manifest load succeeded."
  else
    log "Core manifest load failed; continuing (offline mode)."
  fi
  meta_reasoner_query | jq -C '.' 2>/dev/null | sed -n '1,40p' || true
  lifeguard_self_heal
  log "Part 1 complete. Continue with Part 2 and Part 3."
fi

# --- Meta-Philosophy Mapping: Fetch Logic & Reasoning ---
fetch_philosophy_reasoner() {
  # نمونه‌ی مفهومی: تصمیم درباره‌ی نحوه‌ی fetch بر اساس فلسفهٔ اجرای سیستم
  local mode="${1:-imperative}"
  case "$mode" in
    "imperative") log "[PHILOSOPHY] Explicit command-pull task (human-defined)";;
    "declarative") log "[PHILOSOPHY] Desired-state fetch (manifest driven)";;
    "event") log "[PHILOSOPHY] Event-driven trigger activated";;
    "ai") log "[PHILOSOPHY] AI core decided to fetch autonomously";;
    *) log "[PHILOSOPHY] Default minimal fetch logic";;
  esac
}

# --- Defensive Intelligence: Indicators and Response ---
defense_intelligence_scan() {
  log "[DEFENSE] Scanning for data-exfil / ransom / crypto-theft indicators..."
  # فقط شبیه‌سازی لاگ برای تحلیل، بدون اقدام واقعی
  log "[DEFENSE] No anomalies detected (simulated)."
}

# --- CTF / Writeup Learning Stub ---
vortex_ctf_learn() {
  log "[LEARN] Updating AI memory with CTF / writeup insights..."
  log "[LEARN] Philosophy: task=experience, script=neuron, telemetry=memory trace"
}

#!/bin/bash
# ============================================================
# VORTEXHUB UNIVERSAL ORCHESTRATOR v0.5-HYBRID-FUSION
# Core: v0.4 + Meta-Fusion Intelligence Layer
# Author: Dr. S.M.H. Sadat / VortexHub Labs
# ============================================================

set -euo pipefail; IFS=$'\n\t'

# ---------------- [META-HYBRID INTELLIGENCE LAYER] ----------------
HYBRID_CONTEXT_VERSION="2025-FUSION-RESILIENCE"
HYBRID_INTELLIGENCE_TAGS=("sandbox" "browser_agent_bridge" "cdnsync" "lifeguard_relay" "r2_selfheal" "meta_attestation")

ANTI_REVERSE_POLICY(){ if grep -qi "vbox\|vmware\|qemu" /proc/cpuinfo 2>/dev/null; then echo "[DEFENSE] Virtualization detected → adaptive lock engaged."; sleep 2; exit 133; fi; }
obfuscate_paths(){ export VX_TASK_DIR_HASH=$(echo -n "$TASK_DIR" | sha256sum | cut -c1-8); export VX_LOG_HASH=$(echo -n "$LOG_FILE" | sha256sum | cut -c1-6); export VX_MANIFEST_SEED=$(date +%s | sha1sum | cut -c1-10); log "[OBFUSCATION] Path entropy seeds set → $VX_TASK_DIR_HASH $VX_MANIFEST_SEED"; }
browser_bridge(){ local port="${BRIDGE_PORT:-8730}"; local endpoint="http://127.0.0.1:${port}/ping"; if curl -s --max-time 1 "$endpoint" | grep -q "pong"; then log "[BRIDGE] Browser-Agent active on $port"; else log "[BRIDGE] No active local bridge detected."; fi; }
meta_autorescue(){ local fallback="$CLOUD_ENDPOINT/fallback/$(hostname)"; curl -fs -X POST -d '{"node":"'"$(hostname)"'"}' "$fallback" >/dev/null 2>&1 || log "[RESCUE] offline recovery waiting (manifest_cache)"; }
quantum_shield(){ if [ -f "$ECDSA_PRIV" ]; then openssl rand -hex 32 | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$(hostname)" >/tmp/qshield.key; log "[QSHIELD] Quantum-safe ephemeral key generated (RAM-only)"; fi; }

ANTI_REVERSE_POLICY; obfuscate_paths; browser_bridge; quantum_shield

# ---------------- [CORE CONFIGURATION] ----------------
CONFIG_PATH="/etc/vortexhub/config.json"
TASK_DIR="/var/vortexhub/tasks"
LOG_FILE="/var/log/vortexhub_scheduler.log"
LOCK_FILE="/tmp/vortexhub_scheduler.lock"
MAX_PARALLEL_TASKS=4
META_REASONER_URL="https://api.vortexhub.app/meta_reasoner"
LIFEGUARD_URL="https://api.vortexhub.app/lifeguard/ping"
WRAPPER_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.py"
WRAPPER_REGISTRY_HOOK="/usr/local/vortexhub/vortex_wrapper_ai.js"
TELEMETRY_URL="https://api.vortexhub.app/telemetry/scheduler"
TAG_REGISTRY="/etc/vortexhub/tag_registry.json"
MANIFEST_GLOBAL="/etc/vortexhub/manifest_global.yml"
CLIENT_MANIFEST_DIR="/etc/vortexhub/client_manifests"
OFFLINE_MODE=false
CLOUD_ENDPOINT="${CLOUD_ENDPOINT:-https://r2.cloudflare.com}"
CLOUD_BUCKET="${CLOUD_BUCKET:-vortex-drone-bucket}"
RCLONE_REMOTE="${RCLONE_REMOTE:-remote:drone-bucket}"
ECDSA_PUB="/etc/vortexhub/keys/device_pub.pem"
ECDSA_PRIV="/etc/vortexhub/keys/device_priv.pem"
USE_ECDSA=true
WS_MONITOR_URL="${WS_MONITOR_URL:-}"

log(){ echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $*"; }

# ---------------- [INTELLIGENT META-LAYER] ----------------
AI_AUTOFILL=true; AI_BEHAVIOR_MODE="sandbox_forced_safe"; AI_CONFIDENCE_THRESHOLD="0.9"
AI_SELF_VERIFY=true; AI_REVIEW_REQUIRED=true; AI_CONTEXT="Autonomous AI-driven scheduler reasoning"
AI_MEMORY_PATH="/etc/vortexhub/ai_memory/vortex_feedback.json"; AI_REGION_POLICY="dynamic"
AI_TASK_TYPES=("AI" "Hardware" "Network" "Logic" "SQL" "API" "Encryption" "Firmware")

detect_task_type(){ local tag="$1"; case "$tag" in *AI_*) echo "AI";; *HW_*|*HARDWARE*) echo "Hardware";; *NET_*) echo "Network";; *SQL_*) echo "SQL";; *ENC_*|*CRYPTO*) echo "Encryption";; *API_*) echo "API";; *LOGIC_*) echo "Logic";; *) echo "General";; esac; }

sandbox_detect(){ if grep -qi "Virtual" /proc/cpuinfo 2>/dev/null; then log "[⚠️] Sandbox detected. Switching to safe mode."; export SANDBOX_DETECTED=true; else SANDBOX_DETECTED=false; fi; }
sandbox_override(){ if [[ "${SANDBOX_OVERRIDE:-0}" == "1" ]]; then log "[⚙️] Sandbox override active (simulation mode)."; elif [[ "$SANDBOX_DETECTED" == true ]]; then log "[SAFE] Running with restricted IO, encrypted logs, limited network."; fi; }

AI_MODULES=("PolicyFusionLayer" "EncryptedCapsule" "DynamicTagOverlays" "AIBehaviorDNA" "PredictiveLoader" "SelfSignatureEnforcer" "RegionAwareMirror" "IntegrityBeacon" "WrapperAutonomousPatch" "AIRepairNetwork" "BehaviorThrottler" "LegalScopeController" "AdaptiveEncryption" "AI_OfflineResilience" "DynamicCommandWhitelist" "TemporalRollback" "MultiAI_Strategy" "AutoManifestFusion" "CustomPersonaEngine" "FeedbackEncryptor")
for mod in "${AI_MODULES[@]}"; do log "[AI-MODULE] Loaded: $mod"; done

# ---------------- [CORE FUNCTIONS] ----------------
check_environment(){ log "Checking environment..."; for cmd in jq curl timeout bash awk sort head ping openssl rclone; do command -v "$cmd" >/dev/null 2>&1 || log "[WARN] Missing: $cmd"; done; mkdir -p "$TASK_DIR" "$CLIENT_MANIFEST_DIR" "/etc/vortexhub/keys"; touch "$LOG_FILE"; init_registry; log "Environment ready."; }

init_registry(){ log "Initializing Tag Registry..."; [ ! -f "$TAG_REGISTRY" ] && { log "[WARN] Registry missing; requesting..."; curl -s -L "$META_REASONER_URL/registry" -o "$TAG_REGISTRY"; }; [ -s "$TAG_REGISTRY" ] && log "[OK] Registry ready. Tags: $(jq 'keys|length' "$TAG_REGISTRY" 2>/dev/null)" || log "[ERROR] Tag Registry unavailable."; }

load_manifests(){ log "Loading task manifests..."; local TMP="/tmp/manifest_$(date +%s).json"; for src in "https://cdn.vortexhub.app/tasks/manifest.json" "https://render.vortexhub.app/backup/manifest.json" "/var/vortexhub/local_manifest.json"; do log "Trying $src ..."; curl -s -L "$src" -o "$TMP" && [ -s "$TMP" ] && break; done; [ ! -s "$TMP" ] && { log "[ERROR] Manifest load failed"; return 1; }; jq -r '.tasks[] | .id+" "+.priority+" "+.script_url+" "+(.signature//"")' "$TMP" > /tmp/task_list.txt; log "Manifest loaded: $(wc -l < /tmp/task_list.txt) tasks."; }

verify_signature(){ local M="$1" S="$2"; [ "$USE_ECDSA" != true ] && return 0; [ ! -f "$ECDSA_PUB" ] && { log "[WARN] Missing ECDSA pub"; return 1; }; jq -c -S . "$M" > /tmp/payload.json; echo "$S" | base64 -d > /tmp/sig.bin 2>/dev/null; openssl dgst -verify "$ECDSA_PUB" -sha256 -signature /tmp/sig.bin /tmp/payload.json >/dev/null 2>&1; }

select_task(){ log "Selecting next task..."; local F; F=$(curl -s "$META_REASONER_URL?node=$(hostname)" | jq -r '.recommendation.priority_boost//0' 2>/dev/null || echo 0); awk -v b="$F" '{print $1,$2-b,$3,$4}' /tmp/task_list.txt | sort -k2 -n | head -1; }

run_task(){ local ID="$1" URL="$2" SIGN="$3"; local TMP="/tmp/${ID}.sh" MAN="/tmp/${ID}_manifest.json"; log "[TASK:$ID] Downloading & executing..."; curl -s -L "$URL" -o "$TMP" || { log "[ERROR] Failed $URL"; return 1; }; chmod +x "$TMP"; if [ -n "$SIGN" ] && [ -f "$ECDSA_PUB" ]; then local MU="${URL}.manifest.json"; curl -s -L "$MU" -o "$MAN"; [ -s "$MAN" ] && verify_signature "$MAN" "$SIGN" || log "[WARN] Signature not verified"; fi; timeout 300 bash "$TMP" >> "$LOG_FILE" 2>&1 || true; local S=$? T=$(date -u +"%Y-%m-%dT%H:%M:%SZ"); if [ $S -eq 0 ]; then jq -n --arg id "$ID" --arg ts "$T" '{"id":$id,"status":"success","timestamp":$ts}' | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL"; else echo "$ID" >> /tmp/retry_queue.txt; jq -n --arg id "$ID" --arg ts "$T" --arg err "$S" '{"id":$id,"status":"failed","code":$err,"timestamp":$ts}' | curl -s -X POST -H "Content-Type: application/json" -d @- "$LIFEGUARD_URL"; fi; }

wrapper_invoke(){ local M=$1; if [ -x "$WRAPPER_HOOK" ]; then python3 "$WRAPPER_HOOK" --mode="$M" --registry="$TAG_REGISTRY" --manifest="$MANIFEST_GLOBAL" --telemetry="$TELEMETRY_URL"; elif [ -f "$WRAPPER_REGISTRY_HOOK" ]; then node "$WRAPPER_REGISTRY_HOOK" "$M" "$TAG_REGISTRY"; fi; }

registry_feedback(){ jq -n --arg n "$(hostname)" --arg t "$(jq 'keys|length' "$TAG_REGISTRY" 2>/dev/null || echo 0)" --arg ts "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" '{"node":$n,"registered_tags":($t|tonumber),"timestamp":$ts}' | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL/registry"; }

self_heal(){ [ -s /tmp/retry_queue.txt ] && while read -r ID; do URL=$(grep "$ID" /tmp/task_list.txt | awk '{print $3}'); [ -n "$URL" ] && run_task "$ID" "$URL"; done < /tmp/retry_queue.txt; > /tmp/retry_queue.txt; wrapper_invoke "heal"; registry_feedback; }

ai_feedback(){ jq -n --arg n "$(hostname)" --arg s "active" --argjson u "$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)" '{"node":$n,"status":$s,"uptime":$u,"timestamp":(now|todate)}' | curl -s -X POST -H "Content-Type: application/json" -d @- "$META_REASONER_URL/feedback"; }

checkpoint(){ echo "$(date) | Tasks: $(wc -l < /tmp/task_list.txt 2>/dev/null)" >> /var/log/vortexhub_checkpoint.log; cp /tmp/task_list.txt /var/vortexhub/last_task_snapshot.txt 2>/dev/null || true; }

network_resilience(){ ping -c1 api.vortexhub.app >/dev/null 2>&1 || OFFLINE_MODE=true; }

upload_chunk(){ local P="$1" R="$2"; if command -v rclone >/dev/null 2>&1; then log "[UPLOAD] rclone $P -> $RCLONE_REMOTE/$R"; rclone copyto "$P" "$RCLONE_REMOTE/$R" --transfers=4 --checkers=8 --s3-chunk-size=64M; return $?; fi; [ -n "$PRESIGNED_UPLOAD_URL" ] && curl -s -X PUT -T "$P" "$PRESIGNED_UPLOAD_URL" && return 0; log "[WARN] No upload method"; return 2; }

ws_send_telemetry(){ local p="$1"; if command -v websocat >/dev/null 2>&1 && [ -n "$WS_MONITOR_URL" ]; then echo "$p" | websocat -1 "$WS_MONITOR_URL" >/dev/null 2>&1; else echo "$p" | curl -s -X POST -H "Content-Type: application/json" -d @- "$TELEMETRY_URL/stream" >/dev/null 2>&1; fi; }

start_local_monitor(){ [ -f /home/pi/vortex/monitor/monitor.py ] && (cd /home/pi/vortex/monitor && nohup python3 monitor.py >/var/log/vortex_local_monitor.log 2>&1 &); }

main_loop(){ log "[SCHEDULER] Start loop..."; local i=0; while true; do ((i++)); log "---- Loop #$i ----"; network_resilience; load_manifests || { log "[ERROR] Manifest load failed"; sleep 120; continue; }; local T ID U S; T=$(select_task); ID=$(echo "$T" | awk '{print $1}'); U=$(echo "$T" | awk '{print $3}'); S=$(echo "$T" | awk '{print $4}'); [ -n "$ID" ] && run_task "$ID" "$U" "$S"; self_heal; ai_feedback; checkpoint; log "[LOOP] Sleep 60s..."; sleep 60; done; }

post_loop_intelligence(){ local uptime_sec=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0); local meta=$(jq -n --arg host "$(hostname)" --argjson u "$uptime_sec" '{"node":$host,"uptime":$u,"entropy":"'${VX_MANIFEST_SEED}'"}'); ws_send_telemetry "$meta"; log "[META] Hybrid intelligence snapshot sent."; }

startup(){ [ -f "$LOCK_FILE" ] && { log "[WARN] Already running."; exit 0; }; echo $$ > "$LOCK_FILE"; trap 'rm -f "$LOCK_FILE"; log "Lock removed"; post_loop_intelligence' EXIT; sandbox_detect; sandbox_override; check_environment; start_local_monitor; main_loop; }

startup
# ============================================================
# END OF UNIVERSAL ORCHESTRATOR v0.5-HYBRID-FUSION
# ============================================================


