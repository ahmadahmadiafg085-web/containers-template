// loggingVariables.js

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const LEVELS = ['trace', 'debug', 'info', 'warn', 'error', 'fatal', 'off'];

const LEVEL_PRIORITY = {
  trace: 5,
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
  fatal: 50,
  off: 100
};

const DEFAULT_REDACT_HEADERS = [
  'authorization',
  'cookie',
  'set-cookie',
  'proxy-authorization',
  'x-api-key',
  'x-csrf-token',
  'x-xsrf-token',
  'password',
  'token',
  'secret',
  'access-token',
  'refresh-token',
  'sessionid',
  'api-key',
  'apikey',
  'authentication'
];

const DEFAULT_SKIP_METHODS = [
  'OPTIONS',
  'HEAD'
];

const DEFAULT_SKIP_PATHS = [
  '/health',
  '/metrics',
  /\.js$/i,
  /\.css$/i,
  /\.ico$/i,
  /\/favicon.ico$/,
  /^\/static\//,
  /^\/assets\//
];

const DEFAULT_LOG_FILE_OPTIONS = {
  logDir: path.join(process.cwd(), 'logs'),
  fileName: 'app.log',
  filePrefix: 'access',
  logPerDay: true,
  maxFileSizeMB: 50,
  maxBackupFiles: 10
};

const MAX_BODY_LENGTH_DEFAULT = 4096; // bytes

const HEX_CHARS = '0123456789abcdef';

const REQUEST_ID_HEADER = 'x-request-id';

const DATE_FORMATS = {
  ISO8601: 'ISO8601',
  UNIX_MS: 'unix-ms',
  SIMPLE: 'simple'
};

const USER_AGENT_HEADER = 'user-agent';

const DEFAULT_OPTIONS = {
  logLevel: 'debug',
  logDir: DEFAULT_LOG_FILE_OPTIONS.logDir,
  logPerDay: DEFAULT_LOG_FILE_OPTIONS.logPerDay,
  console: true,
  file: true,
  filePrefix: DEFAULT_LOG_FILE_OPTIONS.filePrefix,
  fileName: DEFAULT_LOG_FILE_OPTIONS.fileName,
  maxBodyLength: MAX_BODY_LENGTH_DEFAULT,
  logRequestBody: true,
  logResponseBody: true,
  redactHeaders: DEFAULT_REDACT_HEADERS,
  requestIdHeader: REQUEST_ID_HEADER,
  logOnErrorLevel: 'error',
  sampleRate: 1.0,
  skipPaths: DEFAULT_SKIP_PATHS,
  skipMethods: DEFAULT_SKIP_METHODS,
  trackUserAgent: true,
  trackIp: true,
  env: process.env.NODE_ENV || 'development',
  serviceName: 'node-service',
  dateFormat: DATE_FORMATS.ISO8601,
  maxFileSizeBytes: DEFAULT_LOG_FILE_OPTIONS.maxFileSizeMB * 1024 * 1024,
  maxBackupFiles: DEFAULT_LOG_FILE_OPTIONS.maxBackupFiles,
  enableFileRotation: true,
  traceBodyOnErrorOnly: false,
  maxLogLineLength: 16384,
  logFormatJson: true,
  enableVerboseErrors: false,
  enableLatencyHistogram: false,
  enableAsyncLogging: true,
  logQueueMaxSize: 10000,
  logFlushIntervalMs: 1000,
  maxConcurrentLogWriters: 5,
  ipHeadersPriority: [
    'x-forwarded-for',
    'x-real-ip',
    'cf-connecting-ip',
    'fastly-client-ip',
    'true-client-ip',
    'x-client-ip',
    'x-cluster-client-ip',
    'x-forwarded',
    'forwarded-for',
    'forwarded'
  ],
  omitPaths: [
    /^\/favicon.ico$/,
    /^\/robots.txt$/,
    /^\/healthz$/,
    /^\/ping$/
  ],
  logFormatters: {
    request: (req) => ({
      method: req.method,
      url: req.originalUrl || req.url,
      headers: redactHeaders(req.headers, DEFAULT_REDACT_HEADERS),
      query: req.query,
      body: req.body
    }),
    response: (res) => ({
      statusCode: res.statusCode,
      headers: redactHeaders(res.getHeaders(), DEFAULT_REDACT_HEADERS)
    }),
    error: (error) => ({
      message: error.message,
      stack: error.stack
    })
  }
};

function redactHeaders(headers = {}, keysToRedact = DEFAULT_REDACT_HEADERS) {
  if (!headers) return {};
  const normalizedKeys = keysToRedact.map(k => k.toLowerCase());
  const redacted = {};
  Object.entries(headers).forEach(([key, val]) => {
    if (normalizedKeys.includes(key.toLowerCase())) {
      redacted[key] = '[REDACTED]';
    } else {
      redacted[key] = val;
    }
  });
  return redacted;
}

const LOG_EVENT_TYPES = {
  HTTP_START: 'http-start',
  HTTP_ACCESS: 'http-access',
  HTTP_ERROR: 'http-error',
  HTTP_ABORT: 'http-abort',
  HTTP_RESPONSE: 'http-response',
  HTTP_REQUEST: 'http-request',
  TRANSPORT_ERROR: 'transport-error',
  SYSTEM_EVENT: 'system-event',
  CUSTOM_EVENT: 'custom-event'
};

const ERROR_LEVELS = ['error', 'fatal'];

const LOG_STORAGE_MODES = {
  CONSOLE: 'console',
  FILE: 'file',
  BOTH: 'both',
  NONE: 'none'
};

const MAX_RETRY_ATTEMPTS = 5;

const RETRY_BACKOFF_BASE_MS = 100; // base for exponential backoff

const TRACE_ID_LENGTH = 24;

const HEX_RADIX = 16;

const DEFAULT_LOG_ROTATION_OPTIONS = {
  maxFileSizeBytes: 50 * 1024 * 1024, // 50MB
  maxBackupFiles: 10,
  backupFileExt: '.backup',
  rotateOnStart: false
};

const LOG_LINE_MAX_LENGTH = 32768;

const LOG_QUEUE_CAPACITY = 10000;

const DEFAULT_LOG_FLUSH_INTERVAL_MS = 500;

const MAX_METADATA_LENGTH = 1024;

const LOG_INDENT_SPACES = 2;

const LOG_ENCODING = 'utf-8';

const DEFAULT_USER_AGENT_HEADER = USER_AGENT_HEADER;

const DEFAULT_IP_SOURCES = [
  'x-forwarded-for',
  'x-real-ip',
  'x-client-ip',
  'x-forwarded',
  'forwarded-for',
  'forwarded',
  'remote_addr',
  'remote_address'
];

const HTTP_METHODS = [
  'GET',
  'POST',
  'PUT',
  'PATCH',
  'DELETE',
  'OPTIONS',
  'HEAD',
  'TRACE',
  'CONNECT'
];

const STATUS_CODE_CLASS = {
  INFORMATIONAL: 'informational',
  SUCCESSFUL: 'successful',
  REDIRECTION: 'redirection',
  CLIENT_ERROR: 'client_error',
  SERVER_ERROR: 'server_error'
};

const LOG_LEVEL_COLOR_CODES = {
  trace: '\x1b[34m',    // Blue
  debug: '\x1b[36m',    // Cyan
  info: '\x1b[32m',     // Green
  warn: '\x1b[33m',     // Yellow
  error: '\x1b[31m',    // Red
  fatal: '\x1b[35m',    // Magenta
  reset: '\x1b[0m'
};

const HTTP_PROTOCOLS = {
  HTTP_1_0: 'HTTP/1.0',
  HTTP_1_1: 'HTTP/1.1',
  HTTP_2_0: 'HTTP/2.0',
  HTTP_3_0: 'HTTP/3.0',
  WS: 'WS',
  WSS: 'WSS'
};

const HTTP_STATUS_DESCRIPTIONS = {
  100: 'Continue',
  101: 'Switching Protocols',
  102: 'Processing',
  200: 'OK',
  201: 'Created',
  202: 'Accepted',
  203: 'Non-authoritative Information',
  204: 'No Content',
  205: 'Reset Content',
  206: 'Partial Content',
  300: 'Multiple Choices',
  301: 'Moved Permanently',
  302: 'Found',
  303: 'See Other',
  304: 'Not Modified',
  305: 'Use Proxy',
  307: 'Temporary Redirect',
  400: 'Bad Request',
  401: 'Unauthorized',
  402: 'Payment Required',
  403: 'Forbidden',
  404: 'Not Found',
  405: 'Method Not Allowed',
  406: 'Not Acceptable',
  407: 'Proxy Authentication Required',
  408: 'Request Timeout',
  409: 'Conflict',
  410: 'Gone',
  411: 'Length Required',
  412: 'Precondition Failed',
  413: 'Payload Too Large',
  414: 'URI Too Long',
  415: 'Unsupported Media Type',
  416: 'Range Not Satisfiable',
  417: 'Expectation Failed',
  426: 'Upgrade Required',
  500: 'Internal Server Error',
  501: 'Not Implemented',
  502: 'Bad Gateway',
  503: 'Service Unavailable',
  504: 'Gateway Timeout',
  505: 'HTTP Version Not Supported'
};

const COMMON_HEADERS = {
  CONTENT_TYPE: 'content-type',
  CONTENT_LENGTH: 'content-length',
  ACCEPT: 'accept',
  AUTHORIZATION: 'authorization',
  COOKIE: 'cookie',
  SET_COOKIE: 'set-cookie',
  USER_AGENT: 'user-agent',
  REFERER: 'referer',
  HOST: 'host',
  CONNECTION: 'connection',
  CACHE_CONTROL: 'cache-control'
};

const SUPPORTED_CONTENT_TYPES = {
  JSON: 'application/json',
  FORM_URLENCODED: 'application/x-www-form-urlencoded',
  MULTIPART_FORM_DATA: 'multipart/form-data',
  TEXT_PLAIN: 'text/plain',
  OCTET_STREAM: 'application/octet-stream',
  HTML: 'text/html'
};

const MAX_HEADER_VALUE_LENGTH = 4096;

const LOG_MESSAGE_PREFIXES = {
  START: 'start',
  END: 'end',
  ERROR: 'error',
  WARN: 'warn',
  INFO: 'info',
  DEBUG: 'debug',
  TRACE: 'trace'
};

const DEFAULT_LOG_FILTERS = [];

const DEFAULT_EXCLUDED_PATH_PATTERNS = [/^\/status$/, /^\/health$/, /^\/metrics$/];

const IP_REGEX = /(\d{1,3}\.){3}\d{1,3}/;

const DATE_LOCALE = 'en-US';

const MAX_HEADER_COUNT = 200;

const SELF_GENERATED_REQUEST_ID_PREFIX = 'sg-';

const DEFAULT_COOKIE_REDACTION = true;

const DEFAULT_LOG_ROTATE_CHECK_INTERVAL_MS = 60000;

const MIME_TYPE_PATTERNS = {
  JSON: /^application\/json(;.*)?$/,
  XML: /^application\/xml(;.*)?$/,
  HTML: /^text\/html(;.*)?$/,
  JAVASCRIPT: /^application\/javascript(;.*)?$/,
  CSS: /^text\/css(;.*)?$/,
  PLAIN_TEXT: /^text\/plain(;.*)?$/
};

const DEFAULT_LOG_ENCODING = 'utf-8';

const MAX_REASONABLE_LOG_LENGTH = 100000;

const LOG_QUEUE_SIZE_LIMIT = 15000;

const MAX_LOG_EVENT_SIZE_BYTES = 1048576; // 1MB

const LOG_EVENT_PROPERTY_BLACKLIST = [
  'password',
  'authorization',
  'cookie',
  'set-cookie',
  'credentials',
  'secret',
  'token',
  'access_token',
  'refresh_token',
  'apikey',
  'api_key',
  'sessionid',
  'session_id'
];

const CARGO_SAFE_BLACKLIST_PREFIXES = [
  'x-',
  'cf-',
  'fastly-',
  'true-',
  'via-'
];

const LOG_ROTATION_METHODS = {
  SIZE_BASED: 'size-based',
  TIME_BASED: 'time-based',
  NONE: 'none'
};

module.exports = {
  LEVELS,
  LEVEL_PRIORITY,
  DEFAULT_REDACT_HEADERS,
  DEFAULT_SKIP_METHODS,
  DEFAULT_SKIP_PATHS,
  DEFAULT_LOG_FILE_OPTIONS,
  MAX_BODY_LENGTH_DEFAULT,
  HEX_CHARS,
  REQUEST_ID_HEADER,
  DATE_FORMATS,
  USER_AGENT_HEADER,
  DEFAULT_OPTIONS,
  redactHeaders,
  LOG_EVENT_TYPES,
  ERROR_LEVELS,
  LOG_STORAGE_MODES,
  MAX_RETRY_ATTEMPTS,
  RETRY_BACKOFF_BASE_MS,
  TRACE_ID_LENGTH,
  HEX_RADIX,
  DEFAULT_LOG_ROTATION_OPTIONS,
  LOG_LINE_MAX_LENGTH,
  LOG_QUEUE_CAPACITY,
  DEFAULT_LOG_FLUSH_INTERVAL_MS,
  MAX_METADATA_LENGTH,
  LOG_INDENT_SPACES,
  LOG_ENCODING,
  DEFAULT_USER_AGENT_HEADER,
  DEFAULT_IP_SOURCES,
  HTTP_METHODS,
  STATUS_CODE_CLASS,
  LOG_LEVEL_COLOR_CODES,
  HTTP_PROTOCOLS,
  HTTP_STATUS_DESCRIPTIONS,
  COMMON_HEADERS,
  SUPPORTED_CONTENT_TYPES,
  MAX_HEADER_VALUE_LENGTH,
  LOG_MESSAGE_PREFIXES,
  DEFAULT_LOG_FILTERS,
  DEFAULT_EXCLUDED_PATH_PATTERNS,
  IP_REGEX,
  DATE_LOCALE,
  MAX_HEADER_COUNT,
  SELF_GENERATED_REQUEST_ID_PREFIX,
  DEFAULT_COOKIE_REDACTION,
  DEFAULT_LOG_ROTATE_CHECK_INTERVAL_MS,
  MIME_TYPE_PATTERNS,
  DEFAULT_LOG_ENCODING,
  MAX_REASONABLE_LOG_LENGTH,
  LOG_QUEUE_SIZE_LIMIT,
  MAX_LOG_EVENT_SIZE_BYTES,
  LOG_EVENT_PROPERTY_BLACKLIST,
  CARGO_SAFE_BLACKLIST_PREFIXES,
  LOG_ROTATION_METHODS
};
