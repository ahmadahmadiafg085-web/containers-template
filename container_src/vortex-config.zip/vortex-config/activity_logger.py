# activity_logger.py
import asyncio, aiohttp, json, logging, time, uuid, random, sqlite3
from typing import Dict, Any, Callable
import redis.asyncio as redis

logging.basicConfig(level=logging.INFO, format=‘[%(levelname)s] %(asctime)s - %(message)s’)

def generate_uuid() -> str: return str(uuid.uuid4())
def timestamp() -> str: return time.strftime(“%Y-%m-%d %H:%M:%S”)

# ======= Event Trigger System =======
class BaseTrigger:
    def __init__(self, name: str, condition: Callable[[dict], bool], action: Callable[[dict], asyncio.Future]):
        self.name = name
        self.condition = condition
        self.action = action

    async def check_fire(self, event: dict):
        try:
            if self.condition(event):
                await self.action(event)
        except Exception as e:
            logging.error(f”[TRIGGER ERROR][{self.name}] {e}”)

class TriggerManager:
    def __init__(self, parent):
        self.parent = parent
        self.triggers: Dict[str, BaseTrigger] = {}
        self.queue = asyncio.Queue()
        self.running = False

    def register(self, trigger: BaseTrigger):
        self.triggers[trigger.name] = trigger
        logging.info(f”[TRIGGER REGISTERED] {trigger.name}”)

    async def emit(self, event_name: str, payload: dict):
        await self.queue.put({“event”: event_name, “data”: payload})

    async def run(self):
        self.running = True
        while self.running:
            event = await self.queue.get()
            for t in self.triggers.values():
                await t.check_fire(event)

    def stop(self):
        self.running = False

# ======= Webhook Sender with Retry =======
class WebhookSender:
    def __init__(self, proxies: list = None):
        self.proxies = proxies or []

    async def send(self, urls: list, payload: dict, retries=5, delay=1):
        for url in urls:
            attempt = 0
            backoff = delay
            while attempt < retries:
                try:
                    proxy = self.proxies.pop(0) if self.proxies else None
                    async with aiohttp.ClientSession() as session:
                        opts = {“json”: payload, “timeout”: aiohttp.ClientTimeout(total=8)}
                        if proxy: opts[“proxy”] = proxy
                        async with session.post(url, **opts) as resp:
                            if resp.status == 200:
                                logging.info(f”[WEBHOOK SUCCESS] {url}”)
                                return True
                except Exception as e:
                    logging.warning(f”[WEBHOOK FAIL] {url} attempt {attempt+1}: {e}”)
                attempt += 1
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
        return False

# ======= Activity Logger Core =======
class ActivityLogger:
    def __init__(self, redis_url=“redis://localhost:6379”, db_path=“activity_logs.db”):
        self.lock = asyncio.Lock()
        self.shutdown = asyncio.Event()
        self.queue_name = “activity_queue”
        self.redis = redis.Redis.from_url(redis_url)
        self.pubsub = redis.Redis.from_url(redis_url)
        self.triggers = TriggerManager(self)
        self.sender = WebhookSender()
        self.webhook_interval = 0.02
        self.fail_score: Dict[str, int] = {}
        self._init_db(db_path)

    # ======= DB Logging =======
    def _init_db(self, path):
        self.conn = sqlite3.connect(path)
        c = self.conn.cursor()
        c.execute(‘’’CREATE TABLE IF NOT EXISTS activity_logs
                     (id TEXT PRIMARY KEY, source TEXT, event TEXT, payload TEXT, status TEXT, timestamp TEXT)’’’)
        self.conn.commit()

    def _log_activity(self, source: str, event: str, payload: dict, status: str):
        c = self.conn.cursor()
        c.execute(‘INSERT INTO activity_logs VALUES (?, ?, ?, ?, ?, ?)’,
                  (payload.get(“_id”, generate_uuid()), source, event, json.dumps(payload), status, timestamp()))
        self.conn.commit()

    # ======= Event Logging =======
    async def log_event(self, source: str, event_name: str, payload: dict, webhook_urls: list = None):
        payload[“_id”] = generate_uuid()
        payload[“_timestamp”] = timestamp()
        payload[“_source”] = source
        await self.redis.zadd(self.queue_name, {json.dumps({“source”: source, “event”: event_name, “payload”: payload, “webhooks”: webhook_urls or []}): 50})

    async def process_queue(self, batch=5):
        while not self.shutdown.is_set():
            items = await self.redis.zrange(self.queue_name, 0, batch - 1)
            if items:
                for raw in items:
                    try:
                        obj = json.loads(raw)
                        success = await self.sender.send(obj.get(“webhooks”, []), obj[“payload”])
                        self._log_activity(obj[“source”], obj[“event”], obj[“payload”], “success” if success else “fail”)
                        if not success:
                            self.fail_score[obj[“source”]] = self.fail_score.get(obj[“source”], 0) + 1
                    except Exception as e:
                        logging.error(f”[QUEUE ERROR] {e}”)
                await self.redis.zremrangebyrank(self.queue_name, 0, batch - 1)
            await asyncio.sleep(self.webhook_interval)

    # ======= Self-Healing =======
    async def self_heal(self):
        async with self.lock:
            logging.info(“[SELF-HEAL] Resetting fail scores”)
            self.fail_score = {}

    # ======= Pub/Sub =======
    async def pubsub_publish(self, channel: str, msg: dict):
        await self.pubsub.publish(channel, json.dumps(msg))

    async def subscribe(self, channel: str, cb: Callable[[dict], None]):
        sub = self.pubsub.pubsub()
        await sub.subscribe(channel)
        async for message in sub.listen():
            if message[‘type’] == ‘message’:
                cb(json.loads(message[‘data’]))

    def stop(self):
        self.shutdown.set()

# ======= Example Triggers =======
async def action_log_event(event):
    logging.info(f”[TRIGGER LOG] Event from {event[‘_source’]}: {event[‘data’]}”)

def condition_event_type(event_type: str):
    return lambda e: e.get(“event”) == event_type

def build_default_triggers(logger: ActivityLogger):
    tm = logger.triggers
    tm.register(BaseTrigger(“log_all_events”, lambda e: True, action_log_event))

# ======= Example Activity =======
async def example_activity(logger: ActivityLogger):
    for i in range(5):
        payload = {“action”: f”test_action_{i}”, “value”: i * 10}
        await logger.log_event(“example_module”, f”test_event_{i}”, payload, webhook_urls=[“http://localhost:8000/webhook”])
        await asyncio.sleep(1)

# ======= Main =======
async def main():
    logger = ActivityLogger()
    build_default_triggers(logger)
    asyncio.create_task(logger.triggers.run())
    asyncio.create_task(logger.process_queue())
    asyncio.create_task(example_activity(logger))
    try:
        while True: await asyncio.sleep(3600)
    except KeyboardInterrupt:
        logger.stop()

if __name__ == “__main__”:
    asyncio.run(main())