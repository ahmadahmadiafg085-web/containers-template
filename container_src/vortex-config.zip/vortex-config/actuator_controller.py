# actuator_controller.py
import asyncio, aiohttp, json, logging, time, uuid, sqlite3, random
from typing import Dict, Any, Callable, List
import redis.asyncio as redis

logging.basicConfig(level=logging.INFO, format=‘[%(levelname)s] %(asctime)s - %(message)s’)

def generate_uuid() -> str: return str(uuid.uuid4())
def timestamp() -> str: return time.strftime(“%Y-%m-%d %H:%M:%S”)

# ======= Base Trigger System =======
class BaseTrigger:
    def __init__(self, name: str, condition: Callable[[dict], bool], action: Callable[[dict], asyncio.Future]):
        self.name = name
        self.condition = condition
        self.action = action

    async def check_fire(self, event: dict):
        try:
            if self.condition(event):
                await self.action(event)
        except Exception as e:
            logging.error(f”[TRIGGER ERROR][{self.name}] {e}”)

class TriggerManager:
    def __init__(self, parent):
        self.parent = parent
        self.triggers: Dict[str, BaseTrigger] = {}
        self.queue = asyncio.Queue()
        self.running = False

    def register(self, trigger: BaseTrigger):
        self.triggers[trigger.name] = trigger
        logging.info(f”[TRIGGER REGISTERED] {trigger.name}”)

    async def emit(self, event_name: str, payload: dict):
        await self.queue.put({“event”: event_name, “data”: payload})

    async def run(self):
        self.running = True
        while self.running:
            event = await self.queue.get()
            for t in self.triggers.values():
                await t.check_fire(event)

    def stop(self):
        self.running = False

# ======= Webhook / HTTP Sender =======
class WebhookSender:
    def __init__(self, proxies: List[str] = None):
        self.proxies = proxies or []

    async def send(self, urls: List[str], payload: dict, retries=5, delay=1):
        for url in urls:
            attempt = 0
            backoff = delay
            while attempt < retries:
                try:
                    proxy = self.proxies.pop(0) if self.proxies else None
                    async with aiohttp.ClientSession() as session:
                        opts = {“json”: payload, “timeout”: aiohttp.ClientTimeout(total=8)}
                        if proxy: opts[“proxy”] = proxy
                        async with session.post(url, **opts) as resp:
                            if resp.status == 200:
                                logging.info(f”[WEBHOOK SUCCESS] {url}”)
                                return True
                except Exception as e:
                    logging.warning(f”[WEBHOOK FAIL] {url} attempt {attempt+1}: {e}”)
                attempt += 1
                await asyncio.sleep(backoff)
                backoff = min(backoff*2, 30)
        return False

# ======= Actuator Controller Core =======
class ActuatorController:
    def __init__(self, redis_url=“redis://localhost:6379”, db_path=“actuator_controller.db”):
        self.lock = asyncio.Lock()
        self.shutdown = asyncio.Event()
        self.redis = redis.Redis.from_url(redis_url)
        self.pubsub = redis.Redis.from_url(redis_url)
        self.triggers = TriggerManager(self)
        self.sender = WebhookSender()
        self.fail_score: Dict[str, int] = {}
        self.webhook_interval = 0.02
        self.queue_name = “controller_queue”
        self.actuators: Dict[str, dict] = {}  # actuator metadata
        self._init_db(db_path)

    # ======= DB Logging =======
    def _init_db(self, path):
        self.conn = sqlite3.connect(path)
        c = self.conn.cursor()
        c.execute(‘’’CREATE TABLE IF NOT EXISTS actuator_logs
                     (id TEXT PRIMARY KEY, actuator TEXT, command TEXT, payload TEXT, status TEXT, timestamp TEXT)’’’)
        self.conn.commit()

    def _log_actuator(self, actuator: str, command: str, payload: dict, status: str):
        c = self.conn.cursor()
        c.execute(‘INSERT INTO actuator_logs VALUES (?, ?, ?, ?, ?, ?)’,
                  (payload.get(“_id”, generate_uuid()), actuator, command, json.dumps(payload), status, timestamp()))
        self.conn.commit()

    # ======= Actuator Management =======
    async def register_actuator(self, name: str, control_urls: List[str]):
        self.actuators[name] = {“control_urls”: control_urls, “status”: “idle”, “history”: []}
        logging.info(f”[ACTUATOR REGISTERED] {name}”)

    async def send_command(self, actuator_name: str, command: str, payload: dict):
        if actuator_name not in self.actuators:
            logging.error(f”[ACTUATOR NOT FOUND] {actuator_name}”)
            return
        actuator = self.actuators[actuator_name]
        payload[“_id”] = generate_uuid()
        payload[“_timestamp”] = timestamp()
        payload[“_command”] = command
        payload[“_actuator”] = actuator_name
        await self.redis.zadd(self.queue_name, {json.dumps({“actuator”: actuator_name, “command”: command, “payload”: payload, “urls”: actuator[“control_urls”]}): 50})

    # ======= Queue Processor =======
    async def process_queue(self, batch=5):
        while not self.shutdown.is_set():
            items = await self.redis.zrange(self.queue_name, 0, batch - 1)
            if items:
                for raw in items:
                    try:
                        obj = json.loads(raw)
                        success = await self.sender.send(obj.get(“urls”, []), obj[“payload”])
                        self._log_actuator(obj[“actuator”], obj[“command”], obj[“payload”], “success” if success else “fail”)
                        if not success:
                            self.fail_score[obj[“actuator”]] = self.fail_score.get(obj[“actuator”], 0) + 1
                    except Exception as e:
                        logging.error(f”[QUEUE ERROR] {e}”)
                await self.redis.zremrangebyrank(self.queue_name, 0, batch - 1)
            await asyncio.sleep(self.webhook_interval)

    # ======= Self-Healing =======
    async def self_heal(self):
        async with self.lock:
            logging.info(“[SELF-HEAL] Resetting fail scores”)
            self.fail_score = {}

    # ======= Pub/Sub =======
    async def pubsub_publish(self, channel: str, msg: dict):
        await self.pubsub.publish(channel, json.dumps(msg))

    async def subscribe(self, channel: str, cb: Callable[[dict], None]):
        sub = self.pubsub.pubsub()
        await sub.subscribe(channel)
        async for message in sub.listen():
            if message[‘type’] == ‘message’:
                cb(json.loads(message[‘data’]))

    def stop(self):
        self.shutdown.set()

# ======= Default Triggers =======
async def trigger_log_command(event):
    logging.info(f”[TRIGGER LOG] Actuator {event[‘_actuator’]} command executed: {event[‘data’]}”)

def build_default_triggers(controller: ActuatorController):
    controller.triggers.register(BaseTrigger(“log_all_commands”, lambda e: True, trigger_log_command))

# ======= Example Usage =======
async def example_usage(controller: ActuatorController):
    await controller.register_actuator(“pump_1”, [“http://localhost:8000/actuator”])
    for i in range(5):
        payload = {“param”: i*10, “mode”: “auto”}
        await controller.send_command(“pump_1”, f”start_pump_{i}”, payload)
        await asyncio.sleep(1)

# ======= Main =======
async def main():
    controller = ActuatorController()
    build_default_triggers(controller)
    asyncio.create_task(controller.triggers.run())
    asyncio.create_task(controller.process_queue())
    asyncio.create_task(example_usage(controller))
    try:
        while True:
            await asyncio.sleep(3600)
    except KeyboardInterrupt:
        controller.stop()

if __name__ == “__main__”:
    asyncio.run(main())