# ================== discord_orchestrated_adapter_full.py ==================
import discord, asyncio, logging, traceback, time, random, resource, importlib, subprocess, json, base64
from typing import Dict, List, Callable, Optional, Any
from pathlib import Path
from datetime import datetime
from ctypes import cdll

# ================== Logger ==================
logger = logging.getLogger(“DiscordAdapter”)
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler())

# ================== Internal Adapter ==================
class DistributedInternalToAdminAdapter:
    def __init__(self, service=None, language=“en”, node=“local”):
        self.s, self.lang, self.node = service, language, node
        self.cache, self.permissions, self.events, self.metrics = {}, {}, {}, {}
        self.trace_enabled = True
        self.policy = {“allow”: set(), “deny”: set(), “rate_limits”: {}, “signatures”: {}}

    def check_permission(self, role, action) -> bool:
        if role in self.permissions and action in self.permissions[role]: 
            return True
        logger.warning(f”[Permission Denied] {role}:{action}”)
        return False

    async def publish_event(self, event_type: str, payload: dict):
        for cb in self.events.get(event_type, []):
            if asyncio.iscoroutinefunction(cb): 
                await cb(payload)
            else: 
                await asyncio.to_thread(cb, payload)

    def on_event(self, event_type: str, callback: Callable): 
        self.events.setdefault(event_type, []).append(callback)

    async def record_execution(self, module_name, record):
        self.metrics.setdefault(module_name, []).append(record.get(“timestamp”, datetime.utcnow().isoformat()))
        await self.publish_event(“module_executed”, {“module”: module_name, “record”: record})

    def _cget(self, key: str, expire: int = 120): 
        v = self.cache.get(key)
        return None if not v or time.time()-v[“t”]>expire else v[“v”]

    def _cset(self, key: str, value: Any): 
        self.cache[key] = {“v”: value, “t”: time.time()}

# ================== Loader Adapter ==================
class LoaderToAdminAdapter:
    def __init__(self, base: str, admin: DistributedInternalToAdminAdapter, node_id=None):
        self.base, self.admin, self.node = Path(base), admin, node_id or “local”
        self.lazy, self.reg, self.hooks, self.metrics, self.cache, self.tc = {}, {}, {}, {}, {}, {}
        self.cache_exp, self.trace_enabled = 120, True
        self.lock = asyncio.Lock()
        self.policy = admin.policy
        self._register_modules(); self._assign_priorities(); self._build_dependency_graph()

    def _hash_file(self, p: Path) -> str:
        import hashlib
        h = hashlib.sha256()
        try: 
            with p.open(“rb”) as f: 
                for c in iter(lambda: f.read(4096), b””): 
                    h.update(c)
            return h.hexdigest()
        except: 
            return “0”*64

    def _register_modules(self):
        for p in (self.base / “loader_modules”).glob(“**/*”):
            if p.suffix in [“.py”,”.js”,”.ts”,”.wasm”,”.so”,”.dll”,”.whl”]:
                n = “.”.join(p.relative_to(self.base).with_suffix(“”).parts)
                self.lazy[n] = None
                self.reg[n] = {“path”: p,”type”:p.suffix,”loaded”:False,”checksum”:self._hash_file(p),
                               “dependencies”:[],”priority”:0,”version”:None,”healthy”:True}
                self.hooks[n] = {“pre”:[],”post”:[]}

    def _assign_priorities(self):
        for m in self.reg.values():
            m[“priority”]=10 if m[“type”]==“.py” else 6 if m[“type”] in [“.js”,”.ts”] else 4 if m[“type”]==“.wasm” else 2

    def _build_dependency_graph(self):
        for m in self.reg.values(): 
            m[“dependencies”]=m.get(“dependencies”,[])

    def _sandbox(self, fn,*a,**k):
        try:
            resource.setrlimit(resource.RLIMIT_CPU,(2,2))
            resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
            return fn(*a,**k)
        except Exception as e: 
            logger.error(f”[Sandbox Error] {e}”)
            return {“sandbox_error”:str(e)}

    def _policy_check(self,module,func):
        if module in self.policy.get(“deny”,[]): raise PermissionError(“denied”)
        if self.policy.get(“allow”) and module not in self.policy[“allow”]: raise PermissionError(“blocked”)
        rl=self.policy.get(“rate_limits”,{}).get(module)
        if rl: 
            rl[“count”]=rl.get(“count”,0)+1
            if rl.get(“max”) and rl[“count”]>rl.get(“max”,0):
                raise RuntimeError(“rate_limit_exceeded”)

    def _signature_check(self,module):
        sig=self.policy.get(“signatures”,{}).get(module)
        if sig and self.reg[module][“checksum”]!=sig: 
            raise ValueError(“tampered”)

    def _trace_start(self,module,func):
        if not self.trace_enabled: return None
        tid=f”{time.time()}-{random.randint(1000,9999)}”
        self.tc[tid]={“module”:module,”func”:func,”start”:datetime.utcnow().isoformat()}
        return tid

    def _trace_end(self,tid,res): 
        if tid in self.tc: 
            self.tc[tid].update({“end”:datetime.utcnow().isoformat(),”res”:str(res)[:200]})

    def _cache_get(self,key): 
        v=self.cache.get(key)
        return None if not v or time.time()-v[“t”]>self.cache_exp else v[“v”]

    def _cache_set(self,key,val): 
        self.cache[key]={“v”:val,”t”:time.time()}

    def load_module(self,name:str,force=False):
        if name not in self.lazy: raise ValueError(f”Module {name} not registered”)
        m, ext = self.reg[name], self.reg[name][“type”]
        if self.lazy[name] is None or force:
            try:
                # — Pre-hooks —
                for h in self.hooks[name][“pre”]: h(name)
                # — Load dependencies —
                for d in m.get(“dependencies”,[]): self.load_module(d,force)
                # — Load module —
                if ext==“.py”: self.lazy[name]=importlib.reload(self.lazy[name]) if force else importlib.import_module(name)
                elif ext in [“.so”,”.dll”]: self.lazy[name]=cdll.LoadLibrary(str(m[“path”]))
                elif ext in [“.js”,”.ts”]: subprocess.run([“node”,str(m[“path”])],check=True)
                # — Post-hooks —
                for h in self.hooks[name][“post”]: h(name)
                # — Update metadata —
                m.update({“loaded”:True,”version”:datetime.utcnow().isoformat(),”last_code”:m[“path”].read_text()})
            except Exception as e: 
                m[“healthy”]=False
                logger.error(f”[Module Load Error] {name}: {e}”)
        return self.lazy[name]

    async def run(self,module,func,*a,timeout=None,retries=0,cache=False,sandbox=True,**k):
        async with self.lock:
            self._policy_check(module,func)
            self._signature_check(module)
            key=f”{module}:{func}:{a}:{k}”
            if cache: 
                cv=self._cache_get(key)
                if cv is not None: return cv
            mod=self.load_module(module)
            fn=getattr(mod,func,None)
            if not callable(fn): return None
            start, att, res = datetime.utcnow(), 0, None
            runner=self._sandbox if sandbox else lambda f,*x,**y:f(*x,**y)
            tid=self._trace_start(module,func)
            while att<=retries:
                try: 
                    if asyncio.iscoroutinefunction(fn): res=await asyncio.wait_for(fn(*a,**k),timeout=timeout)
                    else: res=runner(fn,*a,**k)
                    break
                except Exception as e: 
                    att+=1
                    logger.error(f”[Run Error] Module: {module}, Func: {func}, Attempt: {att}, Error: {e}”)
                    if att>retries: raise
                finally:
                    self.metrics.setdefault(f”{module}.{func}”,[]).append((datetime.utcnow()-start).total_seconds())
                    await self.admin.record_execution(f”loader_{module}_{func}”, {“args”:a,”kwargs”:k,”result”:res})
            if cache: self._cache_set(key,res)
            self._trace_end(tid,res)
            return res

    async def batch(self,evs:List[Dict[str,Any]]):
        return await asyncio.gather(*[self.run(e[“module”],e[“func”],*e.get(“args”,[]),**e.get(“kwargs”,{})) for e in evs],return_exceptions=True)
        