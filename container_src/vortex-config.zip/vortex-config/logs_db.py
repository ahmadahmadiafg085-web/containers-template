

logs_db.py – نسخه عملیاتی

import sqlite3
import datetime
import threading

class LogsDB:
    def __init__(self, db_path=“logs.db”):
        self.db_path = db_path
        self.lock = threading.Lock()
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(“””
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    message TEXT,
                    level TEXT,
                    source TEXT,
                    risk_score INTEGER,
                    metadata TEXT
                )
            “””)
            conn.commit()

    def insert_log(self, log, analysis=None):
        analysis = analysis or {}
        timestamp = log.get(“timestamp”, datetime.datetime.utcnow().isoformat())
        message = log.get(“message”, “”)
        level = log.get(“level”, “INFO”)
        source = log.get(“source”, “unknown”)
        risk_score = analysis.get(“risk_score”, 0)
        metadata = str(analysis.get(“metadata”, {}))

        with self.lock, sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(“””
                INSERT INTO logs (timestamp, message, level, source, risk_score, metadata)
                VALUES (?, ?, ?, ?, ?, ?)
            “””, (timestamp, message, level, source, risk_score, metadata))
            conn.commit()
            return cursor.lastrowid

    def fetch_logs(self, level=None, source=None, min_risk=None, limit=100):
        query = “SELECT * FROM logs WHERE 1=1”
        params = []
        if level:
            query += “ AND level=?”
            params.append(level)
        if source:
            query += “ AND source=?”
            params.append(source)
        if min_risk is not None:
            query += “ AND risk_score>=?”
            params.append(min_risk)
        query += “ ORDER BY timestamp DESC LIMIT ?”
        params.append(limit)

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
        return rows

    def generate_report(self, group_by=“level”):
        # ساده‌ترین گزارش: تعداد لاگ‌ها بر اساس سطح
        query = f”SELECT {group_by}, COUNT(*) FROM logs GROUP BY {group_by}”
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
        return {row[0]: row[1] for row in rows

نمونه استفاده با LogsDispatcher

from logs_db import LogsDB
from logs_dispatcher import LogsDispatcher

db = LogsDB()
dispatcher = LogsDispatcher(config={})

sample_logs = [
    {“message”: “User login failed”, “level”: “WARN”},
    {“message”: “File deleted unexpectedly”, “level”: “ERROR”},
]

for log in sample_logs:
    dispatcher.dispatch(log)
    # بعد از dispatch می‌توان log را در DB ذخیره کرد
    analysis = {“risk_score”: 50}  # نمونه تحلیل
    db.insert_log(log, analysis)

print(db.fetch_logs(min_risk=10))
print(db.generate_report())


