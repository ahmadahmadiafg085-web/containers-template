import time
import threading

class LowLevelTriggerController:
    def __init__(self):
        # لیست همه تریگرها
        self.triggers = []
        # Lock برای همزمانی
        self.lock = threading.Lock()
        print(“[LLC] Controller initialized”)

    # ثبت تریگر جدید
    def register_trigger(self, trigger):
        “””
        trigger = {
            “name”: “Trigger Name”,
            “type”: “simple|composite|timer|system”,
            “conditions”: [],      # برای composite
            “callback”: func,
            “timer”: 5,            # ثانیه برای timer triggers
            “system_event”: “offline|online” # برای system triggers
        }
        “””
        with self.lock:
            self.triggers.append(trigger)
        # اگر تایمر باشد، اجرای خودکار شروع شود
        if trigger.get(“type”) == “timer”:
            threading.Thread(target=self._run_timer, args=(trigger,), daemon=True).start()
        print(f”[LLC] Trigger registered: {trigger[‘name’]}”)

    # اجرای تایمر تریگر
    def _run_timer(self, trigger):
        interval = trigger.get(“timer”, 5)
        while True:
            time.sleep(interval)
            trigger[“callback”](trigger)
            print(f”[LLC] Timer Trigger fired: {trigger[‘name’]}”)

    # اجرای تریگرهای composite
    def check_composite(self, trigger):
        if all(cond.get(“active”, False) for cond in trigger.get(“conditions”, [])):
            trigger[“callback”](trigger)
            print(f”[LLC] Composite Trigger fired: {trigger[‘name’]}”)
            # Reset conditions
            for cond in trigger[“conditions”]:
                cond[“active”] = False

    # فعال‌سازی تریگر سیستم
    def system_event_trigger(self, trigger):
        # placeholder برای ادغام با سیستم واقعی
        print(f”[LLC] System Event Trigger: {trigger[‘name’]}”)

    # لیست تریگرها
    def list_triggers(self):
        with self.lock:
            return [t[“name”] for t in self.triggers]


# =========================
# مثال استفاده
# =========================
if __name__ == “__main__”:
    controller = LowLevelTriggerController()

    # مثال تریگر تایمر
    controller.register_trigger({
        “name”: “Heartbeat Timer”,
        “type”: “timer”,
        “timer”: 3,  # هر 3 ثانیه
        “callback”: lambda t: print(“[Callback] Heartbeat fired”)
    })

    # مثال تریگر composite
    composite_trigger = {
        “name”: “Composite Example”,
        “type”: “composite”,
        “conditions”: [
            {“name”: “cond1”, “active”: True},
            {“name”: “cond2”, “active”: True}
        ],
        “callback”: lambda t: print(“[Callback] Composite fired”)
    }
    controller.register_trigger(composite_trigger)

    # شبیه‌سازی loop برای اجرای composite
    while True:
        controller.check_composite(composite_trigger)
        time.sleep(1)