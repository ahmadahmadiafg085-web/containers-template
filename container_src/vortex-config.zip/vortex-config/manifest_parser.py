# manifest_parser.py
import json
import hashlib
import time
import threading
from pathlib import Path
from typing import Dict, Any, Callable, List, Optional
import requests


class ManifestError(Exception):
    pass


class CDNClient:
    “””Handles CDN failover, integrity checking, retries, and local caching.”””

    def __init__(self, sources: Dict[str, Any], cache_dir=“vh_cache”):
        self.primary = sources[“primary”]
        self.fallbacks = sources.get(“fallbacks”, [])
        self.integrity = sources.get(“integrity”, “sha256”)
        self.max_retry = sources.get(“max_retry”, 3)
        self.cache_path = Path(cache_dir)
        self.cache_path.mkdir(exist_ok=True)

    def _download(self, url: str) -> bytes:
        tries = 0
        while tries < self.max_retry:
            try:
                r = requests.get(url, timeout=5)
                if r.status_code == 200:
                    return r.content
            except Exception:
                pass
            tries += 1
        raise ManifestError(f”CDN download failed: {url}”)

    def fetch(self, url_list: List[str], expected_hash: Optional[str] = None) -> bytes:
        sources = [self.primary] + self.fallbacks

        for base in sources:
            for u in url_list:
                full = f”{base}{u}”
                try:
                    data = self._download(full)
                    if expected_hash:
                        if self._hash(data) != expected_hash:
                            raise ManifestError(“Hash mismatch”)
                    return data
                except Exception:
                    continue
        raise ManifestError(“All CDN sources failed”)

    def _hash(self, data: bytes) -> str:
        h = hashlib.new(self.integrity)
        h.update(data)
        return h.hexdigest()


class EventBus:
    “””Micro event bus for agent → parser → renderer communication.”””

    def __init__(self):
        self.listeners: Dict[str, List[Callable]] = {}

    def on(self, event: str, fn: Callable):
        self.listeners.setdefault(event, []).append(fn)

    def emit(self, event: str, payload: Any = None):
        for fn in self.listeners.get(event, []):
            fn(payload)


class ManifestParser:
    “””Core runtime that loads, verifies, resolves CDN, modules, and real-time agent reports.”””

    def __init__(self, manifest_path: str = “modules_cloud.json”):
        self.manifest_path = manifest_path
        self.data: Dict[str, Any] = {}
        self.event_bus = EventBus()
        self.cdn = None
        self.modules: Dict[str, Any] = {}
        self.agents: Dict[str, Dict[str, Any]] = {}

        self.load_manifest()
        self._start_auto_refresh()

    # -————— LOAD MANIFEST -—————
    def load_manifest(self):
        try:
            with open(self.manifest_path, “r”, encoding=“utf-8”) as f:
                self.data = json.load(f)
        except Exception as e:
            raise ManifestError(f”Manifest parse error: {e}”)

        # Initialize CDN
        self.cdn = CDNClient(self.data[“cdn_sources”])

        # Index modules
        self.modules = {m[“id”]: m for m in self.data.get(“modules”, [])}

        self.event_bus.emit(“manifest_loaded”, self.data)

    # -————— AUTO REFRESH -—————
    def _start_auto_refresh(self):
        “””Refresh manifest every 60 seconds automatically.”””
        def loop():
            last_hash = “”
            while True:
                try:
                    h = self._hash_file(self.manifest_path)
                    if h != last_hash:
                        self.load_manifest()
                        last_hash = h
                except Exception:
                    pass
                time.sleep(60)

        t = threading.Thread(target=loop, daemon=True)
        t.start()

    @staticmethod
    def _hash_file(path: str) -> str:
        data = Path(path).read_bytes()
        h = hashlib.sha256()
        h.update(data)
        return h.hexdigest()

    # -————— MODULE FETCH -—————
    def load_module(self, module_id: str) -> bytes:
        if module_id not in self.modules:
            raise ManifestError(f”Module not found: {module_id}”)

        module = self.modules[module_id]
        cdn_info = module.get(“cdn”, {})
        urls = cdn_info.get(“urls”, [])
        signature = cdn_info.get(“signature”)

        raw = self.cdn.fetch(urls, expected_hash=signature)

        self.event_bus.emit(“module_loaded”, {“id”: module_id, “size”: len(raw)})

        return raw

    # -————— RUNTIME AGENT LOGIC -—————
    def report_agent(self, agent_id: str, payload: Dict[str, Any]):
        “””Browser/Windows agent sends real-time telemetry.”””
        self.agents[agent_id] = {
            “last_update”: time.time(),
            “payload”: payload
        }
        self.event_bus.emit(“agent_report”, {“agent_id”: agent_id, “payload”: payload})

    # -————— PROTOCOL EXECUTION -—————
    def execute_protocol(self, module_id: str, protocol_name: str):
        “””Executes a module protocol — abstract enough to use WASM, Python, JS bridge.”””
        if module_id not in self.modules:
            raise ManifestError(“Module missing”)

        module = self.modules[module_id]
        proto = module.get(“protocols”, {}).get(protocol_name)

        if not proto:
            raise ManifestError(“Protocol undefined”)

        self.event_bus.emit(“protocol_exec”, {
            “module”: module_id,
            “protocol”: protocol_name
        })

        # future hook: wasm sandbox, python vm, JS engine...
        return {“status”: “executed”, “protocol”: protocol_name}

    # -————— RENDER CALLBACK -—————
    def set_render_callback(self, fn: Callable):
        “””Renderer (wasm/js/native) registers itself.”””
        self.event_bus.on(“module_loaded”, fn)
        self.event_bus.on(“manifest_loaded”, fn)
        self.event_bus.on(“agent_report”, fn)


# =================== Example ===================
if __name__ == “__main__”:
    parser = ManifestParser(“modules_cloud.json”)

    def debug(event):
        print(“[EVENT]”, event)

    parser.event_bus.on(“agent_report”, debug)

    # Simulate Windows/Browser agent
    parser.report_agent(“windows.local”, {
        “cpu”: 22,
        “ram”: 47,
        “net”: “online”,
        “latency”: “42ms”
    })

    # Load a module
    try:
        engine_bytes = parser.load_module(“financial_engine”)
        print(“Loaded module size:”, len(engine_bytes))
    except Exception as e:
        print(“Error loading:”, e)