# smart_universal_text_runtime_v2.py
import os
import re
from typing import List, Dict, Any
from pathlib import Path

# External libraries
try:
    import docx  # pip install python-docx
except ImportError:
    docx = None

try:
    import PyPDF2  # pip install PyPDF2
except ImportError:
    PyPDF2 = None

try:
    import pandas as pd  # pip install pandas openpyxl xlrd pyodbc
except ImportError:
    pd = None

try:
    from langdetect import detect, DetectorFactory  # pip install langdetect
    DetectorFactory.seed = 0
except ImportError:
    detect = None

try:
    from polyglot.text import Text  # pip install polyglot pyicu
except ImportError:
    Text = None

# ================= Text Object =================
class TextData:
    “””Smart text object, multi-lingual aware, dynamic analysis.”””
    def __init__(self, content: str, source: str = “unknown”, language: str = “unknown”):
        self.content = content
        self.source = source
        self.language = language
        self.detected_language = language
        self.lines = content.splitlines()
        self.words = content.split()
        self.length = len(content)
        self.entities: List[str] = []
        self.patterns: List[str] = []

# ================= Text Analyzer =================
class SmartTextAnalyzer:
    “””Smart analyzer: language detection, pattern extraction, entity recognition.”””
    DEFAULT_PATTERNS = [
        r”\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b”,  # emails
        r”http[s]?://[^\s]+”,                                     # URLs
        r”\b\d{2,}\b”,                                           # numbers
    ]

    def __init__(self):
        self.learned_patterns: Dict[str, int] = {}

    def detect_language(self, text: str) -> str:
        if detect:
            try:
                return detect(text)
            except:
                return “unknown”
        return “unknown”

    def extract_patterns(self, text: str) -> List[str]:
        results = []
        patterns = self.DEFAULT_PATTERNS + list(self.learned_patterns.keys())
        for pattern in patterns:
            matches = re.findall(pattern, text)
            results.extend(matches)
            for match in matches:
                self.learn_pattern(match)
        return results

    def learn_pattern(self, snippet: str):
        self.learned_patterns[snippet] = self.learned_patterns.get(snippet, 0) + 1

    def extract_entities(self, text: str) -> List[str]:
        if Text:
            try:
                poly_text = Text(text)
                return [ent for ent in poly_text.entities]
            except:
                return []
        return []

    def summarize(self, text_data: TextData) -> str:
        return f”Lines: {len(text_data.lines)}, Words: {len(text_data.words)}, Length: {text_data.length}, Language: {text_data.detected_language}, Entities: {len(text_data.entities)}, Patterns: {len(text_data.patterns)}”

# ================= Text Loader =================
class SmartTextLoader:
    “””Load text from multiple formats (txt, md, pdf, docx, xls/xlsx, mdb/accdb), multi-lingual safe.”””
    @staticmethod
    def load(path: str) -> str:
        ext = Path(path).suffix.lower()
        content = “”
        try:
            if ext in [“.txt”, “.md”, “.csv”, “.log”, “.json”]:
                with open(path, “r”, encoding=“utf-8”, errors=“ignore”) as f:
                    content = f.read()
            elif ext == “.docx” and docx:
                doc = docx.Document(path)
                content = “\n”.join([p.text for p in doc.paragraphs])
            elif ext == “.pdf” and PyPDF2:
                with open(path, “rb”) as f:
                    reader = PyPDF2.PdfReader(f)
                    content = “\n”.join([page.extract_text() for page in reader.pages if page.extract_text()])
            elif ext in [“.xls”, “.xlsx”] and pd:
                df = pd.read_excel(path, sheet_name=None)  # read all sheets
                content = “”
                for sheet_name, sheet in df.items():
                    content += f”\n=== Sheet: {sheet_name} ===\n”
                    content += sheet.to_csv(index=False)
            elif ext in [“.mdb”, “.accdb”] and pd:
                # Requires pyodbc and proper DSN or connection string
                try:
                    import pyodbc
                    conn_str = f”DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={path};”
                    conn = pyodbc.connect(conn_str)
                    tables = [row.table_name for row in conn.cursor().tables(tableType=‘TABLE’)]
                    content = “”
                    for table in tables:
                        df = pd.read_sql(f”SELECT * FROM [{table}]”, conn)
                        content += f”\n=== Table: {table} ===\n”
                        content += df.to_csv(index=False)
                    conn.close()
                except Exception as e:
                    content = f”[Error reading Access file {path}: {e}]”
            else:
                with open(path, “r”, encoding=“utf-8”, errors=“ignore”) as f:
                    content = f.read()
        except Exception as e:
            content = f”[Error reading file {path}: {e}]”
        return content

# ================= Text Generator =================
class SmartTextGenerator:
    “””Generate new text with templates, context, and language awareness.”””
    def generate_from_template(self, template: str, context: Dict[str, str]) -> str:
        result = template
        for k, v in context.items():
            result = result.replace(f”{{{{{k}}}}}”, v)
        return result

# ================= Text Runtime =================
class SmartUniversalTextRuntimeV2:
    “””Main runtime: dynamic, multi-lingual, entity-aware, pattern learning, full MS Office support.”””
    def __init__(self):
        self.text_objects: Dict[str, TextData] = {}
        self.analyzer = SmartTextAnalyzer()
        self.generator = SmartTextGenerator()

    def load_text(self, name: str, path: str, language: str = “unknown”):
        content = SmartTextLoader.load(path)
        text_obj = TextData(content=content, source=path, language=language)
        text_obj.detected_language = self.analyzer.detect_language(content)
        text_obj.patterns = self.analyzer.extract_patterns(content)
        text_obj.entities = self.analyzer.extract_entities(content)
        self.text_objects[name] = text_obj

    def analyze_text(self, name: str) -> str:
        if name not in self.text_objects:
            return f”[Error] Text object ‘{name}’ not found”
        text_data = self.text_objects[name]
        return self.analyzer.summarize(text_data)

    def generate_text(self, name: str, template: str, context: Dict[str, str], language: str = “unknown”) -> str:
        result = self.generator.generate_from_template(template, context)
        text_obj = TextData(content=result, source=“generated”, language=language)
        text_obj.detected_language = self.analyzer.detect_language(result)
        text_obj.patterns = self.analyzer.extract_patterns(result)
        text_obj.entities = self.analyzer.extract_entities(result)
        self.text_objects[name] = text_obj
        return result

    def merge_texts(self, name: str, sources: List[str], delimiter: str = “\n”, language: str = “mixed”) -> str:
        merged = delimiter.join([self.text_objects[s].content for s in sources if s in self.text_objects])
        text_obj = TextData(content=merged, source=“merged”, language=language)
        text_obj.detected_language = self.analyzer.detect_language(merged)
        text_obj.patterns = self.analyzer.extract_patterns(merged)
        text_obj.entities = self.analyzer.extract_entities(merged)
        self.text_objects[name] = text_obj
        return merged

    def save_text(self, name: str, path: str):
        if name in self.text_objects:
            with open(path, “w”, encoding=“utf-8”) as f:
                f.write(self.text_objects[name].content)

# ================= Example Usage =================
if __name__ == “__main__”:
    runtime = SmartUniversalTextRuntimeV2()

    # Load various files
    runtime.load_text(“english_txt”, “./sample_data/english.txt”)
    runtime.load_text(“excel_file”, “./sample_data/data.xlsx”)
    runtime.load_text(“access_file”, “./sample_data/database.accdb”)
    runtime.load_text(“docx_file”, “./sample_data/document.docx”)
    runtime.load_text(“pdf_file”, “./sample_data/report.pdf”)

    # Merge all loaded texts
    runtime.merge_texts(“merged_all”, [“english_txt”, “excel_file”, “access_file”, “docx_file”, “pdf_file”])
    print(“Analysis:\n”, runtime.analyze_text(“merged_all”))

    # Generate text dynamically
    template = “Dear {{name}}, your report on {{topic}} is ready.”
    generated = runtime.generate_text(“generated_text”, template, {“name”: “Alice”, “topic”: “Cyber Security”})
    print(“Generated Text:\n”, generated)

    # Save generated text
    runtime.save_text(“generated_text”, “./output/generated_full_multiformat.txt”)