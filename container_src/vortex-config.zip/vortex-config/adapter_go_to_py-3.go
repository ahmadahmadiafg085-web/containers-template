// adapter_go_to_py-3.go
package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"sync"
	"time"
)

// ======= Scenario Struct =======
type Scenario struct {
	Name      string `json:"name"`
	Status    string `json:"status"`
	Msg       string `json:"msg"`
	FailCount int    `json:"fail_count"`
	LastRun   string `json:"last_run"`
}

// ======= Global Adapter =======
type GoToPyAdapter struct {
	Scenarios map[string]*Scenario
	Lock      sync.Mutex
	Interval  time.Duration
	MaxFail   int
}

// ======= Constructor =======
func NewGoToPyAdapter(interval time.Duration, maxFail int) *GoToPyAdapter {
	return &GoToPyAdapter{
		Scenarios: make(map[string]*Scenario),
		Interval:  interval,
		MaxFail:   maxFail,
	}
}

// ======= Add a Scenario =======
func (a *GoToPyAdapter) AddScenario(name string) {
	a.Lock.Lock()
	defer a.Lock.Unlock()
	if _, exists := a.Scenarios[name]; !exists {
		a.Scenarios[name] = &Scenario{
			Name:      name,
			Status:    "unknown",
			Msg:       "",
			FailCount: 0,
			LastRun:   "",
		}
		fmt.Printf("[ADAPTER] Added scenario: %s\n", name)
	}
}

// ======= Remove Scenario =======
func (a *GoToPyAdapter) RemoveScenario(name string) {
	a.Lock.Lock()
	defer a.Lock.Unlock()
	delete(a.Scenarios, name)
	fmt.Printf("[ADAPTER] Removed scenario: %s\n", name)
}

// ======= Process Single Scenario =======
func (a *GoToPyAdapter) processScenario(s *Scenario) {
	success := rand.Float32() > 0.2 // 80% success simulation

	if success {
		s.Status = "success"
		s.FailCount = 0
	} else {
		s.Status = "fail"
		s.FailCount++
	}

	s.LastRun = time.Now().Format("2006-01-02 15:04:05")
	s.Msg = fmt.Sprintf("Processed at %s", s.LastRun)

	// Self-heal if fail count exceeds threshold
	if s.FailCount >= a.MaxFail {
		fmt.Printf("[SELF-HEAL] Resetting scenario %s after %d fails\n", s.Name, s.FailCount)
		s.Status = "unknown"
		s.FailCount = 0
		s.Msg = "Reset by self-heal"
	}
}

// ======= Process Loop =======
func (a *GoToPyAdapter) ProcessLoop() {
	for {
		a.Lock.Lock()
		for _, s := range a.Scenarios {
			a.processScenario(s)
			data, _ := json.Marshal(s)
			fmt.Printf("[SCENARIO UPDATE] %s\n", string(data))
		}
		a.Lock.Unlock()
		time.Sleep(a.Interval)
	}
}

// ======= Trigger Scenario =======
func (a *GoToPyAdapter) TriggerScenario(name string, customMsg string) {
	a.Lock.Lock()
	defer a.Lock.Unlock()
	if s, exists := a.Scenarios[name]; exists {
		s.Msg = customMsg
		fmt.Printf("[TRIGGER] Scenario %s triggered: %s\n", name, customMsg)
	}
}

// ======= Trigger All Failing Scenarios =======
func (a *GoToPyAdapter) TriggerFailingScenarios() {
	a.Lock.Lock()
	defer a.Lock.Unlock()
	for _, s := range a.Scenarios {
		if s.Status == "fail" {
			s.Msg = fmt.Sprintf("Auto-trigger due to failure at %s", time.Now().Format("15:04:05"))
			fmt.Printf("[AUTO-TRIGGER] %s\n", s.Name)
		}
	}
}

// ======= Main =======
func main() {
	rand.Seed(time.Now().UnixNano())

	adapter := NewGoToPyAdapter(3*time.Second, 5)

	// Add initial scenarios
	adapter.AddScenario("init_scenario")
	adapter.AddScenario("health_check")
	adapter.AddScenario("actuator_monitor")

	// Start background processing loop
	go adapter.ProcessLoop()

	// Dynamic scenario addition after 10s
	time.AfterFunc(10*time.Second, func() {
		adapter.AddScenario("dynamic_scenario_1")
	})

	// Manual trigger after 15s
	time.AfterFunc(15*time.Second, func() {
		adapter.TriggerScenario("init_scenario", "Manual trigger executed")
	})

	// Auto-trigger failing scenarios every 20s
	go func() {
		ticker := time.NewTicker(20 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			adapter.TriggerFailingScenarios()
		}
	}()

	// Keep main alive indefinitely
	select {}
}
