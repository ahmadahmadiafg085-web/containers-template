from modules.parsers import Parser
from modules.normalizer import Normalizer
from modules.analytics import Analyzer
from modules.alerts import AlertManager
from modules.storage import Storage
from modules.visualization import Dashboard
from modules.security import Security
from modules.integration import Integration
from modules.selfrepair import SelfRepair
from modules.optimizer import Optimizer

class LogsDispatcher:
    def __init__(self, config):
        # Initializing all modules
        self.parser = Parser(config.get(‘parser’, {}))
        self.normalizer = Normalizer(config.get(‘normalizer’, {}))
        self.analyzer = Analyzer(config.get(‘analytics’, {}))
        self.alerts = AlertManager(config.get(‘alerts’, {}))
        self.storage = Storage(config.get(‘storage’, {}))
        self.dashboard = Dashboard(config.get(‘visualization’, {}))
        self.security = Security(config.get(‘security’, {}))
        self.integration = Integration(config.get(‘integration’, {}))
        self.self_repair = SelfRepair(config.get(‘selfrepair’, {}))
        self.optimizer = Optimizer(config.get(‘optimizer’, {}))

    def dispatch(self, raw_log):
        # Step 1: Parse
        log = self.parser.parse(raw_log)
        
        # Step 2: Normalize
        log = self.normalizer.normalize(log)
        
        # Step 3: Security Check
        if not self.security.validate(log):
            return
        
        # Step 4: Analyze
        analysis = self.analyzer.analyze(log)
        
        # Step 5: Alerts
        self.alerts.check(analysis)
        
        # Step 6: Store
        self.storage.store(log, analysis)
        
        # Step 7: Dashboard update
        self.dashboard.update(log, analysis)
        
        # Step 8: Integration triggers
        self.integration.trigger(log, analysis)
        
        # Step 9: Self repair
        self.self_repair.fix(log, analysis)
        
        # Step 10: Optimization suggestions
        self.optimizer.suggest(log, analysis)
        
        from modules.parsers import Parser
from modules.normalizer import Normalizer
from modules.analytics import Analyzer
from modules.alerts import AlertManager
from modules.storage import Storage
from modules.visualization import Dashboard
from modules.security import Security
from modules.integration import Integration
from modules.selfrepair import SelfRepair
from modules.optimizer import Optimizer

class LogsDispatcher:
    def __init__(self, config):
        # Initializing all modules
        self.parser = Parser(config.get(‘parser’, {}))
        self.normalizer = Normalizer(config.get(‘normalizer’, {}))
        self.analyzer = Analyzer(config.get(‘analytics’, {}))
        self.alerts = AlertManager(config.get(‘alerts’, {}))
        self.storage = Storage(config.get(‘storage’, {}))
        self.dashboard = Dashboard(config.get(‘visualization’, {}))
        self.security = Security(config.get(‘security’, {}))
        self.integration = Integration(config.get(‘integration’, {}))
        self.self_repair = SelfRepair(config.get(‘selfrepair’, {}))
        self.optimizer = Optimizer(config.get(‘optimizer’, {}))

    def dispatch(self, raw_log):
        # Step 1: Parse
        log = self.parser.parse(raw_log)
        
        # Step 2: Normalize
        log = self.normalizer.normalize(log)
        
        # Step 3: Security Check
        if not self.security.validate(log):
            return
        
        # Step 4: Analyze
        analysis = self.analyzer.analyze(log)
        
        # Step 5: Alerts
        self.alerts.check(analysis)
        
        # Step 6: Store
        self.storage.store(log, analysis)
        
        # Step 7: Dashboard update
        self.dashboard.update(log, analysis)
        
        # Step 8: Integration triggers
        self.integration.trigger(log, analysis)
        
        # Step 9: Self repair
        self.self_repair.fix(log, analysis)
        
        # Step 10: Optimization suggestions
        self.optimizer.suggest(log, analysis)