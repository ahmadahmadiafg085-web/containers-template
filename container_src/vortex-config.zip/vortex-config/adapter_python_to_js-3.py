import asyncio
import hashlib
import time
import json
import math
from dataclasses import dataclass, field
from typing import Any, Dict, Callable, List

# ============================================================================
#  MEMORY ENGINE → SELF LEARNING + PATTERNS + HUMAN-LIKE REASONING
# ============================================================================

class HumanMemory:
    def __init__(self):
        self.dialog_history = []         # کل مکالمه‌ها
        self.learning_patterns = []      # الگوهای یادگیری
        self.topic_weights = {}          # موضوعات مهم
        self.error_patterns = []         # رفتار خطا
        self.sentiment_map = []          # تحلیل احساسات ورودی کاربر

    def log_input(self, text):
        self.dialog_history.append(text)
        self._extract_topics(text)
        self._learn(text)

    def _extract_topics(self, text):
        “””بازیابی موضوعات → بسیار ساده اما مؤثر”””
        keys = [“security”, “runtime”, “python”, “wasm”, “predict”, “analysis”,
                “agent”, “sandbox”, “virus”, “attack”, “training”]
        for k in keys:
            if k in text.lower():
                self.topic_weights[k] = self.topic_weights.get(k, 0) + 1

    def _learn(self, text):
        “””الگوبرداری از ورودی برای خودآموزی”””
        tokens = text.lower().split()
        self.learning_patterns.extend(tokens)

    def predict_relevant(self, text):
        “””پیش‌بینی موضوع پاسخ”””
        score = {}
        for word in text.lower().split():
            score[word] = self.topic_weights.get(word, 0)
        return sorted(score.items(), key=lambda x: x[1], reverse=True)

    def mood(self, text):
        “””تحلیل احساسات ساده”””
        good = [“ok”, “good”, “yes”, “fine”, “great”]
        bad  = [“bad”, “angry”, “error”, “broken”, “problem”]

        score = 0
        for w in text.lower().split():
            if w in good:
                score += 1
            if w in bad:
                score -= 1
        return score


MEM = HumanMemory()


# ============================================================================
#  SELF‑LEARNING AGENT MODULES
# ============================================================================

class SelfLearningAgent:
    def __init__(self):
        self.skills = {}
        self.experience = []

    def learn_skill(self, name, fn):
        self.skills[name] = fn

    def use_skill(self, name, *args):
        if name in self.skills:
            self.experience.append((name, args))
            return self.skills[name](*args)
        raise Exception(“Skill not found”)

    def predict_next_skill(self):
        “””پیش‌بینی skill مناسب بر اساس تجربه قبلی”””
        counter = {}
        for sk, _ in self.experience[-50:]:
            counter[sk] = counter.get(sk, 0) + 1
        if not counter:
            return None
        return max(counter, key=lambda k: counter[k])


AGENT = SelfLearningAgent()


# ============================================================================
#  HUMAN-LIKE RESPONSE GENERATOR
# ============================================================================

def generate_human_response(user_text):
    MEM.log_input(user_text)

    mood = MEM.mood(user_text)
    predicted_topics = MEM.predict_relevant(user_text)

    topic_guess = predicted_topics[0][0] if predicted_topics else “general”
    future_guess = AGENT.predict_next_skill() or “analysis”

    response = {
        “topic”: topic_guess,
        “mood_value”: mood,
        “next_skill_prediction”: future_guess,
        “summary”: f”Your message seems related to {topic_guess}.”,
        “insight”: f”System predicts the next relevant capability: {future_guess}”,
    }

    # خودآموزی برای دفعات بعد
    AGENT.learn_skill(“analysis”, lambda t: f”Analyzed: {t[:40]}”)
    AGENT.learn_skill(“predict”, lambda _: f”Future trend: {topic_guess}”)
    AGENT.learn_skill(“guide”, lambda _: f”Recommendation: focus on {topic_guess}”)

    # مهارت مناسب را فعال می‌کنیم
    recommended_skill = response[“next_skill_prediction”]
    try:
        response[“skill_output”] = AGENT.use_skill(recommended_skill, user_text)
    except:
        response[“skill_output”] = “Skill not ready”

    return response


# ============================================================================
#  HOT RELOAD + MIRROR SYNC (مانند نسخه قبلی)
# ============================================================================

class Mirror:
    def __init__(self):
        self.cache = {}

    def changed(self, name, content):
        key = hashlib.sha256(content.encode()).hexdigest()
        old = self.cache.get(name)
        self.cache[name] = key
        return old != key


MIRROR = Mirror()


# ============================================================================
#  MAIN ORCHESTRATOR (Pyodide Optimized)
# ============================================================================

class HumanInteractiveOrchestrator:
    def __init__(self):
        self.modules = {}

    async def register_module(self, name, content):
        self.modules[name] = content

    async def hot_reload(self, name, new_content):
        if MIRROR.changed(name, new_content):
            await self.register_module(name, new_content)
            return {“reload”: True}
        return {“reload”: False}

    async def interact(self, text):
        “””تعامل انسان‌گونه”””
        result = generate_human_response(text)
        return {
            “input”: text,
            “analysis”: result,
            “memory_topics”: MEM.topic_weights,
            “patterns”: MEM.learning_patterns[-20:]
        }


# ============================================================================
#  DEMO
# ============================================================================

async def demo():
    orch = HumanInteractiveOrchestrator()

    print(await orch.interact(“runtime error python predict future”))
    print(await orch.interact(“security sandbox virus detect”))
    print(await orch.interact(“wasm loader analysis please”))

# asyncio.run(demo())