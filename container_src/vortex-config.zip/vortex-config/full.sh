#!/bin/bash
# VortexHub Mini-Cloud Bootstrap (Multi-node, Multi-lang, GH007-proof)
LOG=/app/logs/bootstrap.log
READY=/app/.ready
ENV_FILE=/app/.env
mkdir -p /app/logs
echo "BOOTSTRAP START $(date)" | tee -a $LOG
[ -f "$ENV_FILE" ] && source "$ENV_FILE"

# Languages
LANGS=${LANGS:-python nodejs rust fsharp lisp}
ACTIVE=""
for L in $LANGS; do
  [[ -f requirements.txt && $L==python ]] && ACTIVE=python
  [[ -f package.json && $L==nodejs ]] && ACTIVE=nodejs
  [[ -f Cargo.toml && $L==rust ]] && ACTIVE=rust
  ls *.fs >/dev/null 2>&1 && ACTIVE=fsharp
  ls *.lisp >/dev/null 2>&1 && ACTIVE=lisp
  [[ ! -z "$ACTIVE" ]] && break
done
echo "Language: ${ACTIVE:-none}" | tee -a $LOG

# Setup
case $ACTIVE in
  python) pip3 install --no-cache-dir -r requirements.txt 2>/dev/null || true ;;
  nodejs) npm install --legacy-peer-deps 2>/dev/null || true ;;
  rust) cargo update 2>/dev/null || true ;;
  fsharp) for f in *.fs; do [ -f "$f" ] && fsharpi "$f"; done ;;
  lisp) for l in *.lisp; do [ -f "$l" ] && sbcl --noinform --eval "(load \"$l\")" --eval '(quit)'; done ;;
esac

# Git
git config user.email "${GIT_NOREPLY_EMAIL}" || true
git config user.name "Dr. S. M. H. Sadat" || true
git fetch origin main || true
git add . || true
git commit -m "Auto-sync [skip ci]" || true
git push origin main || true

# Telemetry
[[ "$CI_MODE"=="true" ]] && curl -s -X POST -H "Content-Type: application/json" -d "{\"ts\":\"$(date)\",\"proj\":\"$PROJECT_NAME\"}" $TELEMETRY_URL || true

# Watch mode
if [[ "$ENABLE_WATCH_MODE"=="true" ]]; then
  apt-get update -y && apt-get install -y inotify-tools 2>/dev/null || true
  inotifywait -mr /app -e modify,create,delete --format '%w%f' | while read c; do
    echo "Change: $c" | tee -a $LOG
    /usr/local/bin/self-upgrade || true
  done &
fi

touch $READY
echo "READY marker created at $READY" | tee -a $LOG
echo "BOOTSTRAP END $(date)" | tee -a $LOG