import json,time,threading,requests
from typing import Callable,List,Dict,Optional

class BaseTrigger:
    def __init__(self,name:str,condition:Callable[[dict],bool]=None,priority:int=0,group:str=None,interval:float=0,dependencies:List[str]=None,logic:str=“SINGLE”):
        self.name=name
        self.condition=condition
        self.active=False
        self.last_activated=None
        self.actions:List[‘Action’]=[]
        self.priority=priority
        self.group=group
        self.history=[]
        self.interval=interval
        self.dependencies=dependencies or []
        self.logic=logic
        self._lock=threading.Lock()
    def add_action(self,action:’Action’):self.actions.append(action)
    def evaluate(self,context:Optional[dict]=None,manager:Optional[‘TriggerManager’]=None)->bool:
        with self._lock:
            context=context or {}
            if self.logic==“AND” and manager:
                self.active=all(manager.get_trigger(dep).active for dep in self.dependencies)
            elif self.logic==“OR” and manager:
                self.active=any(manager.get_trigger(dep).active for dep in self.dependencies)
            elif self.logic==“NOT” and manager:
                self.active=not any(manager.get_trigger(dep).active for dep in self.dependencies)
            elif self.condition:
                self.active=self.condition(context)
            if self.active:
                now=time.time()
                if not self.last_activated or (self.interval==0 or now-self.last_activated>=self.interval):
                    self.last_activated=now
                    self.history.append(now)
                    for action in sorted(self.actions,key=lambda x:x.priority,reverse=True):
                        action.execute(context)
            return self.active

class Action:
    def __init__(self,name:str,func:Callable[[dict],None],priority:int=0,webhook:str=None,dependencies:List[str]=None,max_runs:int=0):
        self.name=name
        self.func=func
        self.priority=priority
        self.webhook=webhook
        self.dependencies=dependencies or []
        self.run_count=0
        self.max_runs=max_runs
        self._lock=threading.Lock()
    def execute(self,context:dict,manager:Optional[‘TriggerManager’]=None):
        with self._lock:
            if self.max_runs>0 and self.run_count>=self.max_runs:
                return
            if manager and self.dependencies:
                if not all(manager.get_action(dep).run_count>0 for dep in self.dependencies):
                    return
            try:
                self.func(context)
                self.run_count+=1
                if self.webhook:requests.post(self.webhook,json=context,timeout=5)
            except Exception as e:print(f”[Action Error] {self.name}: {e}”)

class TriggerManager:
    def __init__(self):self.triggers:List[BaseTrigger]=[]
    def add_trigger(self,trigger:BaseTrigger):self.triggers.append(trigger)
    def remove_trigger(self,name:str):self.triggers=[t for t in self.triggers if t.name!=name]
    def get_trigger(self,name:str)->Optional[BaseTrigger]:
        for t in self.triggers:
            if t.name==name:return t
        return None
    def get_action(self,name:str)->Optional[Action]:
        for t in self.triggers:
            for a in t.actions:
                if a.name==name:return a
        return None
    def evaluate_all(self,context:Optional[dict]=None)->Dict[str,bool]:
        results={}
        for t in sorted(self.triggers,key=lambda x:x.priority,reverse=True):
            results[t.name]=t.evaluate(context,manager=self)
        return results
    def get_active_triggers(self)->List[BaseTrigger]:return [t for t in self.triggers if t.active]
    def save_to_json(self,path:str):
        data={“triggers”:[]}
        for t in self.triggers:
            data[“triggers”].append({
                “name”:t.name,”active”:t.active,”last_activated”:t.last_activated,
                “priority”:t.priority,”group”:t.group,”interval”:t.interval,
                “logic”:t.logic,”dependencies”:t.dependencies,
                “actions”:[{“name”:a.name,”priority”:a.priority,”webhook”:a.webhook,”dependencies”:a.dependencies,”max_runs”:a.max_runs,”run_count”:a.run_count} for a in t.actions]
            })
        with open(path,’w’) as f:json.dump(data,f,indent=2)
    def load_from_json(self,path:str):
        with open(path,’r’) as f:data=json.load(f)
        for item in data.get(“triggers”,[]):
            condition=lambda ctx,key=item.get(“condition_key”),val=item.get(“condition_value”):ctx.get(key)==val if key else True
            trigger=BaseTrigger(
                name=item[“name”],condition=condition,priority=item.get(“priority”,0),
                group=item.get(“group”),interval=item.get(“interval”,0),
                dependencies=item.get(“dependencies”),logic=item.get(“logic”,”SINGLE”)
            )
            for a in item.get(“actions”,[]):
                trigger.add_action(Action(
                    a[“name”],lambda ctx,msg=a.get(“message”,”executed”):print(f”[{a[‘name’]}] {msg}”),
                    priority=a.get(“priority”,0),webhook=a.get(“webhook”),
                    dependencies=a.get(“dependencies”),max_runs=a.get(“max_runs”,0)
                ))
            self.add_trigger(trigger)

def notify_admin(ctx):print(“[NotifyAdmin]”,ctx)
def activate_loader(ctx):print(“[ActivateLoader]”)
def log_event(ctx):print(“[LogEvent]”,ctx)

if __name__==“__main__”:
    tm=TriggerManager()
    t1=BaseTrigger(“HighValue”,condition=lambda ctx:ctx.get(“value”,0)>100,priority=10,group=“finance”,interval=5)
    t1.add_action(Action(“NotifyAdmin”,notify_admin,priority=5,webhook=“https://example.com/webhook”))
    t1.add_action(Action(“ActivateLoader”,activate_loader,priority=3))
    t1.add_action(Action(“LogEvent”,log_event,priority=1))
    t2=BaseTrigger(“MediumValue”,condition=lambda ctx:ctx.get(“value”,0)>50,priority=5,group=“finance”,interval=10,dependencies=[“HighValue”],logic=“NOT”)
    t2.add_action(Action(“NotifyAdminMedium”,notify_admin,priority=2))
    tm.add_trigger(t1)
    tm.add_trigger(t2)

    context={“value”:150}
    while True:
        results=tm.evaluate_all(context)
        print(“Results:”,results)
        print(“Active triggers:”,[t.name for t in tm.get_active_triggers()])
        time.sleep(2)
        