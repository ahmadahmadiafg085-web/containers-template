import os,time,hashlib,threading,queue,psutil,subprocess,json
from pathlib import Path
from typing import List, Dict, Callable, Optional
from pyodide import run_js

import logging
logging.basicConfig(level=logging.INFO, format=‘[%(levelname)s] %(asctime)s - %(message)s’)
def alert_admin(msg:str): logging.warning(f”ALERT: {msg}”)

CTX={“history”:[], “score”:0.0, “actions”:[], “count”:0, “weights”:{}}

# ——————— Utilities ———————
def load_json(path:str) -> Dict:
    try:
        with open(path,’r’,encoding=‘utf-8’) as f: return json.load(f)
    except: return {}

fhash = lambda p: hashlib.sha256(open(p,”rb”).read()).hexdigest() if Path(p).exists() else None
chk_temp = lambda hs: next((f for t in [Path(os.getenv(“TEMP”,”/tmp”))] for f in t.glob(“*”) if fhash(f) in hs), None)
usb = lambda vid=None,pid=None,serial=None: True
sensor = lambda t: psutil.sensors_temperatures().get(‘coretemp’,[25])[0].current if t==“temperature” else False
stego = lambda path,pat: Path(path).exists() and pat in open(path,’rb’).read().decode(errors=‘ignore’)
pdf_js = lambda path: Path(path).exists() and “JavaScript” in open(path,’rb’).read().decode(errors=‘ignore’)
vba = lambda path: Path(path).exists() and (“Sub “ in open(path,’r’,errors=‘ignore’).read() or “Function “ in open(path,’r’,errors=‘ignore’).read())
js_event = lambda code: run_js(code)
cpu = lambda: psutil.cpu_percent() > 85
dom = lambda: True
proc = lambda: any(p.name()==“example_process” for p in psutil.process_iter())
net = lambda: any(n.isup for n in psutil.net_if_stats().values())
clip = lambda: True
scr_area = lambda a: True
score = lambda t,v:(CTX.update({“score”:CTX[“score”]+CTX[“weights”].get(t,1.0)*(1 if v else 0),”history”:CTX[“history”]+[(t,v,time.time())]}))
combo = lambda s:”ultra_combo” if sum(1 for v in s.values() if v)>=4 else “triple_combo” if sum(1 for v in s.values() if v)==3 else “double_combo” if sum(1 for v in s.values() if v)==2 else None

# ——————— Trigger Functions ———————
TRIGGER_FUNCS = {
    “file_open”: lambda t: bool(chk_temp([t.get(“hash”)])),
    “usb_connect”: lambda t: usb(t.get(“vid”), t.get(“pid”), t.get(“serial”)),
    “sensor_temp”: lambda t: t[“min”] <= sensor(“temperature”) <= t[“max”],
    “sensor_motion”: lambda t: sensor(“motion”),
    “image_stego”: lambda t: stego(t.get(“path”), t.get(“pattern”)),
    “pdf_js”: lambda t: pdf_js(t.get(“path”)),
    “vba_macro”: lambda t: vba(t.get(“path”)),
    “js_event”: lambda t: js_event(t.get(“js_code”)),
    “ui_interaction”: lambda t: clip(),
    “window_event”: lambda t: True,
    “screen_area”: lambda t: scr_area(t.get(“area_id”)),
    “clipboard”: lambda t: clip(),
    “cpu_spike”: lambda t: cpu(),
    “dom_change”: lambda t: dom(),
    “process_start”: lambda t: proc(),
    “network_anomaly”: lambda t: net(),
    “ram_pressure”: lambda t: psutil.virtual_memory().percent>80,
    “gpu_usage”: lambda t: psutil.virtual_memory().percent>70,
    “wifi_change”: lambda t: True,
    “vpn_state”: lambda t: True,
    “proxy_change”: lambda t: True,
    “print_job”: lambda t: True,
    “battery_low”: lambda t: psutil.sensors_battery().percent<10 if psutil.sensors_battery() else False,
    “window_focus”: lambda t: True,
    “latency_spike”: lambda t: True,
    “firewall_change”: lambda t: True
}

# ——————— BaseTrigger Classes ———————
class BaseTrigger:
    def __init__(self,name:str,trigger_type:str):
        self.name,self.trigger_type=name,trigger_type
        self.active=False
        self.last_active:Optional[float]=None
        self.actions:List[Callable[[dict],None]]=[]
        self._lock=threading.Lock()
        self.event_queue=queue.Queue()
    def add_action(self,func:Callable[[dict],None]): self.actions.append(func)
    def activate(self,ctx:Optional[dict]=None):
        with self._lock:
            self.active=True
            self.last_active=time.time()
            logging.info(f”Trigger activated: {self.name}”)
            self.event_queue.put({“trigger”:self.name,”context”:ctx,”time”:self.last_active})
            for a in self.actions:
                try: a(ctx or {})
                except Exception as e: logging.error(f”Action error in {self.name}: {e}”); alert_admin(f”Action error in {self.name}: {e}”)
    def deactivate(self):
        with self._lock:
            if self.active: logging.info(f”Trigger deactivated: {self.name}”)
            self.active=False
    def evaluate(self,ctx:Optional[dict]=None)->bool: raise NotImplementedError

class FileTrigger(BaseTrigger):
    def __init__(self,name:str,path:Optional[str]=None,file_hash:Optional[str]=None):
        super().__init__(name,”FILE”)
        self.path,self.file_hash=path,file_hash
    def evaluate(self,ctx:Optional[dict]=None)->bool:
        ctx=ctx or {}
        ofs=ctx.get(“open_files”,[])
        self.activate(ctx) if self.path in ofs else self.deactivate()
        return self.active

class SensorTrigger(BaseTrigger):
    def __init__(self,name:str,sensor_type:str,min_val:Optional[float]=None,max_val:Optional[float]=None):
        super().__init__(name,”SENSOR”)
        self.sensor_type,self.min_val,self.max_val=sensor_type,min_val,max_val
    def evaluate(self,ctx:Optional[dict]=None)->bool:
        ctx=ctx or {}
        val=ctx.get(“sensors”,{}).get(self.sensor_type,0)
        if (self.min_val is None or val>=self.min_val) and (self.max_val is None or val<=self.max_val): self.activate(ctx)
        else: self.deactivate()
        return self.active

class CompositeTrigger(BaseTrigger):
    def __init__(self,name:str,triggers:List[BaseTrigger],logic:str=“AND”):
        super().__init__(name,”COMPOSITE”)
        self.triggers,self.logic=triggers,logic.upper()
    def evaluate(self,ctx:Optional[dict]=None)->bool:
        res=[t.evaluate(ctx) for t in self.triggers]
        if self.logic==“AND”: self.activate(ctx) if all(res) else self.deactivate()
        elif self.logic==“OR”: self.activate(ctx) if any(res) else self.deactivate()
        elif self.logic==“NOT”: self.activate(ctx) if not any(res) else self.deactivate()
        else: self.deactivate()
        return self.active

# ——————— Agents ———————
class MicroAgent:
    def __init__(self,cfg):
        self.cfg,self.cfg.setdefault(“triggers”,cfg.get(“triggers”,[])) = cfg,cfg.get(“triggers”,[])
        self.status,self.wake,self.last = {}, “sleep”, 0
    def update_wake(self):
        now=time.time(); active=any(self.status.values())
        if active: self.last=now; self.wake=“full_wake” if sum(bool(v) for v in self.status.values())>=2 else “semi_wake”
        elif now-self.last>5: self.wake=“sleep”
    def listen(self):
        for t in self.cfg[“triggers”]:
            f=TRIGGER_FUNCS.get(t[“type”])
            v=f(t) if f else False
            score(t[“type”],v)
            self.status[t[“type”]]=bool(v)
        cb=combo(self.status)
        if cb: self.status[f”combo:{cb}”]=True
        self.update_wake()
        return self.status
    def report(self):
        # میتونه JSON webhook یا ذخیره local باشه
        logging.info({“status”:self.status,”wake”:self.wake,”score”:CTX[“score”],”history”:CTX[“history”][-10:]})

class MacroAgent:
    def __init__(self,cfg): self.cfg=cfg
    def evaluate(self,status,wake):
        if wake==“sleep”: return
        for a in self.cfg.get(“actions”,[]):
            sh,cond=False,a.get(“condition”,”all”)
            if cond==“all” and all(status.values()): sh=True
            elif cond==“any” and any(status.values()): sh=True
            elif cond==“combo” and any(k.startswith(“combo:”) for k in status): sh=True
            elif cond==“custom”:
                try: sh=eval(a.get(“expr”,”False”), {}, status)
                except: sh=False
            if sh: self.exec(a)
    def exec(self,a):
        t=a.get(“type”); CTX[“actions”].append(t); CTX[“count”]+=1
        logging.info(f”Macro action executed: {t}”)

# ——————— Main Loop ———————
def main_loop(json_path=“config.json”):
    cfg = load_json(json_path)
    micro = MicroAgent(cfg)
    macro = MacroAgent(cfg)

    triggers = []
    for t in cfg.get(“triggers”, []):
        if t[“type”]==“FILE”: triggers.append(FileTrigger(t.get(“name”), t.get(“path”)))
        elif t[“type”]==“SENSOR”: triggers.append(SensorTrigger(t.get(“name”), t.get(“sensor_type”), t.get(“min”), t.get(“max”)))
        # میشه Composite یا دیگر انواع را از JSON بسازیم

    while True:
        st = micro.listen()
        if micro.wake!=“sleep”:
            micro.report()
            macro.evaluate(st,micro.wake)
        ctx = {“open_files”: [“report.txt”], “sensors”: {“temp”:75}}
        for trig in triggers: trig.evaluate(ctx)
        time.sleep(0.5 if micro.wake!=“sleep” else 2)

threading.Thread(target=main_loop,daemon=True).start()
