# ============================================================
# 🧠 VortexHub Anomaly Detector (v1.6-ULTRA-STABLE+HARDENED)
# Author: Dr. S. M. H. Sadat / VortexHub Labs
# Purpose: Autonomous Anomaly Engine + Self-Healing + Admin API
# ============================================================

import os, sys, time, json, hashlib, random, traceback, threading, asyncio, aiohttp
from datetime import datetime
from typing import Dict, Any, List
from aiohttp import web

# ============================================================
# 🔰 CONFIGURATION
# ============================================================

CONFIG = {
    "tag": "03_anomaly_detector",
    "version": "v1.6-ULTRA-STABLE",
    "mode": "hybrid",
    "telemetry_api": "https://api.vortexhub.app/telemetry",
    "alert_path": "./logs/anomaly_alerts.json",
    "integrity_check_path": "./runtime/hash_index.json",
    "threshold": 0.92,
    "cooldown_sec": 30,
    "auto_recover": True,
    "admin_api_key": "secure_admin_token",
    "admin_port": 8080,
    "alert_channels": ["email", "telegram", "webhook"],
    "linked_modules": [
        "./ai_core_logic.py",
        "./04_vortex_telemetry.v01.py",
        "./07_ai_memory_handler.v01.py",
        "./LifeGuard-ai_autofix.v01.js"
    ],
    "learning_map": "./ai_learning_map.json"
}

os.makedirs(os.path.dirname(CONFIG["alert_path"]), exist_ok=True)
os.makedirs(os.path.dirname(CONFIG["integrity_check_path"]), exist_ok=True)

# ============================================================
# ⚙️ UTILITIES
# ============================================================

def calc_file_hash(path: str):
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return "ERR"

def load_learning_map():
    try:
        if os.path.exists(CONFIG["learning_map"]) and os.path.getsize(CONFIG["learning_map"]) > 0:
            with open(CONFIG["learning_map"], "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except json.JSONDecodeError:
        pass
    return {"adaptive_thresholds": {}, "patterns": []}

def safe_json_load(path):
    try:
        if os.path.exists(path) and os.path.getsize(path) > 0:
            with open(path, "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except Exception:
        pass
    return []

def log_event(event_type: str, details: Dict[str, Any]):
    entry = {"timestamp": datetime.utcnow().isoformat(), "type": event_type, "details": details}
    try:
        data = safe_json_load(CONFIG["alert_path"])
        data.append(entry)
        with open(CONFIG["alert_path"], "w", encoding="utf-8") as f:
            json.dump(data[-1000:], f, indent=2)
    except Exception as e:
        print(f"[LOG_ERROR] {e}")

# ============================================================
# 🧠 CORE ANALYTICS
# ============================================================

def analyze_metrics(metrics: Dict[str, float]) -> bool:
    learn = load_learning_map()
    dynamic_threshold = learn.get("adaptive_thresholds", {}).get("behavior", CONFIG["threshold"])
    cpu = metrics.get("cpu_load", random.uniform(0.3, 0.8))
    latency = metrics.get("latency", random.uniform(0.2, 0.9))
    score = round((cpu + latency) / 2, 3)
    log_event("metrics_collected", {"cpu": cpu, "latency": latency, "score": score})
    if score > dynamic_threshold:
        log_event("behavioral_anomaly", {"score": score, "threshold": dynamic_threshold})
        return True
    return False

def verify_integrity():
    anomalies = []
    base = safe_json_load(CONFIG["integrity_check_path"])
    if isinstance(base, dict):
        for file, ref in base.items():
            current = calc_file_hash(file)
            if current != ref:
                anomalies.append(file)
                log_event("integrity_anomaly", {"file": file, "expected": ref, "found": current})
    return anomalies

def trigger_autofix(targets: List[str]):
    for f in targets:
        log_event("autofix_triggered", {"file": f})
        cmd = f"node LifeGuard-ai_autofix.v01.js --repair {f}"
        if os.system(cmd) != 0:
            log_event("autofix_failed", {"file": f, "cmd": cmd})

# ============================================================
# 🧬 ADAPTIVE LEARNING
# ============================================================

def adaptive_learning_update(event: str):
    data = load_learning_map()
    hist = data.get("patterns", [])
    hist.append({"event": event, "time": datetime.utcnow().isoformat()})
    data["patterns"] = hist[-200:]
    data.setdefault("adaptive_thresholds", {})["behavior"] = min(
        0.98, CONFIG["threshold"] + len(hist) / 10000)
    with open(CONFIG["learning_map"], "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    log_event("learning_updated", {"threshold": data["adaptive_thresholds"]["behavior"]})

# ============================================================
# 🚀 CYCLE
# ============================================================

def run_cycle():
    metrics = {"cpu_load": random.random(), "latency": random.random()}
    if analyze_metrics(metrics):
        adaptive_learning_update("behavioral_anomaly")
    anomalies = verify_integrity()
    if anomalies and CONFIG["auto_recover"]:
        trigger_autofix(anomalies)

# ============================================================
# 🌐 ADMIN API (aiohttp)
# ============================================================

async def handle_logs(request):
    if request.headers.get("X-API-KEY") != CONFIG["admin_api_key"]:
        return web.Response(status=403, text="Forbidden")
    return web.json_response(safe_json_load(CONFIG["alert_path"]))

async def handle_status(request):
    return web.json_response({"status": "running", "version": CONFIG["version"]})

async def start_admin_api():
    app = web.Application()
    app.router.add_get("/logs", handle_logs)
    app.router.add_get("/status", handle_status)
    runner = web.AppRunner(app)
    await runner.setup()
    try:
        site = web.TCPSite(runner, "0.0.0.0", CONFIG["admin_port"])
        await site.start()
        log_event("admin_api_started", {"port": CONFIG["admin_port"]})
    except OSError:
        log_event("admin_port_in_use", {"port": CONFIG["admin_port"]})

def launch_admin_api():
    asyncio.run(start_admin_api())

# ============================================================
# 🛰 EXECUTION ENGINE
# ============================================================

def main_loop():
    threading.Thread(target=launch_admin_api, daemon=True).start()
    log_event("system_start", {"version": CONFIG["version"]})
    while True:
        try:
            run_cycle()
            time.sleep(CONFIG["cooldown_sec"])
        except Exception:
            log_event("fatal_error", {"trace": traceback.format_exc()})
            time.sleep(10)

# ============================================================
# 🌀 ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main_loop()
    
    # ============================================================
# 🧠 VortexHub Anomaly Detector (v1.7-FINAL-ENTERPRISE+AUTONOMOUS)
# Author: Dr. S. M. H. Sadat / VortexHub Labs
# Purpose: Full Self-Healing, Autonomous Detection, Admin Control API
# ============================================================

import os, sys, time, json, hashlib, random, traceback, threading, asyncio, aiohttp
from datetime import datetime
from typing import Dict, Any, List
from aiohttp import web

# ============================================================
# 🔰 CONFIGURATION
# ============================================================

CONFIG = {
    "tag": "03_anomaly_detector",
    "version": "v1.7-FINAL-ENTERPRISE",
    "mode": "hybrid",
    "telemetry_api": "https://api.vortexhub.app/telemetry",
    "alert_path": "./logs/anomaly_alerts.json",
    "integrity_check_path": "./runtime/hash_index.json",
    "threshold": 0.92,
    "cooldown_sec": 30,
    "auto_recover": True,
    "admin_api_key": "secure_admin_token",
    "admin_port": 8080,
    "alert_channels": ["email", "telegram", "webhook"],
    "linked_modules": [
        "./ai_core_logic.py",
        "./04_vortex_telemetry.v01.py",
        "./07_ai_memory_handler.v01.py",
        "./LifeGuard-ai_autofix.v01.js"
    ],
    "learning_map": "./ai_learning_map.json"
}

# ایجاد فولدرهای لازم
os.makedirs(os.path.dirname(CONFIG["alert_path"]), exist_ok=True)
os.makedirs(os.path.dirname(CONFIG["integrity_check_path"]), exist_ok=True)

# ============================================================
# ⚙️ UTILITY FUNCTIONS
# ============================================================

def calc_file_hash(path: str) -> str:
    """Calculate SHA256 hash safely."""
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return "ERR"

def safe_json_load(path: str):
    """Safely load JSON file (handles empty or corrupted files)."""
    try:
        if os.path.exists(path) and os.path.getsize(path) > 0:
            with open(path, "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def safe_json_array(path: str):
    """Load list-based JSON logs safely."""
    data = safe_json_load(path)
    return data if isinstance(data, list) else []

def log_event(event_type: str, details: Dict[str, Any]):
    """Log events with error-resilient JSON writer."""
    entry = {"timestamp": datetime.utcnow().isoformat(), "type": event_type, "details": details}
    try:
        data = safe_json_array(CONFIG["alert_path"])
        data.append(entry)
        with open(CONFIG["alert_path"], "w", encoding="utf-8") as f:
            json.dump(data[-1000:], f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[LOG_ERROR] {e}")

# ============================================================
# 🧠 CORE ANALYTICS ENGINE
# ============================================================

def load_learning_map():
    """Load adaptive learning state."""
    data = safe_json_load(CONFIG["learning_map"])
    if not data:
        data = {"adaptive_thresholds": {}, "patterns": []}
    return data

def analyze_metrics(metrics: Dict[str, float]) -> bool:
    """Dynamic behavior analysis (CPU + latency deviation)."""
    learn = load_learning_map()
    dynamic_threshold = learn.get("adaptive_thresholds", {}).get("behavior", CONFIG["threshold"])
    cpu = metrics.get("cpu_load", random.uniform(0.3, 0.8))
    latency = metrics.get("latency", random.uniform(0.2, 0.9))
    score = round((cpu + latency) / 2, 3)
    log_event("metrics_collected", {"cpu": cpu, "latency": latency, "score": score})
    if score > dynamic_threshold:
        log_event("behavioral_anomaly", {"score": score, "threshold": dynamic_threshold})
        return True
    return False

def verify_integrity() -> List[str]:
    """Compare hashes to baseline to detect tampering."""
    anomalies = []
    base = safe_json_load(CONFIG["integrity_check_path"])
    if isinstance(base, dict):
        for file, ref in base.items():
            current = calc_file_hash(file)
            if current != ref:
                anomalies.append(file)
                log_event("integrity_anomaly", {
                    "file": file, "expected": ref, "found": current
                })
    return anomalies

def trigger_autofix(targets: List[str]):
    """Bridge to Lifeguard AutoFix (NodeJS)."""
    for f in targets:
        log_event("autofix_triggered", {"file": f})
        cmd = f"node LifeGuard-ai_autofix.v01.js --repair {f}"
        try:
            result = os.system(cmd)
            if result != 0:
                log_event("autofix_failed", {"file": f, "cmd": cmd})
        except Exception as e:
            log_event("autofix_error", {"file": f, "error": str(e)})

# ============================================================
# 🤖 ADAPTIVE LEARNING SYSTEM
# ============================================================

def adaptive_learning_update(event: str):
    """Update adaptive learning state dynamically."""
    data = load_learning_map()
    hist = data.get("patterns", [])
    hist.append({"event": event, "time": datetime.utcnow().isoformat()})
    data["patterns"] = hist[-200:]
    data.setdefault("adaptive_thresholds", {})["behavior"] = min(
        0.98, CONFIG["threshold"] + len(hist) / 10000)
    with open(CONFIG["learning_map"], "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    log_event("learning_updated", {"new_threshold": data["adaptive_thresholds"]["behavior"]})

# ============================================================
# 🚀 MAIN DETECTION CYCLE
# ============================================================

def run_cycle():
    """Run detection cycle with full flow."""
    try:
        metrics = {"cpu_load": random.random(), "latency": random.random()}
        if analyze_metrics(metrics):
            adaptive_learning_update("behavioral_anomaly")

        anomalies = verify_integrity()
        if anomalies and CONFIG["auto_recover"]:
            trigger_autofix(anomalies)

    except Exception as e:
        log_event("cycle_error", {"error": str(e)})

# ============================================================
# 🌐 ADMIN PANEL (aiohttp)
# ============================================================

async def handle_logs(request):
    if request.headers.get("X-API-KEY") != CONFIG["admin_api_key"]:
        return web.Response(status=403, text="Forbidden")
    return web.json_response(safe_json_array(CONFIG["alert_path"]))

async def handle_status(request):
    return web.json_response({"status": "running", "version": CONFIG["version"], "uptime": datetime.utcnow().isoformat()})

async def start_admin_api():
    """Asynchronous web API for admin monitoring."""
    app = web.Application()
    app.router.add_get("/logs", handle_logs)
    app.router.add_get("/status", handle_status)
    runner = web.AppRunner(app)
    await runner.setup()
    try:
        site = web.TCPSite(runner, "0.0.0.0", CONFIG["admin_port"])
        await site.start()
        log_event("admin_api_started", {"port": CONFIG["admin_port"]})
        while True:
            await asyncio.sleep(3600)
    except OSError:
        log_event("admin_port_in_use", {"port": CONFIG["admin_port"]})

# ============================================================
# 🛰 EXECUTION ENGINE
# ============================================================

def main_loop():
    """Threaded loop for continuous anomaly monitoring."""
    threading.Thread(target=lambda: asyncio.run(start_admin_api()), daemon=True).start()
    log_event("system_start", {"version": CONFIG["version"]})
    while True:
        try:
            run_cycle()
            time.sleep(CONFIG["cooldown_sec"])
        except Exception as e:
            log_event("fatal_error", {"trace": traceback.format_exc()})
            time.sleep(10)

# ============================================================
# 🌀 ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main_loop()
    
    import os
import sys
import time
import json
import hashlib
import random
import traceback
import threading
import asyncio
import aiohttp
from aiohttp import web
from datetime import datetime
from typing import Dict, Any, List

# ============================================================
# 🔰 CONFIGURATION
# ============================================================

CONFIG = {
    "tag": "03_anomaly_detector",
    "version": "v1.7-FINAL-ENTERPRISE",
    "mode": "hybrid",
    "telemetry_api": "https://api.vortexhub.app/telemetry",
    "alert_path": "./logs/anomaly_alerts.json",
    "integrity_check_path": "./runtime/hash_index.json",
    "threshold": 0.92,
    "cooldown_sec": 30,
    "auto_recover": True,
    "admin_api_key": "secure_admin_token",
    "admin_port": 8080,
    "alert_channels": ["email", "telegram", "webhook"],
    "linked_modules": [
        "./ai_core_logic.py",
        "./04_vortex_telemetry.v01.py",
        "./07_ai_memory_handler.v01.py",
        "./LifeGuard-ai_autofix.v01.js"
    ],
    "learning_map": "./ai_learning_map.json"
}

os.makedirs(os.path.dirname(CONFIG["alert_path"]), exist_ok=True)
os.makedirs(os.path.dirname(CONFIG["integrity_check_path"]), exist_ok=True)

# ============================================================
# ⚙️ UTILITY FUNCTIONS
# ============================================================

def calc_file_hash(path: str) -> str:
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return "ERR"

def safe_json_load(path: str):
    try:
        if os.path.exists(path) and os.path.getsize(path) > 0:
            with open(path, "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def safe_json_array(path: str):
    data = safe_json_load(path)
    return data if isinstance(data, list) else []

def log_event(event_type: str, details: Dict[str, Any]):
    try:
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "type": event_type,
            "details": details
        }
        data = safe_json_array(CONFIG["alert_path"])
        data.append(entry)
        with open(CONFIG["alert_path"], "w", encoding="utf-8") as f:
            json.dump(data[-1000:], f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[LOG_ERROR] {e}")

# ============================================================
# 🧠 CORE ANALYTICS ENGINE
# ============================================================

def load_learning_map():
    data = safe_json_load(CONFIG["learning_map"])
    if not 
        data = {"adaptive_thresholds": {}, "patterns": []}
    return data

def analyze_metrics(metrics: Dict[str, float]) -> bool:
    learn = load_learning_map()
    dynamic_threshold = learn.get("adaptive_thresholds", {}).get("behavior", CONFIG["threshold"])
    cpu = metrics.get("cpu_load", random.uniform(0.3, 0.8))
    latency = metrics.get("latency", random.uniform(0.2, 0.9))
    score = round((cpu + latency) / 2, 3)
    log_event("metrics_collected", {"cpu": cpu, "latency": latency, "score": score})
    if score > dynamic_threshold:
        log_event("behavioral_anomaly", {"score": score, "threshold": dynamic_threshold})
        return True
    return False

def verify_integrity() -> List[str]:
    anomalies = []
    base = safe_json_load(CONFIG["integrity_check_path"])
    if isinstance(base, dict):
        for file, ref in base.items():
            current = calc_file_hash(file)
            if current != ref:
                anomalies.append(file)
                log_event("integrity_anomaly", {"file": file, "expected": ref, "found": current})
    return anomalies

def trigger_autofix(targets: List[str]):
    for f in targets:
        log_event("autofix_triggered", {"file": f})
        cmd = f"node LifeGuard-ai_autofix.v01.js --repair {f}"
        try:
            result = os.system(cmd)
            if result != 0:
                log_event("autofix_failed", {"file": f, "cmd": cmd})
        except Exception as e:
            log_event("autofix_error", {"file": f, "error": str(e)})

# ============================================================
# 🤖 ADAPTIVE LEARNING SYSTEM
# ============================================================

def adaptive_learning_update(event: str):
    data = load_learning_map()
    hist = data.get("patterns", [])
    hist.append({"event": event, "time": datetime.utcnow().isoformat()})
    data["patterns"] = hist[-200:]
    data.setdefault("adaptive_thresholds", {})["behavior"] = min(0.98, CONFIG["threshold"] + len(hist) / 10000)
    with open(CONFIG["learning_map"], "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    log_event("learning_updated", {"new_threshold": data["adaptive_thresholds"]["behavior"]})

# ============================================================
# 🚀 MAIN DETECTION CYCLE
# ============================================================

def run_cycle():
    try:
        metrics = {"cpu_load": random.random(), "latency": random.random()}
        if analyze_metrics(metrics):
            adaptive_learning_update("behavioral_anomaly")

        anomalies = verify_integrity()
        if anomalies and CONFIG["auto_recover"]:
            trigger_autofix(anomalies)
    except Exception as e:
        log_event("cycle_error", {"error": str(e)})

# ============================================================
# 🌐 ADMIN PANEL (aiohttp)
# ============================================================

async def handle_logs(request):
    if request.headers.get("X-API-KEY") != CONFIG["admin_api_key"]:
        return web.Response(status=403, text="Forbidden")
    return web.json_response(safe_json_array(CONFIG["alert_path"]))

async def handle_status(request):
    return web.json_response({"status": "running", "version": CONFIG["version"], "uptime": datetime.utcnow().isoformat()})

async def start_admin_api():
    app = web.Application()
    app.router.add_get("/logs", handle_logs)
    app.router.add_get("/status", handle_status)
    runner = web.AppRunner(app)
    await runner.setup()
    try:
        site = web.TCPSite(runner, "0.0.0.0", CONFIG["admin_port"])
        await site.start()
        log_event("admin_api_started", {"port": CONFIG["admin_port"]})
        while True:
            await asyncio.sleep(3600)
    except OSError:
        log_event("admin_port_in_use", {"port": CONFIG["admin_port"]})

# ============================================================
# 🛰 EXECUTION ENGINE
# ============================================================

def main_loop():
    threading.Thread(target=lambda: asyncio.run(start_admin_api()), daemon=True).start()
    log_event("system_start", {"version": CONFIG["version"]})
    while True:
        try:
            run_cycle()
            time.sleep(CONFIG["cooldown_sec"])
        except Exception:
            log_event("fatal_error", {"trace": traceback.format_exc()})
            time.sleep(10)

# ============================================================
# 🌀 ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main_loop()

# ============================================================
# 🌐 VortexHub Telemetry Core (v1.0-STABLE-ENTERPRISE)
# Author: Dr. S. M. H. Sadat / VortexHub Labs
# Purpose: Secure telemetry relay between local anomaly modules and API Core
# Dependencies: asyncio, aiohttp, anomaly_detector, memory_handler
# ============================================================

import os
import sys
import time
import json
import asyncio
import hashlib
import traceback
import random
import aiohttp
from datetime import datetime
from typing import Dict, Any

# ============================================================
# 🔰 GLOBAL CONFIGURATION
# ============================================================

CONFIG = {
    "tag": "04_vortex_telemetry",
    "version": "v1.0-STABLE-ENTERPRISE",
    "telemetry_endpoint": "https://api.vortexhub.app/telemetry",
    "auth_token": "vx_secure_token",
    "max_retry": 3,
    "cooldown_sec": 15,
    "cache_path": "./runtime/telemetry_cache.json",
    "log_path": "./logs/telemetry_events.json",
    "linked_modules": [
        "./03_anomaly_detector.py",
        "./07_ai_memory_handler.v01.py",
    ],
}

os.makedirs(os.path.dirname(CONFIG["cache_path"]), exist_ok=True)
os.makedirs(os.path.dirname(CONFIG["log_path"]), exist_ok=True)

# ============================================================
# ⚙️ UTILITIES
# ============================================================

def safe_json_load(path: str):
    try:
        if os.path.exists(path) and os.path.getsize(path) > 0:
            with open(path, "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def log_event(event_type: str, details: Dict[str, Any]):
    """Centralized logging for telemetry operations."""
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "type": event_type,
        "details": details
    }
    try:
        data = []
        if os.path.exists(CONFIG["log_path"]):
            with open(CONFIG["log_path"], "r", encoding="utf-8") as f:
                data = json.load(f)
        data.append(entry)
        with open(CONFIG["log_path"], "w", encoding="utf-8") as f:
            json.dump(data[-1000:], f, indent=2)
    except Exception as e:
        print(f"[LOG_ERROR] {e}")

def calc_file_hash(file_path: str) -> str:
    """SHA256 hash utility for verification."""
    try:
        with open(file_path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return "ERR_HASH"

# ============================================================
# 📡 TELEMETRY CORE ENGINE
# ============================================================

async def send_payload(session: aiohttp.ClientSession, payload: Dict[str, Any]):
    """Send payload securely to telemetry API."""
    headers = {
        "Authorization": f"Bearer {CONFIG['auth_token']}",
        "Content-Type": "application/json"
    }
    try:
        async with session.post(CONFIG["telemetry_endpoint"], json=payload, headers=headers) as resp:
            text = await resp.text()
            if resp.status == 200:
                log_event("telemetry_sent", {"status": resp.status, "response": text})
            else:
                log_event("telemetry_error", {"status": resp.status, "response": text})
    except Exception as e:
        log_event("telemetry_exception", {"error": str(e)})

async def send_telemetry_report(data: Dict[str, Any]):
    """Core async sender with retry and fallback."""
    retry = 0
    async with aiohttp.ClientSession() as session:
        while retry < CONFIG["max_retry"]:
            try:
                payload = {
                    "tag": CONFIG["tag"],
                    "version": CONFIG["version"],
                    "timestamp": datetime.utcnow().isoformat(),
                    "system": os.uname().sysname if hasattr(os, "uname") else "UNKNOWN",
                    "data": data
                }
                await send_payload(session, payload)
                return True
            except Exception as e:
                retry += 1
                log_event("retry", {"attempt": retry, "error": str(e)})
                await asyncio.sleep(CONFIG["cooldown_sec"])
    log_event("telemetry_failed", {"data": data})
    return False

# ============================================================
# 🧠 AUTO DATA COLLECTION (Integration Bridge)
# ============================================================

def collect_anomaly_summary() -> Dict[str, Any]:
    """Pull data from anomaly logs for remote sync."""
    anomaly_log = safe_json_load("./logs/anomaly_alerts.json")
    summary = {
        "total_events": len(anomaly_log) if isinstance(anomaly_log, list) else 0,
        "last_event": anomaly_log[-1] if isinstance(anomaly_log, list) and anomaly_log else {},
        "avg_cpu_score": 0.0,
        "avg_latency_score": 0.0
    }

    # Compute average metrics
    if isinstance(anomaly_log, list):
        metrics = [e for e in anomaly_log if e.get("type") == "metrics_collected"]
        if metrics:
            avg_cpu = sum(x["details"]["cpu"] for x in metrics) / len(metrics)
            avg_latency = sum(x["details"]["latency"] for x in metrics) / len(metrics)
            summary["avg_cpu_score"] = round(avg_cpu, 3)
            summary["avg_latency_score"] = round(avg_latency, 3)

    return summary

# ============================================================
# 🔄 TELEMETRY LOOP
# ============================================================

async def telemetry_cycle():
    """Periodic telemetry cycle that runs autonomously."""
    while True:
        try:
            summary = collect_anomaly_summary()
            summary["hash_check"] = calc_file_hash("./03_anomaly_detector.py")
            summary["random_seed"] = random.randint(10000, 99999)
            await send_telemetry_report(summary)
            await asyncio.sleep(CONFIG["cooldown_sec"])
        except Exception as e:
            log_event("telemetry_cycle_error", {"error": str(e)})
            await asyncio.sleep(10)

# ============================================================
# 🛰 EXECUTION ENGINE
# ============================================================

def start_telemetry_loop():
    """Launch telemetry loop asynchronously in safe mode."""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(telemetry_cycle())
    except KeyboardInterrupt:
        print("Telemetry stopped manually.")
    except Exception as e:
        log_event("telemetry_fatal", {"error": str(e)})

# ============================================================
# 🌀 ENTRY POINT
# ============================================================

if __name__ == "__main__":
    print(f"[VortexHub Telemetry] Running {CONFIG['version']}")
    log_event("telemetry_start", {"version": CONFIG["version"]})
    start_telemetry_loop()
    

