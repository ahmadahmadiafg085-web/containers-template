package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os/exec"
	"sync"
)

// ====================================
// EXECUTOR INTERFACE (Strategy Pattern)
// ====================================

type Executor interface {
	Exec(funcName string, args []interface{}) (interface{}, error)
}

// ====================================
// GO EXECUTOR
// ====================================

type GoExecutor struct {
	functions map[string]interface{}
}

func NewGoExecutor() *GoExecutor {
	return &GoExecutor{
		functions: map[string]interface{}{
			"add": func(a, b float64) float64 { return a + b },
			"mul": func(a, b float64) float64 { return a * b },
			"ping": func() string { return "pong-go" },
		},
	}
}

func (g *GoExecutor) Exec(funcName string, args []interface{}) (interface{}, error) {
	fn, ok := g.functions[funcName]
	if !ok {
		return nil, errors.New("go function not found")
	}

	switch f := fn.(type) {
	case func(a, b float64) float64:
		return f(toF(args[0]), toF(args[1])), nil
	case func() string:
		return f(), nil
	default:
		return nil, errors.New("unsupported go function signature")
	}
}

// ====================================
// PYTHON EXECUTOR (Isolated Runtime)
// ====================================

type PythonExecutor struct {
	bin string
}

func NewPythonExecutor(bin string) *PythonExecutor {
	if bin == "" {
		bin = "python3"
	}
	return &PythonExecutor{bin: bin}
}

func (p *PythonExecutor) Exec(funcName string, args []interface{}) (interface{}, error) {
	script := `
import sys, json, math

def add(a,b): return a+b
def mul(a,b): return a*b
def ping(): return "pong-py"

funcs = { "add":add, "mul":mul, "ping":ping }

name = sys.argv[1]
args = json.loads(sys.argv[2])

if name in funcs:
    fn = funcs[name]
    if callable(fn):
        # handle variable args
        result = fn(*args) if args else fn()
        print(json.dumps(result))
`

	argsJSON, _ := json.Marshal(args)
	cmd := exec.Command(p.bin, "-c", script, funcName, string(argsJSON))

	var out, stderr bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("python error: %s", stderr.String())
	}

	var res interface{}
	json.Unmarshal(out.Bytes(), &res)
	return res, nil
}

// ====================================
// ADAPTER (Language-Agnostic)
// ====================================

type Adapter struct {
	executor Executor
	cache    map[string][]byte
	mu       sync.RWMutex
}

func NewAdapter(exec Executor) *Adapter {
	return &Adapter{
		executor: exec,
		cache:    make(map[string][]byte),
	}
}

// ------------- CACHE -------------
func (a *Adapter) cacheKey(name string, args []interface{}) string {
	b, _ := json.Marshal(args)
	return name + "_" + string(b)
}
func (a *Adapter) getCache(key string, dst interface{}) bool {
	a.mu.RLock()
	defer a.mu.RUnlock()
	data, ok := a.cache[key]
	if !ok {
		return false
	}
	json.Unmarshal(data, dst)
	return true
}
func (a *Adapter) setCache(key string, val interface{}) {
	a.mu.Lock()
	defer a.mu.Unlock()
	b, _ := json.Marshal(val)
	a.cache[key] = b
}

// ------------- CALL -------------
func (a *Adapter) Call(funcName string, args ...interface{}) (interface{}, error) {
	key := a.cacheKey(funcName, args)

	var cached interface{}
	if a.getCache(key, &cached) {
		return cached, nil
	}

	out, err := a.executor.Exec(funcName, args)
	if err != nil {
		return nil, err
	}

	a.setCache(key, out)
	return out, nil
}

// ------------- HTTP HANDLER -------------
func (a *Adapter) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	funcName := r.URL.Query().Get("func")
	if funcName == "" {
		http.Error(w, "func missing", 400)
		return
	}

	var args []interface{}
	json.NewDecoder(r.Body).Decode(&args)

	res, err := a.Call(funcName, args...)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(res)
}

// ====================================
// UTIL
// ====================================
func toF(v interface{}) float64 {
	switch x := v.(type) {
	case float64:
		return x
	case int:
		return float64(x)
	default:
		return 0
	}
}

// ====================================
// MAIN (Runtime binding)
// ====================================

func main() {
	goAdapter := NewAdapter(NewGoExecutor())
	pyAdapter := NewAdapter(NewPythonExecutor("python3"))

	fmt.Println("Go add:", must(goAdapter.Call("add", 3, 9)))
	fmt.Println("Py mul:", must(pyAdapter.Call("mul", 4, 8)))
	fmt.Println("Ping go:", must(goAdapter.Call("ping")))
	fmt.Println("Ping py:", must(pyAdapter.Call("ping")))

	http.Handle("/adapter/go", goAdapter)
	http.Handle("/adapter/py", pyAdapter)

	fmt.Println("Serving on :8080")
	http.ListenAndServe(":8080", nil)
}

func must(v interface{}, err error) interface{} {
	if err != nil {
		panic(err)
	}
	return v
}
