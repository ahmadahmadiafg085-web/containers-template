# ============================================================
# adapter_internal_to_admin-2.py
# Full 300-line operational bridge engine for Admin <-> Internal
# Author: VortexHub Labs - Dr. S.M.H. SADAT
# ============================================================

import time
import json
import threading
import queue
import traceback
import hashlib
import os
import uuid
import base64
import hmac
import random
from typing import Callable, Dict, Any, List, Optional

# ============================================================
# LINE 20 — CONFIG
# ============================================================

class Config:
    SECRET_KEY = b”vortexhub-internal-admin-secret”
    TOKEN_EXPIRY = 3600
    RATE_LIMIT = 50
    MAX_QUEUE = 10000
    METRICS_INTERVAL = 5
    PLUGIN_FOLDER = “./plugins”
    LOG_LEVEL = “DEBUG”


# ============================================================
# LINE 50 — LOGGER
# ============================================================

class Logger:
    @staticmethod
    def log(level: str, msg: str):
        if Config.LOG_LEVEL == “DEBUG” or level != “DEBUG”:
            t = time.strftime(“%H:%M:%S”)
            print(f”[{level}][{t}] {msg}”)

    @staticmethod
    def info(msg): Logger.log(“INFO”, msg)
    @staticmethod
    def debug(msg): Logger.log(“DEBUG”, msg)
    @staticmethod
    def warn(msg): Logger.log(“WARN”, msg)
    @staticmethod
    def error(msg): Logger.log(“ERROR”, msg)


# ============================================================
# LINE 90 — MEMORY CACHE
# ============================================================

class MemoryCache:
    def __init__(self):
        self.data = {}
        self.lock = threading.Lock()

    def set(self, key, value, ttl=120):
        with self.lock:
            self.data[key] = (value, time.time() + ttl)

    def get(self, key):
        with self.lock:
            if key not in self.data:
                return None
            value, exp = self.data[key]
            if time.time() > exp:
                del self.data[key]
                return None
            return value

    def clear_expired(self):
        with self.lock:
            keys = list(self.data.keys())
            for k in keys:
                _, exp = self.data[k]
                if time.time() > exp:
                    del self.data[k]


# ============================================================
# LINE 130 — AUTHENTICATION LAYER
# ============================================================

class Auth:
    @staticmethod
    def generate_token(user_id: str):
        ts = str(int(time.time()))
        sign = hmac.new(Config.SECRET_KEY, (user_id + ts).encode(), hashlib.sha256).hexdigest()
        token = base64.b64encode(f”{user_id}:{ts}:{sign}”.encode()).decode()
        return token

    @staticmethod
    def verify_token(token: str) -> bool:
        try:
            raw = base64.b64decode(token).decode()
            user_id, ts, sign = raw.split(“:”)
            if time.time() - int(ts) > Config.TOKEN_EXPIRY:
                return False
            expected = hmac.new(Config.SECRET_KEY, (user_id + ts).encode(), hashlib.sha256).hexdigest()
            return hmac.compare_digest(expected, sign)
        except Exception:
            return False


# ============================================================
# LINE 170 — RATE LIMITER
# ============================================================

class RateLimiter:
    def __init__(self):
        self.calls = {}
        self.lock = threading.Lock()

    def allow(self, key):
        with self.lock:
            now = time.time()
            if key not in self.calls:
                self.calls[key] = []
            calls = self.calls[key]
            while calls and now - calls[0] > 1:
                calls.pop(0)
            if len(calls) >= Config.RATE_LIMIT:
                return False
            calls.append(now)
            return True


# ============================================================
# LINE 200 — EVENT BUS
# ============================================================

class EventBus:
    def __init__(self):
        self.handlers: Dict[str, List[Callable]] = {}

    def on(self, event: str, handler: Callable):
        if event not in self.handlers:
            self.handlers[event] = []
        self.handlers[event].append(handler)

    def emit(self, event: str, payload):
        if event not in self.handlers:
            return
        for h in self.handlers[event]:
            try:
                h(payload)
            except Exception as e:
                Logger.error(f”Event handler error: {e}”)


# ============================================================
# LINE 230 — FUNCTION REGISTRY
# ============================================================

class FunctionRegistry:
    def __init__(self):
        self.registry = {}

    def register(self, name: str, fn: Callable):
        self.registry[name] = fn

    def run(self, name: str, *args, **kwargs):
        if name not in self.registry:
            raise Exception(f”Function ‘{name}’ not found”)
        return self.registry[name](*args, **kwargs)


# ============================================================
# LINE 260 — JOB SYSTEM
# ============================================================

class BackgroundJob:
    def __init__(self, fn, args, kwargs):
        self.fn = fn
        self.args = args
        self.kw = kwargs
        self.id = uuid.uuid4().hex

class JobEngine:
    def __init__(self):
        self.q = queue.Queue(Config.MAX_QUEUE)
        threading.Thread(target=self.worker, daemon=True).start()

    def add(self, fn, *args, **kwargs):
        job = BackgroundJob(fn, args, kwargs)
        self.q.put(job)
        return job.id

    def worker(self):
        while True:
            job = self.q.get()
            try:
                job.fn(*job.args, **job.kw)
            except Exception as e:
                Logger.error(f”Job error: {e}”)


# ============================================================
# LINE 300 — PLUGIN LOADER
# ============================================================

class PluginLoader:
    def __init__(self, registry: FunctionRegistry):
        self.registry = registry

    def load_all(self):
        if not os.path.exists(Config.PLUGIN_FOLDER):
            return
        for file in os.listdir(Config.PLUGIN_FOLDER):
            if file.endswith(“.py”):
                path = os.path.join(Config.PLUGIN_FOLDER, file)
                try:
                    code = open(path).read()
                    env = {}
                    exec(code, env)
                    if “register” in env:
                        env[“register”](self.registry)
                        Logger.info(f”Loaded plugin: {file}”)
                except Exception as e:
                    Logger.error(f”Error loading plugin {file}: {e}”)


# ============================================================
# LINE 330 — ROUTER (ADMIN <-> INTERNAL)
# ============================================================

class AdapterRouter:
    def __init__(self, registry, cache, limiter, events):
        self.registry = registry
        self.cache = cache
        self.limiter = limiter
        self.events = events

    def process(self, token, action: str, payload: dict):
        if not Auth.verify_token(token):
            return {“error”: “unauthorized”}

        key = hashlib.sha1(token.encode()).hexdigest()
        if not self.limiter.allow(key):
            return {“error”: “rate_limit”}

        cache_key = f”{action}:{json.dumps(payload)}”
        cached = self.cache.get(cache_key)
        if cached:
            return {“cached”: True, “data”: cached}

        try:
            result = self.registry.run(action, payload)
            self.cache.set(cache_key, result)
            self.events.emit(“action_executed”, {“action”: action, “payload”: payload})
            return {“ok”: True, “data”: result}
        except Exception as e:
            Logger.error(traceback.format_exc())
            return {“error”: str(e)}


# ============================================================
# LINE 380 — METRICS
# ============================================================

class Metrics:
    def __init__(self):
        self.data = {“requests”: 0, “errors”: 0}
        threading.Thread(target=self.loop, daemon=True).start()

    def inc(self, key):
        self.data[key] += 1

    def loop(self):
        while True:
            time.sleep(Config.METRICS_INTERVAL)
            Logger.info(f”Metrics: {self.data}”)


# ============================================================
# LINE 410 — MAIN ENGINE
# ============================================================

class InternalAdminAdapter:
    def __init__(self):
        self.registry = FunctionRegistry()
        self.cache = MemoryCache()
        self.limiter = RateLimiter()
        self.events = EventBus()
        self.jobs = JobEngine()
        self.metrics = Metrics()

        self.router = AdapterRouter(
            self.registry,
            self.cache,
            self.limiter,
            self.events
        )

        self.load_core_functions()
        PluginLoader(self.registry).load_all()

    # -————————
    # CORE REGISTERED FUNCTIONS
    # -————————
    def load_core_functions(self):
        self.registry.register(“ping”, lambda payload: {“pong”: True})

        def admin_echo(payload):
            return {“echo”: payload, “ts”: time.time()}

        def heavy_process(payload):
            time.sleep(1)
            return {“processed”: True, “data”: payload}

        self.registry.register(“echo”, admin_echo)
        self.registry.register(“heavy”, heavy_process)

    # -————————
    # PUBLIC INTERFACE
    # -————————
    def call(self, token, action, payload):
        self.metrics.inc(“requests”)
        res = self.router.process(token, action, payload)
        if “error” in res:
            self.metrics.inc(“errors”)
        return res


# ============================================================
# LINE 470 — INIT TEST
# ============================================================

if __name__ == “__main__”:
    adapter = InternalAdminAdapter()
    t = Auth.generate_token(“admin”)
    print(adapter.call(t, “ping”, {}))
    print(adapter.call(t, “echo”, {“msg”: “hi”}))
    print(adapter.call(t, “heavy”, {“x”: 10})) 