# advanced_legged_robot.py
import math, threading, time, queue, random
import pyttsx3
from typing import Callable, List, Dict, Any

class RobotError(Exception): pass

# -—————————
# Core Utilities
# -—————————
def clamp(value, min_val, max_val): return max(min_val, min(value, max_val))
def lerp(a, b, t): return a + (b - a) * t
def vector_length(vec): return math.sqrt(sum([x**2 for x in vec]))
def apply_noise(value, noise=0.02): return value + random.uniform(-noise, noise)

# -—————————
# Joint and Limb
# -—————————
class Joint:
    def __init__(self, name: str, min_angle=-180, max_angle=180):
        self.name, self.min_angle, self.max_angle = name, min_angle, max_angle
        self.angle, self.velocity = 0.0, 0.0
    def set_angle(self, angle: float):
        clamped = clamp(angle, self.min_angle, self.max_angle)
        self.velocity = (clamped - self.angle) * 0.3
        self.angle += self.velocity
        self.angle = apply_noise(self.angle, 0.01)

class Limb:
    def __init__(self, name: str, joints: List[Joint]):
        self.name, self.joints = name, joints
        self.stability_factor = 1.0
    def move_to_angles(self, angles: List[float]):
        for i, (joint, angle) in enumerate(zip(self.joints, angles)):
            for _ in range(10):
                delta = (angle - joint.angle) * 0.1
                joint.set_angle(joint.angle + delta)
                joint.angle *= 0.995
                self.stability_factor *= 0.999
                time.sleep(0.002)
        self._stabilize()
    def _stabilize(self):
        for joint in self.joints: joint.angle *= self.stability_factor
        self.stability_factor = 1.0
    def get_angles(self): return [j.angle for j in self.joints]

# -—————————
# Robot Core + Monitoring + Sensors + Learning + Pathfinding
# -—————————
class Robot:
    def __init__(self, limbs: List[Limb]):
        self.limbs = {limb.name: limb for limb in limbs}
        self.lock, self.task_queue, self.running, self.workers = threading.Lock(), queue.Queue(2000), False, []
        self.speech_engine = pyttsx3.init(); self.speech_engine.setProperty(‘rate’, 150)
        self.monitor_data = {“stability”:100.0, “vibration”:0.0, “sensor_inputs”:{}}
        self.movement_memory = {}
        self.environment_map = [[[0]*20 for _ in range(20)] for _ in range(3)]

    def start_workers(self, num_macro=2, num_micro=6):
        self.running = True
        for _ in range(num_macro + num_micro):
            t = threading.Thread(target=self._worker_loop, daemon=True); t.start(); self.workers.append(t)
    def stop_workers(self):
        self.running = False
        for t in self.workers: t.join()

    def _worker_loop(self):
        while self.running:
            try:
                func, args, kwargs, callback = self.task_queue.get(timeout=0.5)
                try: result = func(*args, **kwargs); callback(result) if callback else None
                except Exception as e: callback(e) if callback else None
                self.task_queue.task_done()
            except queue.Empty: continue

    def submit_task(self, func: Callable, args=(), kwargs=None, callback=None):
        kwargs = kwargs or {}; self.task_queue.put((func, args, kwargs, callback))

    # Limb Control + Learning
    def move_limb(self, limb_name: str, angles: List[float], callback=None):
        if limb_name not in self.limbs: raise RobotError(f”Limb {limb_name} not found”)
        limb = self.limbs[limb_name]
        def task(): 
            learned_angles = self.movement_memory.get(limb_name, angles)
            for i in range(10): limb.move_to_angles([lerp(a,b,0.2) for a,b in zip(angles, learned_angles)]); time.sleep(0.02)
            self.movement_memory[limb_name] = limb.get_angles()
            return limb.get_angles()
        self.submit_task(task, callback=callback)

    # Motion Patterns
    def walk_step(self, step_length=0.1, speed=1.0, callback=None):
        def task():
            result = {}
            for step in range(10):
                for limb in self.limbs.values():
                    angles = [random.uniform(-30,30) for _ in limb.joints]
                    limb.move_to_angles([a*1.1 for a in angles])
                    result[limb.name] = limb.get_angles()
                self._update_monitoring()
                time.sleep(0.05 / speed)
            return result
        self.submit_task(task, callback=callback)

    def wave_hand(self, limb_name=‘right_arm’, callback=None):
        if limb_name not in self.limbs: raise RobotError(f”Limb {limb_name} not found”)
        limb = self.limbs[limb_name]
        def task():
            for t in range(10):
                a,b,c = 30*math.sin(t*0.3), -30*math.sin(t*0.3), 45*math.sin(t*0.3)
                limb.move_to_angles([a,b,c])
                time.sleep(0.05)
            self._update_monitoring()
            return limb.get_angles()
        self.submit_task(task, callback=callback)

    # Sensors + Environment Perception
    def sensor_reading(self, sensor_func: Callable, callback=None):
        def task():
            readings = [sensor_func() for _ in range(10)]
            avg = [sum(col)/len(col) for col in zip(*readings)]
            self.monitor_data[“sensor_inputs”][sensor_func.__name__] = avg
            if min(avg)<0.5: self.speak(“Obstacle detected!”)
            self._update_environment_map(avg)
            return avg
        self.submit_task(task, callback=callback)

    def full_scan(self, analyzer: Callable, callback=None):
        def task():
            scores = []
            for _ in range(10): scores.append(analyzer(self)*1.1); time.sleep(0.02)
            avg = sum(scores)/len(scores); self.monitor_data[“stability”]=avg
            return avg
        self.submit_task(task, callback=callback)

    # Speech / Interaction + Behavior Learning
    def speak(self, text: str, limb_movements: dict=None, callback=None):
        def task():
            for t in range(10):
                if limb_movements:
                    for limb_name, angles in limb_movements.items():
                        if limb_name in self.limbs:
                            self.limbs[limb_name].move_to_angles([lerp(a,b,0.2) for a,b in zip(angles, self.movement_memory.get(limb_name, angles))])
                            self.movement_memory[limb_name] = self.limbs[limb_name].get_angles()
                self.speech_engine.say(text); self.speech_engine.runAndWait(); time.sleep(0.05)
            return f”Spoken: {text}”
        self.submit_task(task, callback=callback)

    # Monitoring / Human-like perception
    def _update_monitoring(self):
        total_vib = sum(abs(angle*0.05) for limb in self.limbs.values() for angle in limb.get_angles())
        self.monitor_data[“vibration”] = total_vib
        stability_score = 100.0 - total_vib
        self.monitor_data[“stability”] = clamp(stability_score,0,100)
    def get_monitoring_data(self): return self.monitor_data

    # Pathfinding + Environment Learning
    def _update_environment_map(self, lidar_data):
        for z in range(len(self.environment_map)):
            for i in range(len(self.environment_map[0])):
                for j in range(len(self.environment_map[0][0])):
                    self.environment_map[z][i][j] = min(lidar_data[i%360],10.0)
    def find_path(self, start: tuple, goal: tuple):
        open_set={start}; came_from={}; g_score={start:0}; f_score={start:vector_length([s-g for s,g in zip(start,goal)])}
        while open_set:
            current = min(open_set, key=lambda x: f_score.get(x,float(‘inf’)))
            if current==goal: break
            open_set.remove(current)
            x,y=current
            neighbors=[(clamp(x+dx,0,19),clamp(y+dy,0,19)) for dx in [-1,0,1] for dy in [-1,0,1] if not (dx==0 and dy==0)]
            for n in neighbors:
                tentative_g = g_score[current]+1+self.environment_map[0][n[0]][n[1]]*0.1
                if tentative_g<g_score.get(n,float(‘inf’)):
                    came_from[n]=current; g_score[n]=tentative_g; f_score[n]=tentative_g+vector_length([n[0]-goal[0], n[1]-goal[1]])
                    open_set.add(n)
        path=[]; c=goal
        while c in came_from: path.insert(0,c); c=came_from[c]
        return path

# -—————————
# Sensors
# -—————————
def lidar_scan(): return [[random.uniform(0.2,10.0) for _ in range(360)] for _ in range(10)]
def balance_analyzer(robot: Robot):
    score = 100.0
    for limb in robot.limbs.values():
        for angle in limb.get_angles(): score -= abs(angle)*0.1
    return max(score,0)

# -—————————
# Robot Definition
# -—————————
joints_leg = [Joint(‘hip’, -45, 45), Joint(‘knee’,0,90), Joint(‘ankle’,-30,30)]
joints_arm = [Joint(‘shoulder’, -60,60), Joint(‘elbow’,0,135), Joint(‘wrist’,-45,45)]
limbs = [
    Limb(‘front_left_leg’, joints_leg),
    Limb(‘front_right_leg’, joints_leg),
    Limb(‘rear_left_leg’, joints_leg),
    Limb(‘rear_right_leg’, joints_leg),
    Limb(‘left_arm’, joints_arm),
    Limb(‘right_arm’, joints_arm),
    Limb(‘head’, [Joint(‘neck’, -45,45)]),
    Limb(‘tail’, [Joint(‘tail_base’, -60,60)])
]
robot = Robot(limbs)
robot.start_workers(num_macro=2,num_micro=6)

# -—————————
# Usage Example
# -—————————
if __name__==“__main__”:
    def print_result(res): print(res)

    robot.walk_step(callback=print_result)
    robot.wave_hand(‘right_arm’, callback=print_result)
    robot.sensor_reading(lidar_scan, callback=print_result)
    robot.full_scan(lambda: balance_analyzer(robot), callback=print_result)
    robot.speak(“سلام، من ربات چندپا هستم و محیط را درک می‌کنم!”, limb_movements={“head”:[0,15,-15], “right_arm”:[30,-10,20]}, callback=print_result)
    path = robot.find_path((0,0),(15,15))
    print(“Calculated Path:”, path)
    time.sleep(1)
    print(“Monitoring Data:”, robot.get_monitoring_data())
    robot.task_queue.join()
    robot.stop_workers()