import path from "path";
import fs from "fs";
import { spawn } from "child_process";
import { EventEmitter } from "events";
import crypto from "crypto";

interface ModuleConfig {
  path: string;
  version: string;
  hash_base64?: string;
  dependencies?: string[];
  pre_hooks?: string[];
  post_hooks?: string[];
  priority?: number;
  scheduled?: string;
  resource_limits?: { cpu?: number; memory?: number };
}

interface AdapterConfig {
  class: string;
  node_id: string;
  description: string;
  events?: string[];
  modules: Record<string, ModuleConfig>;
}

interface OrchestratorConfig {
  class: string;
  adapters: string[];
  metrics_enabled: boolean;
  retry_policy?: { maxRetries: number; delayMs: number };
}

export class BackendWrapper extends EventEmitter {
  private adapters: Record<string, AdapterConfig>;
  private orchestrator: OrchestratorConfig;
  private baseDir: string;
  private executedModules = new Set<string>();
  private moduleStates: Record<string, string> = {}; // idle, running, failed, completed

  constructor(adapters: Record<string, AdapterConfig>, orchestrator: OrchestratorConfig, baseDir = ".") {
    super();
    this.adapters = adapters;
    this.orchestrator = orchestrator;
    this.baseDir = baseDir;
  }

  private async verifyHash(module: ModuleConfig, modulePath: string) {
    if (!module.hash_base64) return true;
    const buf = fs.readFileSync(modulePath);
    const hash = crypto.createHash("sha256").update(buf).digest("base64");
    if (hash !== module.hash_base64) throw new Error(`Hash mismatch for ${modulePath}`);
    return true;
  }

  private async spawnModule(modulePath: string, args: string[] = []) {
    if (!fs.existsSync(modulePath)) throw new Error(`Module not found: ${modulePath}`);
    return new Promise<void>((resolve, reject) => {
      const proc = spawn("node", [modulePath, ...args], { stdio: "inherit" });
      proc.on("close", code => code === 0 ? resolve() : reject(new Error(`Exited with code ${code}`)));
      proc.on("error", reject);
    });
  }

  private async runHooks(adapterName: string, moduleName: string, hooks?: string[]) {
    if (!hooks) return;
    for (const hook of hooks) await this.executeModule(adapterName, hook);
  }

  async loadModule(adapterName: string, moduleName: string) {
    const adapter = this.adapters[adapterName];
    if (!adapter) throw new Error(`Adapter ${adapterName} not found`);
    const module = adapter.modules[moduleName];
    if (!module) throw new Error(`Module ${moduleName} not in ${adapterName}`);

    const modulePath = path.resolve(this.baseDir, module.path);
    this.verifyHash(module, modulePath);

    await this.runHooks(adapterName, moduleName, module.pre_hooks);
    await this.spawnModule(modulePath);
    await this.runHooks(adapterName, moduleName, module.post_hooks);
  }

  async executeModule(adapterName: string, moduleName: string, args: string[] = [], retryCount = 0) {
    try {
      const module = this.adapters[adapterName].modules[moduleName];
      if (!module) throw new Error(`Module not found: ${moduleName}`);

      this.emit("module_start", { adapterName, moduleName });
      this.moduleStates[`${adapterName}.${moduleName}`] = "running";

      await this.runHooks(adapterName, moduleName, module.pre_hooks);

      const modulePath = path.resolve(this.baseDir, module.path);
      this.verifyHash(module, modulePath);

      await this.spawnModule(modulePath, args);

      await this.runHooks(adapterName, moduleName, module.post_hooks);

      this.executedModules.add(`${adapterName}.${moduleName}`);
      this.moduleStates[`${adapterName}.${moduleName}`] = "completed";

      this.emit("module_executed", { adapterName, moduleName });

    } catch (err) {
      this.moduleStates[`${adapterName}.${moduleName}`] = "failed";

      if (retryCount < (this.orchestrator.retry_policy?.maxRetries || 0)) {
        setTimeout(
          () => this.executeModule(adapterName, moduleName, args, retryCount + 1),
          this.orchestrator.retry_policy?.delayMs || 1000
        );
      } else {
        this.emit("module_error", { adapterName, moduleName, error: err });
      }
    }
  }

  async runAllModules(adapterName: string) {
    const adapter = this.adapters[adapterName];
    if (!adapter) throw new Error(`Adapter ${adapterName} not found`);

    const executed = new Set<string>();
    const runModuleWithDeps = async (name: string) => {
      if (executed.has(name)) return;
      const mod = adapter.modules[name];
      if (!mod) throw new Error(`Module ${name} missing`);
      if (mod.dependencies) for (const dep of mod.dependencies) await runModuleWithDeps(dep);
      await this.executeModule(adapterName, name);
      executed.add(name);
    };

    const moduleNames = Object.keys(adapter.modules)
      .sort((a, b) => (adapter.modules[b].priority || 0) - (adapter.modules[a].priority || 0));

    for (const name of moduleNames) await runModuleWithDeps(name);
  }

  async runScheduledModules(adapterName: string) {
    const adapter = this.adapters[adapterName];
    if (!adapter) throw new Error(`Adapter not found: ${adapterName}`);

    for (const [name, mod] of Object.entries(adapter.modules)) {
      if (mod.scheduled) {
        this.emit("scheduled_pending", { adapterName, name, schedule: mod.scheduled });
      }
    }
  }

  collectMetrics() {
    const internal = this.adapters.internal?.modules;
    if (!internal) return;

    ["telemetry_bridge", "audit_logger", "state_router", "execution_pipeline"]
      .forEach(name => internal[name] && this.executeModule("internal", name, ["--report"]));
  }

  async recover() {
    const internal = this.adapters.internal?.modules;
    if (!internal) return;

    if (internal.manifest_loader) await this.executeModule("internal", "manifest_loader", ["--recover"]);
    if (internal.cache_manager) await this.executeModule("internal", "cache_manager", ["--reset"]);
    if (internal.auto_debugger) await this.executeModule("internal", "auto_debugger", ["--repair"]);
  }

  async hotReloadModule(adapterName: string, moduleName: string) {
    await this.loadModule(adapterName, moduleName);
  }

  async dryRunModule(adapterName: string, moduleName: string) {
    console.log(`Dry-run for ${adapterName}.${moduleName}`);
  }
}

/*
// Example Usage
import { adaptersConfig, orchestratorConfig } from './config';
const backend = new BackendWrapper(adaptersConfig, orchestratorConfig);
backend.on("module_executed", ({ adapterName, moduleName }) => console.log(`${adapterName}.${moduleName} executed`));
backend.on("module_error", ({ adapterName, moduleName, error }) => console.error(`${adapterName}.${moduleName} failed:`, error));
backend.runAllModules("internal"); 
backend.collectMetrics();
*/
