import os, time, json, threading, hashlib
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from datetime import datetime

USERS = {
 “admin”:{“permissions”:[“read”,”write”,”delete”,”system_change”,”usb_access”]},
 “guest”:{“permissions”:[“read”]}
}

EVENT_LOG_FILE=“events_log.json”
LOG_BUFFER=[]; LOG_LOCK=threading.Lock()

def _sign(obj):
 raw=json.dumps(obj,sort_keys=True).encode()
 return hashlib.sha256(raw).hexdigest()

def log_event(event_type,details):
 with LOG_LOCK:
  LOG_BUFFER.append({
   “timestamp”:datetime.now().isoformat(),
   “event_type”:event_type,
   “details”:details,
   “signature”:_sign(details)
  })

def _flush_logs():
 while True:
  time.sleep(0.8)
  with LOG_LOCK:
   if not LOG_BUFFER: continue
   try:
    existing=[]
    if os.path.exists(EVENT_LOG_FILE):
     with open(EVENT_LOG_FILE,”r”) as f: existing=json.load(f)
    existing.extend(LOG_BUFFER[:])
    LOG_BUFFER.clear()
    with open(EVENT_LOG_FILE,”w”) as f: json.dump(existing,f,separators=(“,”,”:”))
   except Exception as e:
    print(“[LOG ERROR]”,e)

threading.Thread(target=_flush_logs,daemon=True).start()

class AccessControl:
 def __init__(self,users): self.users=users
 def check(self,username,action):
  role=self.users.get(username)
  return bool(role and action in role.get(“permissions”,[]))

class EventManager:
 def __init__(self): self.l={}; self.lock=threading.Lock()
 def register(self,e,cb):
  with self.lock: self.l.setdefault(e,[]).append(cb)
 def trigger(self,e,**kw):
  for cb in self.l.get(e,[]): 
   try: cb(**kw)
   except Exception as x: print(“[CB ERROR]”,x)

class WindowsEventSimulator(FileSystemEventHandler):
 def __init__(self,em): self.em=em
 def on_created(self,e): self.em.trigger(“file_created”,path=e.src_path)
 def on_modified(self,e): self.em.trigger(“file_modified”,path=e.src_path)
 def on_deleted(self,e): self.em.trigger(“file_deleted”,path=e.src_path)

ac = AccessControl(USERS)
em = EventManager()

def on_access_request(username,action):
 allowed = ac.check(username,action)
 print(f”[ACCESS] {username} {action} → {allowed}”)
 log_event(“access_request”,{“user”:username,”action”:action,”allowed”:allowed})

def on_file_created(path):
 print(“[EVENT] File created:”,path)
 log_event(“file_created”,{“path”:path})
 em.trigger(“access_request”,username=“guest”,action=“read”)

def on_file_modified(path):
 print(“[EVENT] File modified:”,path)
 log_event(“file_modified”,{“path”:path})
 em.trigger(“access_request”,username=“admin”,action=“write”)

def on_file_deleted(path):
 print(“[EVENT] File deleted:”,path)
 log_event(“file_deleted”,{“path”:path})
 em.trigger(“access_request”,username=“admin”,action=“delete”)

def on_user_login(username):
 print(“[EVENT] Login:”,username)
 log_event(“login”,{“user”:username})
 em.trigger(“access_request”,username=username,action=“read”)

def on_system_change(username,desc):
 print(“[EVENT] System change:”,desc)
 log_event(“system_change”,{“user”:username,”change”:desc})
 em.trigger(“access_request”,username=username,action=“system_change”)

events=[
 (“access_request”,on_access_request),
 (“file_created”,on_file_created),
 (“file_modified”,on_file_modified),
 (“file_deleted”,on_file_deleted)
]

for ev,cb in events: em.register(ev,cb)

os.makedirs(“watched_folder”,exist_ok=True)
observer=Observer()
observer.schedule(WindowsEventSimulator(em),”watched_folder”,recursive=True)
observer.start()
print(“[INFO] Windows Event Monitor → Active”)

def simulate_events():
 time.sleep(1)
 on_user_login(“admin”)
 time.sleep(1)
 on_user_login(“guest”)
 time.sleep(1)
 on_system_change(“admin”,”Firewall modified”)
 time.sleep(1)
 on_file_created(“demo.txt”)

threading.Thread(target=simulate_events,daemon=True).start()

try:
 while True: time.sleep(1)
except KeyboardInterrupt:
 observer.stop()
observer.join()