# smart_file_text_intelligence.py
import os
import re
from typing import List, Dict, Any
from collections import Counter, defaultdict

class SmartFileAnalyzer:
    “””Advanced standalone analyzer with learning, automation, and content intelligence.”””
    
    DEFAULT_CODE_PATTERNS = [
        r”```[\s\S]+?```”,          # Markdown code blocks
        r”(?<=<code>)[\s\S]+?(?=</code>)”,  # HTML code
        r”def\s+\w+\(.*?\):”,       # Python function
        r”function\s+\w+\(.*?\)\s*{“, # JS function
    ]

    TEXT_FILE_EXTENSIONS = [‘.txt’, ‘.md’, ‘.csv’, ‘.log’]
    CODE_FILE_EXTENSIONS = [‘.py’, ‘.js’, ‘.java’, ‘.cpp’, ‘.rs’, ‘.go’, ‘.ts’]

    def __init__(self, directory: str):
        self.directory = directory
        self.files_data: Dict[str, Dict[str, Any]] = {}
        self.learned_patterns: Counter = Counter()      # یادگیری patternها
        self.automation_rules: Dict[str, Any] = {}      # ذخیره automation

    # -————— Core -—————
    def scan_directory(self):
        for root, _, files in os.walk(self.directory):
            for f in files:
                full_path = os.path.join(root, f)
                self.files_data[full_path] = self.analyze_file(full_path)

    def analyze_file(self, filepath: str) -> Dict[str, Any]:
        result = {“type”: “unknown”, “content”: “”, “code_snippets”: [], “lines_count”: 0}
        try:
            ext = os.path.splitext(filepath)[1].lower()
            with open(filepath, “r”, encoding=“utf-8”, errors=“ignore”) as f:
                content = f.read()
                result[“content”] = content
                result[“lines_count”] = content.count(“\n”) + 1

                # Determine type
                if ext in self.TEXT_FILE_EXTENSIONS:
                    result[“type”] = “text”
                elif ext in self.CODE_FILE_EXTENSIONS:
                    result[“type”] = “code”
                else:
                    code_snips = self.extract_code(content)
                    if code_snips:
                        result[“type”] = “code”
                        result[“code_snippets”] = code_snips
                    else:
                        result[“type”] = “text”

                # Extract inline code
                if result[“type”] == “text”:
                    result[“code_snippets”] = self.extract_code(content)

                # Auto-learn patterns
                for snippet in result[“code_snippets”]:
                    self.learn_pattern(snippet)

        except Exception as e:
            result[“error”] = str(e)
        return result

    # -————— Code Extraction -—————
    def extract_code(self, text: str) -> List[str]:
        snippets = []
        patterns = self.DEFAULT_CODE_PATTERNS + list(self.learned_patterns.keys())
        for pattern in patterns:
            matches = re.findall(pattern, text, re.MULTILINE)
            snippets.extend(matches)
        return snippets

    # -————— Learning -—————
    def learn_pattern(self, snippet: str):
        # ساده‌ترین یادگیری: طول snippet و نوع کلمات کلیدی
        key = snippet[:50]  # نمونه اولیه pattern
        self.learned_patterns[key] += 1

    # -————— Automation -—————
    def define_automation(self, name: str, condition, action):
        “””Define automatic tasks on file analysis.”””
        self.automation_rules[name] = {“condition”: condition, “action”: action}

    def run_automation(self):
        for filepath, data in self.files_data.items():
            for name, rule in self.automation_rules.items():
                try:
                    if rule[“condition”](filepath, data):
                        rule[“action”](filepath, data)
                except Exception as e:
                    print(f”[Automation Error] {name} -> {str(e)}”)

    # -————— Reporting -—————
    def summarize(self) -> Dict[str, Any]:
        summary = {“total_files”: len(self.files_data), “text_files”: 0, “code_files”: 0}
        for fdata in self.files_data.values():
            if fdata.get(“type”) == “text”:
                summary[“text_files”] += 1
            elif fdata.get(“type”) == “code”:
                summary[“code_files”] += 1
        return summary

# ======================= Example Usage =======================
if __name__ == “__main__”:
    analyzer = SmartFileAnalyzer(“./sample_data”)
    
    # Define automation: print code files with more than 50 lines
    analyzer.define_automation(
        “large_code_file”,
        lambda path, data: data[“type”]==“code” and data[“lines_count”]>50,
        lambda path, data: print(f”[AUTOMATION] Large code file detected: {path}, lines: {data[‘lines_count’]}”)
    )

    analyzer.scan_directory()
    analyzer.run_automation()

    for filepath, data in analyzer.files_data.items():
        print(f”File: {filepath}”)
        print(f”Type: {data[‘type’]}”)
        print(f”Lines: {data[‘lines_count’]}”)
        if data[“code_snippets”]:
            print(f”Code snippets found: {len(data[‘code_snippets’])}”)
        print(“-“ * 40)
    print(“Summary:”, analyzer.summarize())
    print(“Learned patterns:”, dict(analyzer.learned_patterns.most_common(10)))