import asyncio, aiohttp, json, hashlib, logging, uuid, time, random
from typing import Dict, Any, Callable

logging.basicConfig(level=logging.INFO, format=‘[%(levelname)s]%(asctime)s-%(message)s’)

def generate_uuid() -> str: return str(uuid.uuid4())
def timestamp() -> str: return time.strftime(“%Y-%m-%d %H:%M:%S”)
def hash_json(obj: Dict[str, Any]) -> str:
    try: return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()
    except: return str(time.time())

class CentralWebhookManager:
    _instance = None
    def __new__(cls, *a, **k):
        if not cls._instance: cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        self.queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self.webhook_rate_limit: float = 50
        self.webhook_interval: float = 1 / self.webhook_rate_limit
        self.module_hashes: Dict[str, str] = {}
        self.module_fail_score: Dict[str, float] = {}
        self.module_agents: Dict[str, Any] = {}
        self.local_secure_store: Dict[str, Dict[str, Any]] = {}
        self._shutdown: asyncio.Event = asyncio.Event()
        self._lock = asyncio.Lock()
        self.system_health: float = 100
        self.network_score: float = 100
        self.load_score: float = 100

    async def register_agent(self, module_name: str, agent_info: Dict[str, Any]):
        self.module_agents[module_name] = agent_info
        self.local_secure_store[module_name] = dict(agent_info)

    async def trigger(self, module_name: str, payload: Dict[str, Any], priority_value: int = 50):
        payload[‘_agent_info’] = self.module_agents.get(module_name, {})
        new_hash = hash_json(payload)
        old_hash = self.module_hashes.get(module_name)
        self.module_hashes[module_name] = new_hash
        if old_hash == new_hash: return
        await self.queue.put((max(1, 100 - priority_value), {“module”: module_name, “payload”: payload}))
        logging.info(f”Webhook queued:{module_name}, priority:{max(1, 100 - priority_value)}”)

    async def trigger_condition(self, module_name: str, payload: Dict[str, Any], condition: Callable[[Dict[str, Any]], bool], priority_value: int = 50):
        if condition(payload): await self.trigger(module_name, payload, priority_value)

    async def process_queue(self):
        while not self._shutdown.is_set():
            try:
                _, item = await self.queue.get()
                await self._send_webhook(item[“payload”], item[“module”])
            except Exception as e: logging.error(f”Queue error:{e}”)
            finally:
                await asyncio.sleep(self.webhook_interval)
                self.queue.task_done()

    async def _send_webhook(self, payload: Dict[str, Any], module_name: str):
        urls = [payload.get(“webhook_url”)] if payload.get(“webhook_url”) else []
        urls.extend(self.module_agents.get(module_name, {}).get(“fallback_urls”, []))
        if not urls: return
        retries, delay = 5, 1
        random.shuffle(urls)
        async with aiohttp.ClientSession() as session:
            for url in urls:
                for attempt in range(retries):
                    try:
                        async with session.post(url, json=payload, timeout=8) as resp:
                            if resp.status == 200: logging.info(f”Webhook sent:{module_name}->{url}”); return
                            logging.warning(f”Webhook {module_name} error {resp.status}”)
                    except Exception as e: logging.error(f”Webhook {module_name} attempt {attempt + 1} failed:{e}”)
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 30)
        logging.error(f”Webhook FAILED:{module_name}->{urls}”)
        self.module_fail_score[module_name] = self.module_fail_score.get(module_name, 0) + 1

    async def monitor_agents(self, interval: int = 30):
        while not self._shutdown.is_set():
            total_cpu = total_ram = count = 0
            for module, info in self.module_agents.items():
                cpu, ram = info.get(“cpu_usage”, 0), info.get(“ram_usage”, 0)
                total_cpu += cpu; total_ram += ram; count += 2
                if cpu > 80 or ram > 80: logging.warning(f”High load:{module} CPU:{cpu}% RAM:{ram}%”)
            self.system_health = 100 - (total_cpu + total_ram) / count if count else 100
            self.network_score = random.randint(90, 100)
            self.load_score = random.randint(90, 100)
            if self.system_health < 95 or self.network_score < 95 or self.load_score < 95:
                logging.warning(f”System low:{self.system_health}% network:{self.network_score}% load:{self.load_score}%, self-heal”)
                await self.self_heal()
            await asyncio.sleep(interval)

    async def self_heal(self):
        async with self._lock:
            for module in self.module_agents:
                agent = self.local_secure_store.get(module)
                if agent: self.module_agents[module] = dict(agent)
            self.system_health = self.network_score = self.load_score = 100
            logging.info(“Self-heal complete, system restored”)

    async def generate_webhook_for_all(self, value: int):
        for module in self.module_agents:
            payload = {“module”: module, “value”: value, “_timestamp”: timestamp(), “_id”: generate_uuid(),
                       “webhook_url”: self.module_agents[module].get(“webhook_url”)}
            await self.trigger_condition(module, payload, lambda p: p[“value”] > 20, priority_value=value)

    def stop(self): self._shutdown.set()

async def example_module(module_name: str, webhook_url: str):
    manager = CentralWebhookManager()
    await manager.register_agent(module_name, {“webhook_url”: webhook_url, “cpu_usage”: 0, “ram_usage”: 0, “fallback_urls”: []})
    for i in range(10):
        payload = {“module”: module_name, “value”: i * 10, “webhook_url”: webhook_url, “_timestamp”: timestamp(), “_id”: generate_uuid()}
        await manager.trigger_condition(module_name, payload, lambda p: p[“value”] > 20, priority_value=i * 10)
        await asyncio.sleep(0.5)

async def main():
    manager = CentralWebhookManager()
    asyncio.create_task(manager.process_queue())
    asyncio.create_task(manager.monitor_agents())
    asyncio.create_task(example_module(“cpu_monitor”, “http://localhost:8000/webhook”))
    asyncio.create_task(example_module(“memory_monitor”, “http://localhost:8000/webhook”))
    try:
        while True: await asyncio.sleep(3600)
    except KeyboardInterrupt:
        manager.stop()
        logging.info(“Graceful shutdown initiated.”)

if __name__ == “__main__”: asyncio.run(main())
