
import base64
import json
import traceback
import hashlib
import mimetypes
import binascii
import time
import random

# -———————————————————
#  JS BRIDGE (Pyodide Style)
# -———————————————————

try:
    import js
    JS_AVAILABLE = True
except:
    JS_AVAILABLE = False

# -———————————————————
#  CORE HELPERS
# -———————————————————

def b64e(x:bytes)->str:
    return base64.b64encode(x).decode()

def b64d(x:str)->bytes:
    return base64.b64decode(x)

def sha256(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()

def now():
    return int(time.time()*1000)

def rand():
    return hex(random.getrandbits(64))

# -———————————————————
#  PYTHOID SERIALIZER (Unified Serialization Format)
# -———————————————————

class Pythoid:
    def encode(self, obj):
        try:
            blob = json.dumps(obj).encode()
            return b64e(blob)
        except:
            return None

    def decode(self, blob:str):
        try:
            return json.loads(b64d(blob).decode())
        except:
            return None

    def encode_binary(self, raw:bytes):
        return {
            “type”:”binary”,
            “sha256”:sha256(raw),
            “size”:len(raw),
            “data”:b64e(raw)
        }

    def decode_binary(self, pkg):
        return b64d(pkg[“data”])

# -———————————————————
#  FILE ANALYSIS + ROUTER
# -———————————————————

class FileRouter:
    EXT_MAP = {
        “.png”:”image/png”,
        “.jpg”:”image/jpeg”,
        “.jpeg”:”image/jpeg”,
        “.gif”:”image/gif”,
        “.webp”:”image/webp”,
        “.mp4”:”video/mp4”,
        “.mkv”:”video/mkv”,
        “.mp3”:”audio/mpeg”,
        “.wav”:”audio/wav”,
        “.pdf”:”application/pdf”,
        “.zip”:”application/zip”,
        “.json”:”application/json”,
        “.txt”:”text/plain”,
        “.py”:”text/python”,
        “.js”:”text/javascript”,
        “.wasm”:”application/wasm”
    }

    def detect(self, filename, raw_bytes):
        ext = “.” + filename.split(“.”)[-1].lower()
        mime = self.EXT_MAP.get(ext, mimetypes.guess_type(filename)[0] or “application/octet-stream”)
        return {
            “filename”: filename,
            “mime”: mime,
            “size”: len(raw_bytes),
            “sha256”: sha256(raw_bytes),
            “is_text”: mime.startswith(“text”) or mime==“application/json”,
            “ext”: ext
        }

# -———————————————————
#  JS EVENT BINDING (Browser + Node Compatible)
# -———————————————————

class JSEventBridge:
    def __init__(self):
        self.handlers = {}

    def on(self, event_name:str, callback):
        self.handlers[event_name]=callback
        if JS_AVAILABLE:
            try:
                js.globalThis.addEventListener(event_name, lambda evt: callback(str(evt)))
            except:
                pass

    def emit(self, event_name:str, payload):
        if event_name in self.handlers:
            try:
                self.handlers[event_name](payload)
            except:
                pass

# -———————————————————
#  NETWORK PROTOCOL ADAPTER (WS / HTTP / WebHook)
# -———————————————————

class NetworkAdapter:
    def __init__(self):
        self.ws = None

    # -———————— WEBHOOK (SEND POST)
    def webhook(self, url, data):
        if not JS_AVAILABLE:
            return {“error”:”JS not available”}
        try:
            r = js.fetch(url, {
                “method”: “POST”,
                “body”: json.dumps(data),
                “headers”: {“Content-Type”:”application/json”}
            })
            return {“queued”:True}
        except Exception as e:
            return {“error”:str(e)}

    # -———————— WEBSOCKET
    def ws_connect(self, url, onmsg):
        if not JS_AVAILABLE:
            return {“error”:”JS not available”}

        self.ws = js.WebSocket.new(url)
        self.ws.onmessage = lambda evt: onmsg(str(evt.data))
        return {“connected”:True}

    def ws_send(self, msg):
        try:
            self.ws.send(msg)
            return True
        except:
            return False

    # -———————— HTTP FETCH WRAPPER
    def http_get(self, url):
        if not JS_AVAILABLE: 
            return {“error”:”JS not available”}
        try:
            res = js.fetch(url)
            return {“fetched”:True}
        except Exception as e:
            return {“error”:str(e)}

# -———————————————————
#  JS ↔ PY DECODING ADAPTER
# -———————————————————

class JSGateway:
    def decode_js_value(self, val):
        try:
            return json.loads(str(val))
        except:
            return str(val)

    def encode_python_value(self, val):
        try:
            return json.dumps(val)
        except:
            return str(val)

# -———————————————————
#  SECURITY / DECRYPT / ENCRYPT
# -———————————————————

class CryptoAdapter:
    def encrypt(self, raw:bytes, key:str):
        k = key.encode()
        enc = bytes([raw[i] ^ k[i % len(k)] for i in range(len(raw))])
        return b64e(enc)

    def decrypt(self, enc:str, key:str):
        raw = b64d(enc)
        k = key.encode()
        dec = bytes([raw[i] ^ k[i % len(k)] for i in range(len(raw))])
        return dec

# -———————————————————
#  MAIN ADAPTER FACADE
# -———————————————————

class PythonToJSAdapter:
    def __init__(self):
        self.pythoid = Pythoid()
        self.fr = FileRouter()
        self.events = JSEventBridge()
        self.net = NetworkAdapter()
        self.crypto = CryptoAdapter()
        self.js_gate = JSGateway()

    # -—————— UNIVERSAL INPUT HANDLER
    def handle_input(self, filename=None, raw=None, text=None):
        try:
            if raw:
                info = self.fr.detect(filename, raw)
                blob = self.pythoid.encode_binary(raw)
                return {“info”:info, “blob”:blob, “status”:”ok”}

            if text:
                return {
                    “type”:”text”,
                    “size”:len(text),
                    “sha256”:sha256(text.encode()),
                    “status”:”ok”
                }

        except Exception as e:
            return {“error”:str(e)}

    # -—————— PASS-THROUGH ANY FILE TO JS
    def forward_to_js(self, pkg):
        if not JS_AVAILABLE:
            return {“error”: “JS not available”}
        try:
            js.globalThis.vortex_incoming(self.pythoid.encode(pkg))
            return {“sent”:True}
        except Exception as e:
            return {“error”:str(e)}

    # -—————— JS → PY RECEPTION
    def recv_from_js(self, js_payload):
        data = self.js_gate.decode_js_value(js_payload)
        return {“received”:data}

