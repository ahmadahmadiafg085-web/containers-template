import json
from base64 import b64decode

# ================================
# 🌐 CONFIGURATION DICTIONARY
# ================================
CONFIG = {
    “version”: “1.0.2”,
    “config_token”: “VHX-2025-SECURE-01”,
    “config_expiry”: “2025-12-31T23:59:59Z”,
    “valkey”: “redis://red-d4f8qishg0os738qkgt0:6379”,
    “allowed_ips”: [
        “44.229.227.142”,
        “52.13.128.108”,
        “54.188.71.94”,
        “74.220.48.0/24”,
        “74.220.56.0/24”
    ],
    “deployment”: {
        “render_url”: “https://vortex-universal-orchestrator-cppw.onrender.com”,
        “status”: “active”,
        “last_deploy_commit”: “bdc06dba0415d5718871d6e6dfa85cadb636533b”,
        “region”: “Frankfurt”
    },
    “links”: {
        “github_repo”: “https://github.com/ahmadahmadiafg085-web/vortex-universal-orchestrator”,
        “github_raw_base”: “https://raw.githubusercontent.com/“,
        “base64_github”: “aHR0cHM6Ly9naXRodWIuY29tL2FobWFkYWhtYWRpYWZnMDg1LXdlYi92b3J0ZXgtdW5pdmVyc2FsLW9yY2hlc3”,
        “vercel_live”: “https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app”,
        “vercel_api”: “https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/api”,
        “vercel_api_data”: “https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/api/data”,
        “vercel_data_json”: “https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/data.json”,
        “google_drive_view”: “https://drive.google.com/file/d/1Kt0qLYaOfrh_pM6i-8WPFqE9P415uP-N/view?usp=drivesdk”,
        “google_drive_download”: “https://drive.google.com/uc?export=download&id=1Kt0qLYaOfrh_pM6i-8WPFqE9P415uP-N”,
        “k00_links”: [
            {“url”: “https://k00.fr/cv9tsz1p”, “password”: “285861”},
            {“url”: “https://k00.fr/k9ourdsf”},
            {“url”: “https://k00.fr/mqdrkha5”},
            {“url”: “https://app.koofr.net/app/storage/d9699792-7987-4f17-9069-d0a14e681749”}
        ]
    },
    “credentials”: {
        “api_key”: “74074fb6f51063e40f55”,
        “api_secret”: “885439176976b165e50f414fdd594a2c75a89f85512927359416b9d79aae93ab”,
        “jwt”: “eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySW5mb3JtYXRpb24iOnsiaWQiOiJiNmRjODMxMC0xNGQ1LTRlMmEtOTRjNS1iOWE2MThmMzhkYmYiLCJlbWFpbCI6ImFobWFkYWhtYWRpYWZnMDg1QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJwaW5fcG9saWN5Ijp7InJlZ2lvbnMiOlt7ImRlc2lyZWRSZXBsaWNhdGlvbkNvdW50IjoxLCJpZCI6IkZSQTEifSx7ImRlc2lyZWRSZXBsaWNhdGlvbkNvdW50IjoxLCJpZCI6Ik5ZQzEifV0sInZlcnNpb24iOjF9LCJtZmFfZW5hYmxlZCI6ZmFsc2UsInN0YXR1cyI6IkFDVElWRSJ9LCJhdXRoZW50aWNhdGlvblR5cGUiOiJzY29wZWRLZXkiLCJzY29wZWRLZXlLZXkiOiI3NDA3NGZiNmY1MTA2M2U0MGY1NSIsInNjb3BlZEtleVNlY3JldCI6Ijg4NTQzOTE3Njk3NmIxNjVlNTBmNDE0ZmRkNTk0YTJjNzVhODlmODU1MTI5MjczNTk0MTZiOWQ3OWFhZTkzYWIiLCJleHAiOjE3OTUyMDAyODN9.CecVpXHvvfYigUHr909Mmc36Nan3sWg8hvnPWIvUTaA”,
        “pinata”: {
            “pinata_id_1”: “019aa299-3759-75d4-8c36-c6b70f6104ea”,
            “pinata_id_2”: “019aa29b-0f99-70e3-a899-e693dc4258cd”,
            “cid”: “bafkreic3uxleigat5kieluw4uq3vrji4flwwsr6ltgme4yn7a2yqnx7nfm”,
            “gateway”: “peach-tropical-reindeer-499.mypinata.cloud”,
            “api_keys_url”: “https://app.pinata.cloud/developers/api-keys”
        },
        “koofr”: {
            “rclone”: {
                “remote_name”: “my-safe-box”,
                “type”: “crypt”,
                “remote_path”: “koofr:/My safe box”,
                “password”: “Jbo626Z49ARQQEiNfHJ-EGWO73LA1pQpioJzLQ”,
                “password2”: “SMQF-LhWfCFP7nVdRFEFDWfbNV8Nf5ZfZOC5veg0Pym2lxhVsC7miuuZNJeo8wZYtWe4L32JAg0cGq-UjF1dgpwJ-dgTKMwXKVcsTS6zX0GIFR9tplSrsJkXSp2U5atyVSSc3LAOgm_aZf989XB_YpO1L0652hmxUdSb4ZXWkH48znNpeA8jFNQ05Jz65hfLNFI1ODBhfPkQInJxXUkNDtI6uEZo0fWRN0ujaglrw2T50ip10gja4degAw”,
                “salt”: “m7LAs4ca3s5WGYeTTVAs7IbwJevCr_nUrvEMNnC6ZTsyO0WcV7JPTLSXdCZWYpRGj774CRc8unhuTjto4p9BMufEdn6ktQ08RWVRXg9mvj62YynuW36gadD8jwbRgjvQUIiZVTKl057teVC8C1uzleYkv0dVpJTDq_1gq71mB4Q”
            }
        }
    },
    “fetch_snippets”: {
        “github_base64”: “const url = atob(‘aHR0cHM6Ly9naXRodWIuY29tL2FobWFkYWhtYWRpYWZnMDg1LXdlYi92b3J0ZXgtdW5pdmVyc2FsLW9yY2hlc3’); fetch(url).then(r => r.text()).then(console.log);”,
        “google_drive”: “fetch(‘https://drive.google.com/uc?export=download&id=1Kt0qLYaOfrh_pM6i-8WPFqE9P415uP-N’).then(r => r.blob()).then(console.log);”,
        “github_raw”: “fetch(‘https://raw.githubusercontent.com/USERNAME/REPO/main/file.json’).then(r => r.json()).then(data => console.log(data));”,
        “vercel_api”: “fetch(‘https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/api’).then(r => r.text()).then(console.log);”,
        “vercel_api_data”: “fetch(‘https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/api/data’).then(r => r.json()).then(j => console.log(j));”,
        “vercel_data_json”: “fetch(‘https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/data.json’).then(r => r.json()).then(j => console.log(j));”,
        “k00_fetch”: [
            “fetch(‘https://k00.fr/cv9tsz1p’).then(r => r.text()).then(console.log);”,
            “fetch(‘https://k00.fr/k9ourdsf’).then(r => r.text()).then(console.log);”,
            “fetch(‘https://k00.fr/mqdrkha5’).then(r => r.text()).then(console.log);”
        ]
    },
    “triggers”: [“file_update”, “agent_login”, “service_call”, “runtime_error”],
    “metadata”: {
        “last_update”: “2025-11-20T20:00:00Z”,
        “repo_link”: “https://github.com/ahmadahmadiafg085-web/vortex-universal-orchestrator”,
        “repo_fetch_mirrors”: [
            “https://mirror1.githubusercontent.com/repo”,
            “https://mirror2.githubusercontent.com/repo”
        ],
        “author”: “VortexHub Labs”,
        “metadata_signature”: “HMAC-SHA256”,
        “metadata_schema_version”: “2.2”,
        “schema_versioning”: True,
        “metadata_validation”: True,
        “scenario_tracking_enabled”: True
    }
}

# ================================
# 🌐 JSON EXTRACTOR FUNCTIONS
# ================================
def get_config(key_path: str, default=None):
    “””
    دسترسی به مقادیر پیکربندی با مسیر نقطه‌ای
    مثال: get_config(“deployment.render_url”)
    “””
    keys = key_path.split(“.”)
    data = CONFIG
    try:
        for key in keys:
            data = data[key]
        return data
    except KeyError:
        return default


def decode_base64_github():
    “””
    دیکود کردن لینک base64 گیت‌هاب
    “””
    encoded = CONFIG[“links”][“base64_github”]
    decoded = b64decode(encoded + “==“).decode(“utf-8”)  # padding safe
    return decoded


def dump_config_json(pretty=True):
    “””
    بازگرداندن کل پیکربندی به صورت رشته JSON
    “””
    return json.dumps(CONFIG, indent=4) if pretty else json.dumps(CONFIG)


# ================================
# 🌐 EXAMPLE USAGE
# ================================
if __name__ == “__main__”:
    print(“🚀 Render URL:”, get_config(“deployment.render_url”))
    print(“🔑 API Key:”, get_config(“credentials.api_key”))
    print(“🌐 Decoded GitHub Base64:”, decode_base64_github())
    print(“📄 Full JSON dump:”)
    print(dump_config_json())