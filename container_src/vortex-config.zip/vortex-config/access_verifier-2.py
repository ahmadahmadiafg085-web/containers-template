import fnmatch, json
from datetime import datetime

# -——————— CONFIG -———————
POLICIES=[
    {“user”:”guest”,”action”:”read”,”resource”:”*.txt”},
    {“user”:”admin”,”action”:”*”,”resource”:”*”},
    {“user”:”agent_*”,”action”:”*”,”resource”:”*”}
]

AGENT_TOKENS={
    “agent_1”:”a1x9f7”,
    “agent_2”:”b4t3k2”,
    “agent_root”:”root777”
}

ACCESS_LOG=[]

# -——————— POLICY ENGINE -———————
def _match_user(p, u): return fnmatch.fnmatch(u, p)
def _check_policy(user, action, resource):
    for p in POLICIES:
        if _match_user(p[“user”],user):
            if p[“action”] in (action,”*”):
                if fnmatch.fnmatch(resource,p[“resource”]):
                    return True
    return False

def enforce_policy(user, action, resource, cb=None):
    ok=_check_policy(user,action,resource)
    if ok:
        if cb: cb()
        return True
    print(f”[DENIED] {user} cannot {action} {resource}”)
    return False

# -——————— AGENT ENGINE -———————
def verify_agent(agent, token): return AGENT_TOKENS.get(agent)==token

def agent_action(agent, token, action, resource):
    ts=datetime.now().isoformat()
    if not verify_agent(agent,token):
        entry={“ts”:ts,”agent”:agent,”action”:action,”resource”:resource,”allowed”:False,”reason”:”AUTH_FAIL”}
        ACCESS_LOG.append(entry)
        print(f”[AUTH FAIL] {agent}”)
        return False

    ok=enforce_policy(agent,action,resource,
        lambda: print(f”[EXECUTED] {agent} {action} {resource}”)
    )

    ACCESS_LOG.append({
        “ts”:ts,”agent”:agent,”action”:action,”resource”:resource,”allowed”:ok
    })

    return ok

# -——————— DEMO -———————
if __name__==“__main__”:
    print(“[ACCESS ENGINE READY]\n”)
    agent_action(“agent_1”,”a1x9f7”,”read”,”data.txt”)
    agent_action(“agent_2”,”wrong”,”write”,”db.sqlite”)
    agent_action(“agent_root”,”root777”,”delete”,”secret.cfg”)
    agent_action(“guest”,”none”,”read”,”data.txt”)

    with open(“access.log.json”,”w”) as f:
        json.dump(ACCESS_LOG,f,indent=2)

    print(“\n[LOG SAVED] → access.log.json”)
    