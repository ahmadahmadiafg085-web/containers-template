// loggingEngine.js
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const EventEmitter = require('events');

const LEVELS = ['trace', 'debug', 'info', 'warn', 'error', 'fatal', 'off'];
const LEVEL_PRIORITY = { trace: 5, debug: 10, info: 20, warn: 30, error: 40, fatal: 50, off: 100 };
const DEFAULT_REDACT_HEADERS = [
  'authorization','cookie','set-cookie','proxy-authorization','x-api-key','x-csrf-token','x-xsrf-token',
  'password','token','secret','access-token','refresh-token','sessionid','api-key','apikey','authentication'
];
const DEFAULT_LOG_FILE_OPTIONS = { logDir: path.join(process.cwd(), 'logs'), fileName: 'app.log', filePrefix: 'access', logPerDay: true, maxFileSizeMB: 50, maxBackupFiles: 10 };
const MAX_BODY_LENGTH_DEFAULT = 4096;
const REQUEST_ID_HEADER = 'x-request-id';
const DATE_FORMATS = { ISO8601:'ISO8601', UNIX_MS:'unix-ms', SIMPLE:'simple' };
const LOG_ROTATION_METHODS = { SIZE_BASED:'size-based', TIME_BASED:'time-based', NONE:'none' };
const MAX_LOG_EVENT_SIZE_BYTES = 1048576;
const LOG_QUEUE_SIZE_LIMIT = 15000;

function ensureDir(dirPath){ if(!dirPath) throw new Error('Directory path required'); if(!fs.existsSync(dirPath)) fs.mkdirSync(dirPath,{recursive:true}); }
function safeJSONStringify(data,options={}){ try{ if(options.indent) return JSON.stringify(data,null,options.indent); if(options.maxLength){ let str=JSON.stringify(data); if(str.length>options.maxLength) return str.slice(0,options.maxLength)+'...[truncated]'; return str; } return JSON.stringify(data);}catch{return'"[Circular or Unserializable]"';} }
function formatTimestamp(date=new Date(),format='ISO8601'){ if(format==='ISO8601') return date.toISOString(); if(format==='utcMillis') return date.getTime(); const pad=n=>n<10?'0'+n:n; const y=date.getFullYear(),m=pad(date.getMonth()+1),d=pad(date.getDate()),h=pad(date.getHours()),min=pad(date.getMinutes()),s=pad(date.getSeconds()),ms=date.getMilliseconds().toString().padStart(3,'0'); return`${y}-${m}-${d}T${h}:${min}:${s}.${ms}Z`; }
function getBaseContext(options){ return { hostname:os.hostname(), service:options.serviceName||'service', environment:options.env||process.env.NODE_ENV||'development', pid:process.pid, processTitle:process.title, nodeVersion:process.version }; }
function getLogFilePath(options,date=new Date()){ if(!options.logDir) return null; ensureDir(options.logDir); if(options.logPerDay){ const y=date.getFullYear(),m=(date.getMonth()+1).toString().padStart(2,'0'),d=date.getDate().toString().padStart(2,'0'); const file=`${options.filePrefix||'app'}-${y}-${m}-${d}.log`; return path.join(options.logDir,file); } return path.join(options.logDir,options.fileName||'app.log'); }
function writeLogToFile(filePath,data){ if(!filePath) return false; try{ fs.appendFile(filePath,data+os.EOL,err=>{ if(err) console.error('Log Write Error:',err); }); return true;}catch{return false;} }
function generateRequestId(req,headerName=REQUEST_ID_HEADER){ return req.headers[headerName.toLowerCase()]||crypto.randomBytes(16).toString('hex'); }
function isLevelEnabled(currentLevel,configLevel){ return LEVEL_PRIORITY[currentLevel]>=LEVEL_PRIORITY[configLevel]; }
function redactObject(obj,keysToRedact=DEFAULT_REDACT_HEADERS){ if(!obj||typeof obj!=='object') return obj; const result={}; const lowerKeys=keysToRedact.map(k=>k.toLowerCase()); Object.entries(obj).forEach(([key,value])=>{ if(lowerKeys.includes(key.toLowerCase())) result[key]='[REDACTED]'; else result[key]=value; }); return result; }
function cloneSafeValue(value,lengthLimit=2048){ if(value==null) return undefined; let result=value; if(Buffer.isBuffer(value)) result=result.toString('utf-8'); if(typeof result==='string'){ if(lengthLimit&&result.length>lengthLimit) return result.slice(0,lengthLimit)+'...[truncated]'; return result; } try{ let str=JSON.stringify(result); if(lengthLimit&&str.length>lengthLimit) return str.slice(0,lengthLimit)+'...[truncated]'; return str;}catch{return'[Unserializable]';} }

class AsyncLogger extends EventEmitter{
  constructor(options){
    super();
    this.options=options;
    this.baseContext=getBaseContext(options);
    this.queue=[];
    this.isFlushing=false;
    this.flushInterval=setInterval(()=>this.flushQueue(),options.logFlushIntervalMs||500);
  }
  enqueue(level,payload){
    if(!isLevelEnabled(level,this.options.logLevel)) return;
    const entry=Object.assign({},this.baseContext,payload,{level,timestamp:formatTimestamp()});
    const line=safeJSONStringify(entry);
    if(this.options.console) console[level==='error'||level==='fatal'?'error':'log'](line);
    if(this.options.file) this.queue.push({filePath:getLogFilePath(this.options),line});
    if(this.queue.length>LOG_QUEUE_SIZE_LIMIT) this.flushQueue();
  }
  flushQueue(){
    if(this.isFlushing||this.queue.length===0) return;
    this.isFlushing=true;
    const batch=this.queue.splice(0,this.queue.length);
    batch.forEach(({filePath,line})=>writeLogToFile(filePath,line));
    this.isFlushing=false;
  }
  trace(payload){ this.enqueue('trace',payload); }
  debug(payload){ this.enqueue('debug',payload); }
  info(payload){ this.enqueue('info',payload); }
  warn(payload){ this.enqueue('warn',payload); }
  error(payload){ this.enqueue('error',payload); }
  fatal(payload){ this.enqueue('fatal',payload); }
}

function captureRequestBody(req,options,callback){
  if(!options.logRequestBody) return callback();
  if(req.readableEnded||req.body){ req._rawBody=cloneSafeValue(req.body,options.maxBodyLength); return callback(); }
  const chunks=[]; let length=0;
  req.on('data',chunk=>{ chunks.push(chunk); length+=chunk.length; if(options.maxBodyLength&&length>options.maxBodyLength*2) req.pause(); });
  req.on('end',()=>{ const buf=Buffer.concat(chunks,length); req._rawBody=cloneSafeValue(buf,options.maxBodyLength); callback(); });
  req.on('error',()=>callback());
}

function wrapResponse(res,ctx,options,logger,redactHeadersFn){
  const origWrite=res.write; const origEnd=res.end;
  const chunks=[]; let length=0;
  res.write=function(chunk,encoding,cb){ try{ if(options.logResponseBody&&chunk){ const buf=Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk,encoding||'utf-8'); chunks.push(buf); length+=buf.length; } }catch{} return origWrite.call(this,chunk,encoding,cb); };
  res.end=function(chunk,encoding,cb){ try{ if(options.logResponseBody&&chunk){ const buf=Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk,encoding||'utf-8'); chunks.push(buf); length+=buf.length; } }catch{} origEnd.call(this,chunk,encoding,cb); };
  res.on('finish',()=>{ const status=res.statusCode; const body=(options.logResponseBody&&chunks.length)?Buffer.concat(chunks,length):undefined; const elapsed=Date.now()-ctx.startAt; const level=status>=500?'error':status>=400?'warn':'info'; const redactedHeaders=redactHeadersFn(res.getHeaders(),options.redactHeaders); const payload={ type:'response', requestId:ctx.requestId, method:ctx.method, path:ctx.path, statusCode:status, elapsedTimeMs:elapsed, responseHeaders:redactedHeaders }; if(options.logRequestBody) payload.requestBody=ctx.body; if(options.logResponseBody) payload.responseBody=cloneSafeValue(body,options.maxBodyLength); if(options.trackUserAgent&&ctx.userAgent) payload.userAgent=ctx.userAgent; if(options.trackIp&&ctx.ip) payload.ip=ctx.ip; logger[level](payload); });
  res.on('close',()=>{ if(res.writableFinished) return; const elapsed=Date.now()-ctx.startAt; const payload={ type:'connection-closed', requestId:ctx.requestId, method:ctx.method, path:ctx.path, statusCode:res.statusCode, elapsedTimeMs:elapsed }; logger[options.logOnErrorLevel||'error'](payload); });
}

function createLoggerMiddleware(rawOptions={}){
  const options=Object.assign({ logLevel:'debug', logDir:path.join(process.cwd(),'logs'), logPerDay:true, console:true, file:true, filePrefix:'access', env:process.env.NODE_ENV||'development', serviceName:'node-service', requestIdHeader:REQUEST_ID_HEADER, redactHeaders:DEFAULT_REDACT_HEADERS, maxBodyLength:2048, logRequestBody:true, logResponseBody:true, logOnErrorLevel:'error', sampleRate:1.0, skipPaths:[], skipMethods:[], trackUserAgent:true, trackIp:true },rawOptions);
  const logger=new AsyncLogger(options);
  function shouldSkip(req){ if(options.sampleRate<1&&Math.random()>options.sampleRate) return true; if(Array.isArray(options.skipMethods)&&options.skipMethods.includes(req.method)) return true; if(Array.isArray(options.skipPaths)){ const url=req.originalUrl||req.url||''; for(const pattern of options.skipPaths){ if(!pattern) continue; if(pattern instanceof RegExp&&pattern.test(url)) return true; if(typeof pattern==='string'&&url.startsWith(pattern)) return true; } } return false; }
  function middleware(req,res,next){ if(shouldSkip(req)) return next(); const startAt=Date.now(); const requestId=generateRequestId(req,options.requestIdHeader); req.requestId=requestId; res.setHeader(options.requestIdHeader,requestId); const ctx={ requestId, startAt, method:req.method, path:req.originalUrl||req.url||'', route:req.route?.path, query:req.query||{}, userAgent:req.headers['user-agent'], ip:req.ip||req.connection?.remoteAddress||req.socket?.remoteAddress, requestHeaders:redactObject(req.headers,options.redactHeaders), body:undefined }; const handleError=err=>{ const elapsed=Date.now()-startAt; logger.error({ type:'error', requestId, method:ctx.method, path:ctx.path, message:err.message||String(err), stack:err.stack, elapsedTimeMs:elapsed }); }; let doneCalled=false; const safeNext=err=>{ if(doneCalled) return; doneCalled=true; if(err) handleError(err); next(err); }; try{ captureRequestBody(req,options,()=>{ ctx.body=req._rawBody; wrapResponse(res,ctx,options,logger,redactObject); logger.info({ type:'request-start', requestId, method:ctx.method, path:ctx.path, route:ctx.route, query:ctx.query, ip:ctx.ip, userAgent:ctx.userAgent }); safeNext(); }); }catch(err){ handleError(err); safeNext(err); } }
  middleware.logger=logger; middleware.levels=[...LEVELS]; middleware.options=options;
  return middleware;
}

module.exports={ createLoggerMiddleware, AsyncLogger, LEVELS, LEVEL_PRIORITY, ensureDir, safeJSONStringify, formatTimestamp, getBaseContext, getLogFilePath, writeLogToFile, generateRequestId, isLevelEnabled, redactObject, cloneSafeValue };