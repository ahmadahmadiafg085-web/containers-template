<template>
  <div class="admin-layout">
    <header class="admin-header">
      <h1>Admin Dashboard</h1>
    </header>

    <aside class="sidebar">
      <h3>Scenarios</h3>
      <ul>
        <li v-for="(s, name) in scenarios" :key="name" :class="s.status">
          {{ name }} - {{ s.status }} - {{ s.msg }}
          <button @click="triggerScenario(name)">Trigger</button>
        </li>
      </ul>
      <button @click="addScenario()">Add Scenario</button>
    </aside>

    <main class="main-content">
      <h3>Actuators Health</h3>
      <table>
        <thead>
          <tr><th>Name</th><th>Status</th><th>Last Checked</th></tr>
        </thead>
        <tbody>
          <tr v-for="(a, name) in actuators" :key="name" :class="a.status">
            <td>{{ name }}</td>
            <td>{{ a.status }}</td>
            <td>{{ a.lastRun }}</td>
          </tr>
        </tbody>
      </table>
    </main>
  </div>
</template>

<script setup>
import { reactive, onMounted } from "vue";

// ======= Reactive States =======
const scenarios = reactive({});
const actuators = reactive({});

// ======= Helper Functions =======
function timestamp() {
  return new Date().toISOString().slice(0, 19).replace("T", " ");
}

// ======= Scenario Functions =======
function processScenario(name) {
  const s = scenarios[name];
  if (!s) return;

  const success = Math.random() > 0.2; // 80% success simulation
  s.status = success ? "success" : "fail";
  s.msg = `Processed at ${timestamp()}`;

  // Self-heal logic
  if (!s.failCount) s.failCount = 0;
  s.failCount = success ? 0 : s.failCount + 1;

  if (s.failCount >= 5) {
    s.status = "unknown";
    s.failCount = 0;
    s.msg = "Reset by self-heal";
  }
}

function triggerScenario(name) {
  const s = scenarios[name];
  if (s) {
    s.msg = `Manual trigger at ${timestamp()}`;
    processScenario(name);
  }
}

function addScenario() {
  const name = `dynamic_scenario_${Object.keys(scenarios).length + 1}`;
  scenarios[name] = { status: "unknown", msg: "", failCount: 0 };
}

// ======= Actuator Functions =======
function monitorActuators() {
  Object.keys(actuators).forEach(name => {
    const success = Math.random() > 0.2; // Simulate health
    actuators[name].status = success ? "healthy" : "unhealthy";
    actuators[name].lastRun = timestamp();
  });
}

function addActuator(name) {
  if (!actuators[name]) {
    actuators[name] = { status: "unknown", lastRun: "" };
  }
}

// ======= JSON Fetch Simulation =======
async function fetchScenarioData() {
  try {
    // Example: Fetch from backend or adapter
    // Replace URL with actual endpoint
    const res = await fetch("/api/scenarios");
    if (!res.ok) throw new Error("Fetch failed");
    const data = await res.json();

    // Update scenarios
    Object.entries(data.scenarios || {}).forEach(([name, s]) => {
      if (!scenarios[name]) scenarios[name] = { failCount: 0, ...s };
      else Object.assign(scenarios[name], s);
    });

    // Update actuators
    Object.entries(data.actuators || {}).forEach(([name, a]) => {
      if (!actuators[name]) actuators[name] = { ...a };
      else Object.assign(actuators[name], a);
    });
  } catch (err) {
    console.warn("Fetch error:", err);
  }
}

// ======= Lifecycle =======
onMounted(() => {
  // Initialize default scenarios & actuators
  ["init_scenario", "health_check", "actuator_monitor"].forEach(n => addScenario(n));
  ["pump_1", "valve_1"].forEach(addActuator);

  // Periodic simulation loop
  setInterval(() => {
    Object.keys(scenarios).forEach(processScenario);
    monitorActuators();
  }, 3000);

  // Periodic JSON fetch loop
  setInterval(fetchScenarioData, 5000);
});
</script>

<style scoped>
.admin-layout { display: flex; font-family: Arial, sans-serif; height: 100vh; }
.admin-header { position: fixed; top: 0; left: 0; width: 100%; background: #1f2937; color: #fff; padding: 1rem; }
.sidebar { width: 250px; background: #f3f4f6; padding: 1rem; margin-top: 60px; }
.main-content { flex: 1; padding: 1rem; margin-top: 60px; overflow-y: auto; }
.success { background-color: #c6f6d5; }
.fail, .unhealthy { background-color: #fed7d7; }
table { width: 100%; border-collapse: collapse; }
th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
th { background-color: #e5e7eb; }
button { margin-left: 0.5rem; }
</style>
