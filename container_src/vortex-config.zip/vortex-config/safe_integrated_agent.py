# safe_integrated_agent_optimized.py
import os,time,threading,logging,psutil,queue,json,random,subprocess,socket,platform,requests
from pathlib import Path
from typing import Dict,Any,Callable,Optional
from pyodide import run_js
import importlib.util,traceback

logging.basicConfig(level=logging.INFO,format='[%(levelname)s] %(asctime)s - %(message)s')
CTX={"history":[],"errors":[],"loaded_modules":{},"score":0.0,"actions":[],"weights":{},"count":0}

def alert_admin(msg:str): logging.warning(f"ALERT: {msg}"); CTX["errors"].append({"msg":msg,"time":time.time()})
def safe_import(path:str,name:str=None): p=Path(path); n=name or p.stem; 
    if not p.exists() or p.suffix!=".py": alert_admin(f"File not found or invalid: {path}"); return None
    try: spec=importlib.util.spec_from_file_location(n,str(p)); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); CTX["loaded_modules"][n]=m; logging.info(f"Module loaded safely: {n}"); return m
    except Exception as e: alert_admin(f"Error loading {n}: {e}\n{traceback.format_exc()}"); return None
def execute_function_safe(module,func_name:str,*args,**kwargs): 
    if not module: return None
    try: return getattr(module,func_name)(*args,**kwargs)
    except Exception as e: alert_admin(f"Error executing {func_name} in {module.__name__}: {e}\n{traceback.format_exc()}"); return None
def load_modules_from_json(cfg:Dict[str,Any]): return {m.get("name") or Path(m.get("path")).stem:safe_import(m.get("path"),m.get("name")) for m in cfg.get("modules",[])}
def load_config(path="config.json")->Dict: 
    try: return json.load(open(path,"r",encoding="utf-8"))
    except Exception as e: alert_admin(f"Config load error: {e}"); return {}
def safe_exec(func:Callable,ctx:Optional[Dict]=None,name:str="unknown"):
    try: return func(ctx or {})
    except Exception as e: logging.error(f"[{name}] Execution error: {e}"); alert_admin(f"[{name}] Execution error: {e}"); return None
def score(trigger:str,val:bool): CTX["score"]+=CTX["weights"].get(trigger,1.0)*(1 if val else 0); CTX["history"].append((trigger,val,time.time()))
def combo(status:Dict[str,bool]): s=sum(1 for v in status.values() if v); return "ultra_combo" if s>=4 else "triple_combo" if s==3 else "double_combo" if s==2 else None

# ----------------- Utilities -----------------
def cpu_check(ctx=None): val=psutil.cpu_percent(interval=0.5); val>85 and alert_admin(f"High CPU {val}%"); return val>85
def ram_check(ctx=None): val=psutil.virtual_memory().percent; val>80 and alert_admin(f"High RAM {val}%"); return val>80
def gpu_check(ctx=None):
    try: import GPUtil; val=max([g.load*100 for g in GPUtil.getGPUs()]); val>70 and alert_admin(f"High GPU {val}%"); return val>70
    except: val=random.randint(0,100); return val>70
def proc_check(ctx=None,pname="example_process"): return any(p.name()==pname for p in psutil.process_iter())
def net_check(ctx=None): return any(n.isup for n in psutil.net_if_stats().values())
def sensor_check(ctx=None,sensor_type="temperature"):
    try: temps=psutil.sensors_temperatures().get('coretemp',[25]); return temps[0].current if sensor_type=="temperature" else 0
    except: return 0
def usb_check(ctx=None,vid=None,pid=None,serial=None): return True
def file_stego_check(path,pattern): return Path(path).exists() and pattern.encode() in Path(path).read_bytes() if Path(path).exists() else False
def pdf_js_check(path): return Path(path).exists() and b"JavaScript" in Path(path).read_bytes() if Path(path).exists() else False
def vba_macro_check(path): return Path(path).exists() and ("Sub " in Path(path).read_text(errors="ignore") or "Function " in Path(path).read_text(errors="ignore"))
def js_event_exec(code): return run_js(code) or True

# ----------------- Actions -----------------
def perform_action(a:Dict,ctx:Optional[Dict]=None):
    t=a.get("type")
    if t=="notify_admin": alert_admin(a.get("message","No message"))
    elif t=="adjust_weight": CTX["weights"][a.get("trigger")]=a.get("weight",1.0)
    elif t=="ai_reinforce": CTX["score"]+=5
    elif t=="restart_service": subprocess.run(["systemctl","restart",a.get("service")],check=False)
    elif t=="snapshot": json.dump(CTX,open("ctx_snapshot.json","w"))
    elif t=="webhook_notify": safe_exec(lambda c: requests.post(a.get("url"),json={"status":ctx,"score":CTX["score"]}),ctx)
    else: logging.info(f"Unknown action: {t}")

# ----------------- Triggers -----------------
TRIGGERS={
"cpu_spike":cpu_check,"ram_pressure":ram_check,"gpu_usage":gpu_check,"process_start":proc_check,
"network_anomaly":net_check,"sensor_temp":sensor_check,"usb_connect":usb_check,"file_stego":file_stego_check,
"pdf_js":pdf_js_check,"vba_macro":vba_macro_check,"js_event":js_event_exec
}

def evaluate_triggers(triggers:Dict,ctx:Optional[Dict]=None):
    ctx=ctx or {}; status={}
    for t in triggers:
        f=TRIGGERS.get(t.get("type"))
        args=t.get("args",{})
        res=safe_exec(lambda c: f(**args) if f else False,ctx,t.get("name",t.get("type")))
        status[t.get("type")]=bool(res)
        CTX["history"].append((t.get("type"),bool(res),time.time()))
        CTX["score"]+=CTX["weights"].get(t.get("type"),1.0)*(1 if res else 0)
    return status

def evaluate_combos(status:Dict):
    v=sum(1 for val in status.values() if val)
    cmb="ultra_combo" if v>=4 else "triple_combo" if v==3 else "double_combo" if v==2 else None
    cmb and status.update({f"combo:{cmb}":True})

# ----------------- Agents -----------------
class MicroAgent:
    def __init__(self,cfg:Dict[str,Any]):
        self.cfg=cfg; self.cfg.setdefault("triggers",cfg.get("triggers",[]))
        self.status:Dict[str,bool]={}; self.wake="sleep"; self.last=time.time()
    def update_wake(self):
        now=time.time(); active=any(self.status.values())
        if active:self.last=now; self.wake="full_wake" if sum(bool(v) for v in self.status.values())>=2 else "semi_wake"
        elif now-self.last>5:self.wake="sleep"
    def listen(self):
        for t in self.cfg.get("triggers",[]):
            f=TRIGGERS.get(t["type"]); v=f(t) if f else False
            score(t["type"],v); self.status[t["type"]]=bool(v)
        cb=combo(self.status); cb and self.status.update({f"combo:{cb}":True})
        self.update_wake(); return self.status

class MacroAgent:
    def __init__(self,cfg:Dict[str,Any]): self.cfg=cfg
    def evaluate(self,status:Dict[str,bool],wake:str):
        if wake=="sleep": return
        for a in self.cfg.get("actions",[]):
            sh=False; cond=a.get("condition","all")
            if cond=="all" and all(status.values()): sh=True
            elif cond=="any" and any(status.values()): sh=True
            elif cond=="combo" and any(k.startswith("combo:") for k in status): sh=True
            elif cond=="custom":
                try: sh=eval(a.get("expr","False"),{},status)
                except: sh=False
            if sh: self.exec(a)
    def exec(self,a):
        t=a.get("type"); CTX["actions"].append(t); CTX["count"]=CTX.get("count",0)+1
        safe_exec(lambda c: perform_action(a,ctx=c),CTX); logging.info(f"Macro action executed: {t}")

# ----------------- Main Loop -----------------
def main_loop(json_path="config.json"):
    cfg=load_config(json_path); micro=MicroAgent(cfg); macro=MacroAgent(cfg)
    while True:
        st=micro.listen()
        if micro.wake!="sleep":
            logging.info({"status":st,"wake":micro.wake,"score":CTX["score"],"history":CTX["history"][-10:]})
            macro.evaluate(st,micro.wake)
        time.sleep(0.5 if micro.wake!="sleep" else 2)

if __name__=="__main__":
    threading.Thread(target=main_loop,daemon=True).start() 