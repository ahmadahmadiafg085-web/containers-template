#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <thread>
#include <chrono>
#include <mutex>
#include <memory>

// ----------------------
// Logging Utility
// ----------------------
#define INFO(msg) std::cout << "\033[36m[INFO]\033[0m " << msg << std::endl
#define WARN(msg) std::cout << "\033[33m[WARN]\033[0m " << msg << std::endl
#define ERROR(msg) std::cout << "\033[31m[ERROR]\033[0m " << msg << std::endl
#define PLUGIN(msg) std::cout << "\033[35m[PLUGIN]\033[0m " << msg << std::endl

// ----------------------
// Tenant & Feature Flags
// ----------------------
struct FeatureFlag {
    std::string name;
    bool enabled;
};

struct Module {
    std::string name;
    std::string type; // JS / WASM / PYTHON / PLUGIN
    std::string url;
    bool enabled;
    virtual ~Module() = default;
    virtual void execute() {
        INFO("Executing module: " + name + " (" + type + ")");
    }
};

struct Plugin : public Module {
    void execute() override {
        PLUGIN("Executing plugin: " + name);
    }
};

struct Tenant {
    std::string name;
    bool active;
    bool killSwitch;
    std::vector<std::shared_ptr<Module>> modules;
    std::vector<FeatureFlag> features;
};

// ----------------------
// Global Orchestrator
// ----------------------
class Orchestrator {
private:
    std::map<std::string, Tenant> tenants;
    std::mutex mtx;

public:
    void addTenant(const Tenant& t) {
        std::lock_guard<std::mutex> lock(mtx);
        tenants[t.name] = t;
    }

    void runTenant(const std::string& name) {
        Tenant t;
        {
            std::lock_guard<std::mutex> lock(mtx);
            if(tenants.find(name) == tenants.end()) {
                ERROR("Tenant not found: " + name);
                return;
            }
            t = tenants[name];
        }

        if(!t.active) {
            INFO("Tenant inactive: " + t.name);
            return;
        }
        if(t.killSwitch) {
            WARN("Kill switch active, stopping runtime: " + t.name);
            return;
        }

        INFO("Starting runtime for tenant: " + t.name);

        // Load modules concurrently
        std::vector<std::thread> moduleThreads;
        for(auto& mod : t.modules) {
            if(!mod->enabled) continue;
            moduleThreads.emplace_back([mod](){
                mod->execute();
                std::this_thread::sleep_for(std::chrono::milliseconds(200)); // simulate load
            });
        }

        // Wait for all module threads
        for(auto& th : moduleThreads) th.join();

        // Apply feature flags
        for(const auto &f : t.features) {
            INFO("Feature [" + f.name + "] = " + (f.enabled ? "ON" : "OFF"));
        }

        INFO("Runtime active for tenant: " + t.name);
    }

    void runAll() {
        std::vector<std::thread> tenantThreads;
        for(const auto &kv : tenants) {
            tenantThreads.emplace_back([this, name=kv.first](){
                this->runTenant(name);
            });
        }
        for(auto& th : tenantThreads) th.join();
    }
};

// ----------------------
// Example Usage
// ----------------------
int main() {
    Orchestrator orchestrator;

    Tenant clientA;
    clientA.name = "Client_A";
    clientA.active = true;
    clientA.killSwitch = false;
    clientA.modules = {
        std::make_shared<Module>(Module{"core", "JS", "https://cdn.vortexhub.io/js/core.js", true}),
        std::make_shared<Module>(Module{"compute", "WASM", "https://cdn.vortexhub.io/wasm/compute.wasm", true}),
        std::make_shared<Module>(Module{"ai", "PYTHON", "https://cdn.vortexhub.io/python/ai.py", true}),
        std::make_shared<Plugin>(Plugin{"plugin_example", "PLUGIN", "local/plugin.so", true})
    };
    clientA.features = {{"gpu_compute", true}, {"quantum_pipe", false}};
    orchestrator.addTenant(clientA);

    Tenant clientB;
    clientB.name = "Client_B";
    clientB.active = true;
    clientB.killSwitch = true;
    orchestrator.addTenant(clientB);

    orchestrator.runAll();

    return 0;
}