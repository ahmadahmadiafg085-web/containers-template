(async function() {
    // ==== Utility: fetch JSON safely ====
    const fetchJSON = async (url) => {
        try {
            const res = await fetch(url);
            if (!res.ok) throw new Error("Fetch JSON failed: " + url);
            return await res.json();
        } catch (e) {
            console.error(e);
            return null;
        }
    };

    // ==== Load JSON metadata ====
    const masterOrchestrator = await fetchJSON("./json/master-orchestrator.json");
    const hybridLoader = await fetchJSON("./json/hybrid-loader.json");
    console.log("JSONs loaded");

    // ==== Preload modules based on extension ====
    const preloadModule = async (url) => {
        try {
            if (url.endsWith(".js")) return import(url);
            if (url.endsWith(".wasm")) {
                const buffer = await (await fetch(url)).arrayBuffer();
                return await WebAssembly.instantiate(buffer, {});
            }
            if (url.endsWith(".py")) return await (await fetch(url)).text();
            return url; // fallback (php or others)
        } catch (e) {
            console.warn("Module preload failed:", url, e);
            return null;
        }
    };

    // ==== Prepare module URLs ====
    const tenantModules = masterOrchestrator?.tenants?.tenant_default?.modules || {};
    const urls = [
        tenantModules?.js?.core?.url,
        tenantModules?.wasm?.compute?.url,
        tenantModules?.python?.ai?.url,
        "./php/adapter.php"
    ].filter(Boolean);

    // ==== Preload all modules concurrently ====
    const modules = await Promise.allSettled(urls.map(preloadModule));
    const loadedModules = modules.map(m => m.status === "fulfilled" ? m.value : null);
    console.log("Modules preloaded:", loadedModules);

    // ==== Initialize WASM modules ====
    loadedModules.filter(m => m instanceof WebAssembly.Instance).forEach(wasm => {
        if (wasm.exports.init) wasm.exports.init();
    });
    console.log("WASM threads ready");

    // ==== Initialize Python bridge (Pyodide) ====
    let pyodide;
    try {
        if (window.loadPyodide) {
            pyodide = await loadPyodide({ indexURL: "./pyodide/" });
            const pythonModules = tenantModules?.python || {};
            for (const key in pythonModules) {
                const code = await fetch(pythonModules[key].url).then(r => r.text());
                await pyodide.runPythonAsync(code);
            }
            console.log("Python bridge ready");
        }
    } catch (e) {
        console.warn("Pyodide init failed:", e);
    }

    // ==== Initialize GPU (WebGPU) ====
    if (navigator.gpu) {
        try {
            const adapter = await navigator.gpu.requestAdapter();
            const device = await adapter.requestDevice();
            console.log("GPU ready", device);
        } catch (e) {
            console.warn("WebGPU init failed:", e);
        }
    }

    // ==== Quantum cluster info ====
    console.log("Quantum cluster nodes:", hybridLoader?.quantumCluster?.nodes);

    // ==== Generate adapters for each type ====
    const genAdapter = async (type, url) => {
        switch (type) {
            case "js": return import(url).catch(e => { console.warn(e); return null; });
            case "python": 
                if (pyodide) {
                    const code = await fetch(url).then(r => r.text());
                    return pyodide.runPythonAsync(code);
                }
                return null;
            case "php": return url;
            case "wasm":
                const buffer = await (await fetch(url)).arrayBuffer();
                return WebAssembly.instantiate(buffer, {}).catch(e => { console.warn(e); return null; });
            default: return null;
        }
    };

    const adapters = {};
    ["js", "python", "php", "wasm"].forEach(type => adapters[type] = genAdapter(type, ""));
    console.log("Adapters generated");

    // ==== Hot reload ====
    if (hybridLoader?.pipeline?.hotReload) {
        const interval = hybridLoader?.update?.hotReloadInterval || 60000;
        setInterval(async () => {
            const updatedJSON = await fetchJSON("./json/master-orchestrator.json");
            if (updatedJSON) console.log("Hot reload JSON:", updatedJSON.version);
        }, interval);
    }

    // ==== Master kill switch ====
    if (hybridLoader?.masterControl?.killSwitch) {
        return console.warn("Remote kill switch active");
    }

    console.log("VortexHub Fully Bundled Single-Step Runtime initialized!");
})();