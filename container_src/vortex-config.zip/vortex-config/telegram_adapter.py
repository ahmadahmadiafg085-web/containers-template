import asyncio,logging,traceback,datetime,time,random
from typing import Dict,List,Callable,Optional,Any

logger=logging.getLogger(“TelegramAdapter”)
logger.setLevel(logging.INFO)

class TelegramAdapterConfig:
    def __init__(self,bot_token:str,default_chat_id:Optional[str]=None,
                 max_retries:int=3,retry_delay:int=2,
                 enable_metrics:bool=True,enable_context_tracking:bool=True,
                 enable_dag_execution:bool=True,enable_scheduled_tasks:bool=True,
                 enable_dry_run:bool=True,enable_hot_reload:bool=True,
                 max_context_length:int=50,scheduled_interval:int=60):
        self.bot_token=bot_token
        self.default_chat_id=default_chat_id
        self.max_retries=max_retries
        self.retry_delay=retry_delay
        self.enable_metrics=enable_metrics
        self.enable_context_tracking=enable_context_tracking
        self.enable_dag_execution=enable_dag_execution
        self.enable_scheduled_tasks=enable_scheduled_tasks
        self.enable_dry_run=enable_dry_run
        self.enable_hot_reload=enable_hot_reload
        self.max_context_length=max_context_length
        self.scheduled_interval=scheduled_interval

class TelegramAdapter:
    def __init__(self,config:TelegramAdapterConfig,backend_execute:Callable,tenant_id:str):
        self.config=config
        self.backend_execute=backend_execute
        self.tenant_id=tenant_id
        self.module_states:Dict[str,str]={}
        self.module_dependencies:Dict[str,List[str]]={}
        self.execution_history:Dict[str,List[Dict[str,Any]]]={}
        self.retry_counts:Dict[str,int]={}
        self._executing_modules:Dict[str,asyncio.Lock]={}
        self.message_context:Dict[str,List[str]]={}
        self._scheduled_task:Optional[asyncio.Task]=None

    def _tenant_key(self,key:str)->str:
        return f”{self.tenant_id}:{key}”

    def add_context(self,chat_id:str,message:str):
        if not self.config.enable_context_tracking:return
        key=self._tenant_key(chat_id)
        self.message_context.setdefault(key,[]).append(message)
        self.message_context[key]=self.message_context[key][-self.config.max_context_length:]

    async def send_message(self,chat_id:Optional[str],text:str):
        chat_id=chat_id or self.config.default_chat_id
        if not chat_id:logger.warning(“No chat_id provided”);return False
        retries=0;tenant_key=self._tenant_key(chat_id)
        while retries<=self.config.max_retries:
            try:
                if self.config.enable_dry_run:
                    logger.info(f”[DRY-RUN][{self.tenant_id}] Send to {chat_id}: {text}”)
                else:
                    await self.backend_execute(“telegram”,”send_message”,[chat_id,text],tenant_id=self.tenant_id)
                self.add_context(chat_id,text)
                self.module_states[tenant_key]=“completed”
                self.execution_history.setdefault(tenant_key,[]).append({
                    “timestamp”:datetime.datetime.utcnow().isoformat(),
                    “text”:text,”status”:”completed”})
                return True
            except Exception as e:
                retries+=1
                self.retry_counts[tenant_key]=retries
                self.module_states[tenant_key]=“failed”
                self.execution_history.setdefault(tenant_key,[]).append({
                    “timestamp”:datetime.datetime.utcnow().isoformat(),
                    “text”:text,”status”:”failed”,”error”:str(e)})
                logger.error(f”[TelegramAdapter][{self.tenant_id}] Send failed attempt {retries}: {e}”)
                traceback.print_exc()
                if retries>self.config.max_retries:return False
                await asyncio.sleep(self.config.retry_delay)

    async def execute_module_safe(self,module_name:str,args:List[str]=[]):
        tenant_key=self._tenant_key(module_name)
        if tenant_key not in self._executing_modules:self._executing_modules[tenant_key]=asyncio.Lock()
        async with self._executing_modules[tenant_key]:
            for dep in self.module_dependencies.get(module_name,[]):
                await self.execute_module_safe(dep,[])
            retries=0
            while retries<=self.config.max_retries:
                try:
                    self.module_states[tenant_key]=“running”
                    await self.backend_execute(“telegram”,module_name,[“—pre-hook”]+args,tenant_id=self.tenant_id)
                    await self.backend_execute(“telegram”,module_name,args,tenant_id=self.tenant_id)
                    await self.backend_execute(“telegram”,module_name,[“—post-hook”]+args,tenant_id=self.tenant_id)
                    self.module_states[tenant_key]=“completed”
                    self.execution_history.setdefault(tenant_key,[]).append({
                        “timestamp”:datetime.datetime.utcnow().isoformat(),”args”:args,”status”:”completed”})
                    return
                except Exception as e:
                    retries+=1
                    self.retry_counts[tenant_key]=retries
                    self.module_states[tenant_key]=“failed”
                    self.execution_history.setdefault(tenant_key,[]).append({
                        “timestamp”:datetime.datetime.utcnow().isoformat(),”args”:args,
                        “status”:”failed”,”error”:str(e)})
                    logger.error(f”[TelegramAdapter][{self.tenant_id}] Module {module_name} failed attempt {retries}: {e}”)
                    traceback.print_exc()
                    if retries>self.config.max_retries:return
                    await asyncio.sleep(self.config.retry_delay)

    async def hot_reload_module(self,module_name:str):
        if not self.config.enable_hot_reload:return
        try:
            await self.backend_execute(“telegram”,module_name,[“—reload”],tenant_id=self.tenant_id)
            logger.info(f”[TelegramAdapter][{self.tenant_id}] Module {module_name} hot reloaded”)
        except Exception as e:
            logger.error(f”[TelegramAdapter][{self.tenant_id}] Hot reload failed for {module_name}: {e}”)
            traceback.print_exc()

    async def dry_run_module(self,module_name:str):
        if not self.config.enable_dry_run:return
        try:
            await self.backend_execute(“telegram”,module_name,[“—dry-run”],tenant_id=self.tenant_id)
        except Exception as e:
            logger.error(f”[TelegramAdapter][{self.tenant_id}] Dry run failed for {module_name}: {e}”)
            traceback.print_exc()

    async def run_scheduled_modules(self):
        if not self.config.enable_scheduled_tasks:return
        while True:
            for m,state in self.module_states.items():
                if state==“scheduled”:
                    await self.execute_module_safe(m,[])
            await asyncio.sleep(self.config.scheduled_interval)

    def metrics_summary(self,module_name:Optional[str]=None):
        key=self._tenant_key(module_name) if module_name else None
        return self.execution_history.get(key,[]) if module_name else self.execution_history

    def add_module_dependency(self,module_name:str,dependencies:List[str]):
        self.module_dependencies[module_name]=dependencies

    async def run_module(self,module_name:str,args:List[str]=[],dry_run=False,hot_reload=False):
        if hot_reload: await self.hot_reload_module(module_name)
        if dry_run: await self.dry_run_module(module_name)
        await self.execute_module_safe(module_name,args)

def create_telegram_adapter(config:TelegramAdapterConfig,backend_execute:Callable,tenant_id:str):
    adapter=TelegramAdapter(config,backend_execute,tenant_id)
    if config.enable_scheduled_tasks:
        adapter._scheduled_task=asyncio.create_task(adapter.run_scheduled_modules())
    return adapter
    