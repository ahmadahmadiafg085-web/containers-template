import os
import json
from modules.parsers import LogParser
from modules.analytics import Analyzer
from modules.alerts import AlertManager
from modules.visualization import Dashboard

class LogsViewer:
    def __init__(self, config):
        self.parser = LogParser(config.get(‘parser’, {}))
        self.analyzer = Analyzer(config.get(‘analytics’, {}))
        self.alerts = AlertManager(config.get(‘alerts’, {}))
        self.dashboard = Dashboard(config.get(‘visualization’, {}))
        self.logs_buffer = []

    def ingest_log(self, raw_log):
        parsed = self.parser.parse(raw_log)
        self.logs_buffer.append(parsed)
        analysis = self.analyzer.analyze(parsed)
        self.alerts.check(analysis)
        self.dashboard.update(parsed, analysis)

    def run_stream(self, log_source):
        for raw_log in log_source.stream():
            self.ingest_log(raw_log)