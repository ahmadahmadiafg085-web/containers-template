// adapter_go_to_py-final.go
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"os/exec"
	"sync"
	"time"
)

// -----------------------------
// Adapter Config & State
// -----------------------------
type Adapter struct {
	env           string
	cache         map[string][]byte
	cacheMutex    sync.RWMutex
	pythonBinPath string
}

// Ensure Adapter implements http.Handler
var _ http.Handler = (*Adapter)(nil)

// -----------------------------
// Constructor
// -----------------------------
func NewAdapter(env string, pythonPath ...string) *Adapter {
	a := &Adapter{
		env:   env,
		cache: make(map[string][]byte),
	}
	if len(pythonPath) > 0 {
		a.pythonBinPath = pythonPath[0]
	} else {
		a.pythonBinPath = "python3"
	}
	return a
}

// -----------------------------
// Serialization
// -----------------------------
func serialize(data interface{}) ([]byte, error) {
	return json.Marshal(data)
}

func deserialize(data []byte, target interface{}) error {
	return json.Unmarshal(data, target)
}

// -----------------------------
// Cache Handling
// -----------------------------
func (a *Adapter) SetCache(key string, value interface{}) error {
	a.cacheMutex.Lock()
	defer a.cacheMutex.Unlock()
	data, err := serialize(value)
	if err != nil {
		return err
	}
	a.cache[key] = data
	return nil
}

func (a *Adapter) GetCache(key string, target interface{}) bool {
	a.cacheMutex.RLock()
	defer a.cacheMutex.RUnlock()
	if data, ok := a.cache[key]; ok {
		if err := deserialize(data, target); err != nil {
			return false
		}
		return true
	}
	return false
}

// -----------------------------
// Go Function Call
// -----------------------------
func (a *Adapter) callGo(funcName string, args ...interface{}) (interface{}, error) {
	switch funcName {
	case "add":
		if len(args) != 2 {
			return nil, fmt.Errorf("add expects 2 args")
		}
		a1, ok1 := toFloat64(args[0])
		a2, ok2 := toFloat64(args[1])
		if !ok1 || !ok2 {
			return nil, fmt.Errorf("invalid args for add")
		}
		return a1 + a2, nil
	case "predict_example":
		return map[string]interface{}{"prediction": "example_result"}, nil
	default:
		return nil, fmt.Errorf("Go function '%s' not found", funcName)
	}
}

// safe conversion to float64
func toFloat64(v interface{}) (float64, bool) {
	switch val := v.(type) {
	case float64:
		return val, true
	case int:
		return float64(val), true
	case int32:
		return float64(val), true
	case int64:
		return float64(val), true
	default:
		return 0, false
	}
}

// -----------------------------
// Python Function Call
// -----------------------------
func (a *Adapter) callPython(funcName string, args ...interface{}) (interface{}, error) {
	argsJSON, err := serialize(args)
	if err != nil {
		return nil, err
	}

	pyScript := fmt.Sprintf(`
import sys, json

def add(x, y):
    return x + y

def multiply(x, y):
    return x * y

def predict_example():
    return {"prediction": "example_result"}

functions = {
    "add": add,
    "multiply": multiply,
    "predict_example": predict_example
}

args = json.loads(sys.argv[1])
func_name = "%s"

result = None
if func_name in functions:
    func = functions[func_name]
    if callable(func):
        if func_name == "predict_example":
            result = func()
        else:
            result = func(*args)
print(json.dumps(result))
`, funcName)

	cmd := exec.Command(a.pythonBinPath, "-c", pyScript, string(argsJSON))
	var out bytes.Buffer
	var stderr bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &stderr

	err = cmd.Run()
	if err != nil {
		return nil, fmt.Errorf("python call error: %s | %s", err, stderr.String())
	}

	var result interface{}
	if err := deserialize(out.Bytes(), &result); err != nil {
		return nil, err
	}
	return result, nil
}

// -----------------------------
// Generic Call Interface
// -----------------------------
func (a *Adapter) Call(funcName string, args ...interface{}) (interface{}, error) {
	cacheKey := funcName + "_" + fmt.Sprint(args...)
	if a.GetCache(cacheKey, new(interface{})) {
		var cached interface{}
		a.GetCache(cacheKey, &cached)
		return cached, nil
	}

	var result interface{}
	var err error
	switch a.env {
	case "go":
		result, err = a.callGo(funcName, args...)
	case "python":
		result, err = a.callPython(funcName, args...)
	default:
		err = fmt.Errorf("unsupported environment: %s", a.env)
	}

	if err == nil {
		a.SetCache(cacheKey, result)
	}

	return result, err
}

// -----------------------------
// Web / Real-time Handler
// -----------------------------
func (a *Adapter) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	funcName := r.URL.Query().Get("func")
	if funcName == "" {
		http.Error(w, "func parameter missing", http.StatusBadRequest)
		return
	}

	var args []interface{}
	if r.Body != nil {
		defer r.Body.Close()
		if err := json.NewDecoder(r.Body).Decode(&args); err != nil {
			http.Error(w, "invalid json body", http.StatusBadRequest)
			return
		}
	}

	res, err := a.Call(funcName, args...)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(res)
}

// -----------------------------
// Main / Example
// -----------------------------
func main() {
	adapterPy := NewAdapter("python")
	adapterGo := NewAdapter("go")

	// تست Python
	if resPy, err := adapterPy.Call("add", 10, 20); err != nil {
		fmt.Println("Python Error:", err)
	} else {
		fmt.Println("Python Result:", resPy)
	}

	// تست Go
	if resGo, err := adapterGo.Call("add", 5, 7); err != nil {
		fmt.Println("Go Error:", err)
	} else {
		fmt.Println("Go Result:", resGo)
	}

	// راه‌اندازی Web server real-time
	serverAdapter := NewAdapter("python")
	http.Handle("/adapter", serverAdapter)
	fmt.Println("Serving Adapter on :8080 ...")
	go func() {
		if err := http.ListenAndServe(":8080", nil); err != nil {
			fmt.Println("Server Error:", err)
		}
	}()

	// شبیه‌سازی long running و diagnostics
	for i := 0; i < 3; i++ {
		time.Sleep(1 * time.Second)
		fmt.Println("Diagnostics cycle", i+1)
	}
}
