import json
from base64 import b64decode
import asyncio
import aiohttp
import time
import logging
from typing import Any, List, Dict

logging.basicConfig(level=logging.INFO, format=‘[%(levelname)s] %(asctime)s - %(message)s’)

# ================================
# 🌐 CONFIGURATION DICTIONARY
# ================================
CONFIG = {
    “version”: “1.0.2”,
    “config_token”: “VHX-2025-SECURE-01”,
    “config_expiry”: “2025-12-31T23:59:59Z”,
    “valkey”: “redis://red-d4f8qishg0os738qkgt0:6379”,
    “allowed_ips”: [
        “44.229.227.142”,
        “52.13.128.108”,
        “54.188.71.94”,
        “74.220.48.0/24”,
        “74.220.56.0/24”
    ],
    “deployment”: {
        “render_url”: “https://vortex-universal-orchestrator-cppw.onrender.com”,
        “status”: “active”,
        “last_deploy_commit”: “bdc06dba0415d5718871d6e6dfa85cadb636533b”,
        “region”: “Frankfurt”
    },
    “links”: {
        “github_repo”: “https://github.com/ahmadahmadiafg085-web/vortex-universal-orchestrator”,
        “github_raw_base”: “https://raw.githubusercontent.com/“,
        “base64_github”: “aHR0cHM6Ly9naXRodWIuY29tL2FobWFkYWhtYWRpYWZnMDg1LXdlYi92b3J0ZXgtdW5pdmVyc2FsLW9yY2hlc3”,
        “vercel_live”: “https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app”,
        “vercel_api”: “https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/api”,
        “vercel_api_data”: “https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/api/data”,
        “vercel_data_json”: “https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/data.json”,
        “google_drive_download”: “https://drive.google.com/uc?export=download&id=1Kt0qLYaOfrh_pM6i-8WPFqE9P415uP-N”,
        “k00_links”: [
            {“url”: “https://k00.fr/cv9tsz1p”, “password”: “285861”},
            {“url”: “https://k00.fr/k9ourdsf”},
            {“url”: “https://k00.fr/mqdrkha5”},
            {“url”: “https://app.koofr.net/app/storage/d9699792-7987-4f17-9069-d0a14e681749”}
        ]
    },
    “credentials”: {
        “api_key”: “74074fb6f51063e40f55”,
        “api_secret”: “885439176976b165e50f414fdd594a2c75a89f85512927359416b9d79aae93ab”,
        “jwt”: “<JWT_TOKEN_HERE>”
    },
    “triggers”: [“file_update”, “agent_login”, “service_call”, “runtime_error”],
    “metadata”: {
        “last_update”: “2025-11-20T20:00:00Z”,
        “repo_link”: “https://github.com/ahmadahmadiafg085-web/vortex-universal-orchestrator”,
        “author”: “VortexHub Labs”,
        “metadata_signature”: “HMAC-SHA256”,
        “metadata_schema_version”: “2.2”
    }
}

# ================================
# 🌐 HELPER FUNCTIONS
# ================================
def get_config(key_path: str, default=None):
    keys = key_path.split(“.”)
    data = CONFIG
    try:
        for key in keys:
            data = data[key]
        return data
    except KeyError:
        return default


def decode_base64_github() -> str:
    encoded = CONFIG[“links”][“base64_github”]
    return b64decode(encoded + “==“).decode(“utf-8”)


def dump_config_json(pretty=True) -> str:
    return json.dumps(CONFIG, indent=4) if pretty else json.dumps(CONFIG)


# ================================
# 🌐 BOOTLOADER
# ================================
class Bootstrapper:
    “””Bootloader: بررسی شرایط و آماده سازی سناریو”””
    def __init__(self):
        self.validated = False
        self.start_time = time.time()

    def validate_environment(self):
        # بررسی IP و token (نمونه)
        self.validated = True
        logging.info(“🔒 Environment validated.”)

    def check_triggers(self, trigger: str):
        if trigger not in CONFIG[“triggers”]:
            raise ValueError(f”Trigger {trigger} not allowed.”)
        logging.info(f”⚡ Trigger ‘{trigger}’ recognized.”)

    def initialize(self, trigger: str):
        self.validate_environment()
        self.check_triggers(trigger)
        logging.info(“🚀 Bootloader initialized.”)


# ================================
# 🌐 ASYNC FETCH WITH RETRY
# ================================
async def fetch_url(session: aiohttp.ClientSession, url: str, retries=3, timeout=15) -> Any:
    for attempt in range(1, retries + 1):
        try:
            async with session.get(url, timeout=timeout) as response:
                content_type = response.headers.get(“Content-Type”, “”)
                if “application/json” in content_type:
                    data = await response.json()
                    logging.info(f”✅ JSON fetched: {url}”)
                    return data
                else:
                    text = await response.text()
                    logging.info(f”✅ Text fetched: {url}”)
                    return text
        except Exception as e:
            logging.warning(f”⚠️ Attempt {attempt} failed for {url}: {e}”)
            await asyncio.sleep(1)
    logging.error(f”❌ Failed to fetch {url} after {retries} attempts”)
    return None


async def fetch_all_urls(urls: List[str]) -> Dict[str, Any]:
    results = {}
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_url(session, url) for url in urls]
        responses = await asyncio.gather(*tasks)
        for url, data in zip(urls, responses):
            results[url] = data
    return results


# ================================
# 🌐 AGENT / OPERATIONAL FETCH
# ================================
class Agent:
    “””Agent for orchestrating fetch and data merge”””
    def __init__(self):
        self.data_store = {}

    async def fetch_snippets_operational(self):
        urls = [
            decode_base64_github(),
            get_config(“links.google_drive_download”),
            get_config(“links.vercel_api”),
            get_config(“links.vercel_api_data”),
            get_config(“links.vercel_data_json”)
        ]
        for k in get_config(“links.k00_links”):
            urls.append(k[“url”])

        self.data_store = await fetch_all_urls(urls)
        logging.info(“📦 Operational fetch completed.”)
        return self.data_store

    def get_data(self):
        return self.data_store


# ================================
# 🌐 JOHNSON GENERATOR (MERGE / NORMALIZE)
# ================================
class JohnsonGenerator:
    “””Merge and normalize fetched JSON/text data”””
    @staticmethod
    def merge_data(agent_data: Dict[str, Any]) -> Dict[str, Any]:
        merged = {}
        for k, v in agent_data.items():
            key = k.split(“/“)[-1]
            merged[key] = v
        logging.info(“🧩 Data merged and normalized.”)
        return merged


# ================================
# 🌐 MAIN EXECUTION
# ================================
if __name__ == “__main__”:
    trigger_event = “agent_login”  # نمونه trigger
    bootstrap = Bootstrapper()
    bootstrap.initialize(trigger_event)

    print(“🚀 Render URL:”, get_config(“deployment.render_url”))
    print(“🔑 API Key:”, get_config(“credentials.api_key”))
    print(“🌐 Decoded GitHub Base64:”, decode_base64_github())
    print(“📄 Full JSON dump:”)
    print(dump_config_json())

    # اجرای Agent و fetch عملیاتی
    agent = Agent()
    loop = asyncio.get_event_loop()
    fetched_data = loop.run_until_complete(agent.fetch_snippets_operational())

    # Merge و normalize
    merged_data = JohnsonGenerator.merge_data(fetched_data)
    print(“\n📊 Merged Operational Data:”)
    print(json.dumps(merged_data, indent=4, ensure_ascii=False))