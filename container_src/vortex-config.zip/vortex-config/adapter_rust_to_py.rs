// src/bridge_scenario.rs
//! Integrated FFI Bridge + Scenario Engine
//! Supports Rust → Python → WASM → Node.js
//! Conditional, Action-based, Local & Remote triggers

use serde::{Serialize, Deserialize};
use serde_json::Value;
use std::collections::HashMap;
use chrono::{Utc, DateTime};
use pyo3::prelude::*;
use wasm_bindgen::prelude::*;

// ===================== FFI Bridge =====================

#[derive(Clone, Serialize, Deserialize)]
pub struct FfiTask {
    pub id: u64,
    pub action: String,
    pub payload: Value,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct FfiResult {
    pub id: u64,
    pub status: String,
    pub output: Value,
}

// Rust → Python bridge
#[pyfunction]
pub fn execute_task_py(task_json: &str) -> PyResult<String> {
    let task: FfiTask = serde_json::from_str(task_json)?;
    let result = FfiResult { id: task.id, status: "ok".into(), output: task.payload };
    Ok(serde_json::to_string(&result)?)
}

// Rust → WASM / Node.js bridge
#[wasm_bindgen]
pub fn execute_task_wasm(task_json: &str) -> String {
    let task: FfiTask = serde_json::from_str(task_json).unwrap();
    let result = FfiResult { id: task.id, status: "ok".into(), output: task.payload };
    serde_json::to_string(&result).unwrap()
}

// ===================== Scenario Engine =====================

#[derive(Clone, Serialize, Deserialize)]
pub enum Trigger {
    Timer(u64),           // هر n ثانیه
    FileChange(String),   // تغییر فایل خاص
    HttpRequest(String),  // فراخوانی API
    Condition(String),    // expression / شرط سفارشی
}

#[derive(Clone, Serialize, Deserialize)]
pub enum Action {
    RunCommand(String),    // PowerShell / bash / terminal
    ExecuteModule(String), // Module name
    SendEvent(String),     // به سیستم دیگر
    Log(String),           // لاگ محلی
}

#[derive(Clone, Serialize, Deserialize)]
pub struct ScenarioTask {
    pub id: u64,
    pub triggers: Vec<Trigger>,
    pub actions: Vec<Action>,
    pub status: String,
    pub created: DateTime<Utc>,
}

#[derive(Clone)]
pub struct ScenarioEngine {
    pub tasks: HashMap<u64, ScenarioTask>,
}

impl ScenarioEngine {
    pub fn new() -> Self {
        Self { tasks: HashMap::new() }
    }

    pub fn add_task(&mut self, task: ScenarioTask) {
        self.tasks.insert(task.id, task);
    }

    pub fn evaluate_triggers(&self, task: &ScenarioTask) -> bool {
        // Placeholder: implement real trigger evaluation
        // Timer, FileChange, HttpRequest, Condition parsing
        true
    }

    pub fn execute(&mut self) {
        for task in self.tasks.values_mut() {
            if self.evaluate_triggers(task) {
                for action in &task.actions {
                    match action {
                        Action::RunCommand(cmd) => {
                            #[cfg(target_os = "windows")]
                            {
                                let _ = std::process::Command::new("powershell")
                                    .arg("-Command")
                                    .arg(cmd)
                                    .status();
                            }
                            #[cfg(not(target_os = "windows"))]
                            {
                                let _ = std::process::Command::new("sh")
                                    .arg("-c")
                                    .arg(cmd)
                                    .status();
                            }
                        }
                        Action::ExecuteModule(name) => {
                            println!("[SCENARIO] Executing module: {}", name);
                            // Optionally call FFI bridge or runtime module
                        }
                        Action::SendEvent(evt) => {
                            println!("[SCENARIO] Send event: {}", evt);
                        }
                        Action::Log(msg) => {
                            println!("[SCENARIO LOG] {}", msg);
                        }
                    }
                }
                task.status = "executed".into();
            }
        }
    }

    // Optional: generate FfiResult for external systems
    pub fn to_ffi_results(&self) -> Vec<FfiResult> {
        self.tasks.values().map(|t| FfiResult {
            id: t.id,
            status: t.status.clone(),
            output: serde_json::json!({
                "triggers": t.triggers,
                "actions": t.actions
            })
        }).collect()
    }
}

// ===================== Optional Worker Loop =====================

pub fn run_scenario_worker(mut engine: ScenarioEngine) {
    std::thread::spawn(move || loop {
        engine.execute();
        std::thread::sleep(std::time::Duration::from_secs(5));
    });
}