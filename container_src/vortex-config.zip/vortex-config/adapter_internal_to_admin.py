from typing import Dict, Any, List, Optional, Callable
import asyncio, importlib, logging, os, json, subprocess, yaml
from pathlib import Path
from datetime import datetime
from ctypes import cdll
from shared.storage.redis_connector import RedisConnector
from shared.storage.mongo_connector import MongoConnector
from core.user_manager import UserManager
from core.role_manager import RoleManager
from core.access_verifier import AccessVerifier
from core.notification_engine import NotificationEngine

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter(‘%(asctime)s - %(levelname)s - %(message)s’))
logger.addHandler(ch)

class DistributedInternalToAdminAdapter:
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        self.configs: Dict[str, Any] = {}
        self.lazy_modules: Dict[str, Any] = {}
        self.module_registry: Dict[str, Dict[str, Any]] = {}
        self.redis = RedisConnector()
        self.mongo = MongoConnector()
        self.user_manager = UserManager()
        self.role_manager = RoleManager()
        self.access_verifier = AccessVerifier()
        self.notification_engine = NotificationEngine()
        self.lock = asyncio.Lock()
        self.loop = asyncio.get_event_loop()
        self.flow_log_path = self.resolve_path(“logs/adapter_flow/flow_log.json”)
        os.makedirs(self.flow_log_path.parent, exist_ok=True)
        self._load_configs()
        self._register_lazy_modules()
        self._initialize_notification_bridge()

    def _log_flow(self, name: str, input_data: Any, output_data: Any, start_time: datetime, end_time: datetime):
        entry = {“name”: name, “start”: start_time.isoformat(), “end”: end_time.isoformat(),
                 “input”: input_data, “output”: output_data}
        logger.info(json.dumps(entry, default=str))
        with open(self.flow_log_path, “a”, encoding=“utf-8”) as f:
            f.write(json.dumps(entry, default=str) + “\n”)

    async def track_async_flow(self, name: str, coro: Callable, *args, **kwargs):
        start = datetime.utcnow()
        try:
            result = await coro(*args, **kwargs)
        finally:
            self._log_flow(name, {“args”: args, “kwargs”: kwargs}, result if ‘result’ in locals() else None,
                           start, datetime.utcnow())
        return result

    def track_flow(self, name: str, func: Callable, *args, **kwargs):
        start = datetime.utcnow()
        try:
            result = func(*args, **kwargs)
        finally:
            self._log_flow(name, {“args”: args, “kwargs”: kwargs}, result if ‘result’ in locals() else None,
                           start, datetime.utcnow())
        return result

    def _load_configs(self):
        for cfg in (self.base_path / “configs”).glob(“*.yaml”):
            try:
                self.configs[cfg.stem] = yaml.safe_load(cfg.read_text(encoding=“utf-8”))
            except Exception as e:
                logger.warning(f”Failed config {cfg}: {e}”)

    def _register_lazy_modules(self):
        mods_dir = self.base_path / “modules”
        for path in mods_dir.glob(“**/*”):
            if path.suffix in [“.py”, “.rlib”, “.so”, “.dll”, “.wasm”, “.whl”, “.js”, “.ts”]:
                name = “.”.join(path.relative_to(self.base_path).with_suffix(“”).parts)
                self.lazy_modules[name] = None
                self.module_registry[name] = {“path”: path, “loaded”: False, “version”: None, “type”: path.suffix}

    def load_module(self, name: str):
        if name not in self.lazy_modules:
            raise ValueError(f”Module {name} not registered”)
        if self.lazy_modules[name] is None:
            meta = self.module_registry[name]
            try:
                ext = meta[“type”]
                if ext == “.py”:
                    self.lazy_modules[name] = importlib.import_module(name)
                elif ext in [“.rlib”, “.so”, “.dll”]:
                    self.lazy_modules[name] = cdll.LoadLibrary(str(meta[“path”]))
                elif ext == “.wasm”:
                    import wasmer
                    self.lazy_modules[name] = wasmer.Instance(str(meta[“path”]))
                elif ext == “.whl”:
                    subprocess.run([“pip”, “install”, str(meta[“path”])], check=True)
                    self.lazy_modules[name] = importlib.import_module(name)
                elif ext in [“.js”, “.ts”]:
                    subprocess.run([“node”, str(meta[“path”])], check=True)
                meta[“loaded”] = True
                logger.info(f”Module {name} loaded”)
            except Exception as e:
                logger.error(f”Failed to load {name}: {e}”)
        return self.lazy_modules[name]

    async def run_event(self, event_name: str, payload: dict):
        return await self.track_async_flow(f”event_{event_name}”, self.notification_engine.dispatch, event_name, payload)

    def _initialize_notification_bridge(self):
        try:
            mod = self.load_module(“modules.loader_modules.notification_loader”)
            if hasattr(mod, “initialize”):
                mod.initialize(self)
        except Exception as e:
            logger.warning(f”Notification bridge init failed: {e}”)

    def get_user(self, user_id: str):
        return self.track_flow(“get_user”, self.user_manager.get_user, user_id)

    def check_permission(self, user_id: str, permission: str) -> bool:
        return self.track_flow(“check_permission”, self._check_permission_internal, user_id, permission)

    def _check_permission_internal(self, user_id: str, permission: str) -> bool:
        return self.access_verifier.has_permission(self.role_manager.get_user_roles(user_id), permission)

    def cache_set(self, key: str, value: Any, expire: Optional[int] = None):
        return self.track_flow(“cache_set”, self.redis.set, key, value, expire)

    def cache_get(self, key: str):
        return self.track_flow(“cache_get”, self.redis.get, key)

    def mongo_insert(self, collection: str, doc: dict):
        return self.track_flow(“mongo_insert”, self.mongo.insert, collection, doc)

    def mongo_find(self, collection: str, query: dict):
        return self.track_flow(“mongo_find”, self.mongo.find, collection, query)

    def execute_script(self, script_path: str, args: Optional[List[str]] = None):
        full = self.base_path / script_path
        if not full.exists():
            logger.error(f”Script {script_path} not found”)
            return
        ext = full.suffix

        def _exec():
            if ext == “.py”:
                spec = importlib.util.spec_from_file_location(full.stem, full)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                return mod
            elif ext in [“.js”, “.ts”]:
                return subprocess.run([“node”, str(full), *(args or [])], capture_output=True, text=True)
            elif ext == “.wasm”:
                import wasmer
                return wasmer.Instance(str(full))
            elif ext in [“.rlib”, “.so”, “.dll”]:
                return cdll.LoadLibrary(str(full))
            elif ext == “.whl”:
                subprocess.run([“pip”, “install”, str(full)], check=True)
                return importlib.import_module(full.stem)

        return self.track_flow(f”execute_script_{full.stem}”, _exec)

    def lazy_run_module_func(self, name: str, func_name: str, *args, **kwargs):
        def _lazy():
            mod = self.load_module(name)
            fn = getattr(mod, func_name, None)
            return fn(*args, **kwargs) if callable(fn) else logger.warning(f”{func_name} not found in {name}”)
        return self.track_flow(f”lazy_run_{name}_{func_name}”, _lazy)

    def resolve_path(self, *args) -> Path:
        return self.base_path.joinpath(*args)
        