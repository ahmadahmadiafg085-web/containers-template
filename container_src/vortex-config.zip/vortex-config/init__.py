import os,sys,importlib,hashlib,json,datetime,subprocess,platform,socket,random
META={"v":"1.0-INIT-CROSSRUNTIME","a":"Dr. Sadat","r":os.path.dirname(__file__),"c":str(datetime.datetime.now()),"m":["pattern_engine","ai_core_logic","vortex_linker","lifeguard_ai_autofix"],"region":["ASIA","EU","FALLBACK"],"tele":"https://api.vortexhub.app/telemetry","id":hex(random.getrandbits(64))[2:]}
def H(p):return hashlib.sha256(open(p,"rb").read()).hexdigest()
def C():print("[🧩]Check env");print("[✅]Python ok" if subprocess.run(["which","python3"],capture_output=True).returncode==0 else"[⚠️]No Python");print("[🌐]",META["r"],platform.system(),socket.gethostname())
def V():print("[🛡️]Verify");R={f:H(os.path.join(META["r"],f))for f in os.listdir(META["r"])if f.endswith((".py",".fs",".js",".sh"))};json.dump(R,open(os.path.join(META["r"],"telemetry_cache.json"),"w"),indent=2);return R
def L(n): 
  try:importlib.import_module(n);print("[🔗]",n)
  except Exception as e:print("[❌]",n,e)
def S(): 
  print("[🧠]AI check"); 
  if random.random()<.05:subprocess.run(["node","LifeGuard-ai_autofix.v01.js"])
def main():print("🔰VortexHub Init");C();V();subprocess.run(["ping","-c","1","cdn.vortexhub.app"],capture_output=True);[L(x)for x in META["m"]];S();print("[✅]Done")
if __name__=="__main__":main()
