import js, time, json, hashlib, asyncio
from datetime import datetime

USERS={“admin”:{“permissions”:[“read”,”write”,”delete”,”system_change”,”usb_access”]},”guest”:{“permissions”:[“read”]}}
LOG_BUFFER=[]

def _sign(obj): return hashlib.sha256(json.dumps(obj,sort_keys=True).encode()).hexdigest()
def log_event(t,d): LOG_BUFFER.append({“timestamp”:datetime.now().isoformat(),”event_type”:t,”details”:d,”signature”:_sign(d)})

class AccessControl:
 def __init__(self,u): self.users=u
 def check(self,user,act): r=self.users.get(user); return bool(r and act in r.get(“permissions”,[]))

class EventManager:
 def __init__(self): self.l={}
 def register(self,e,cb): self.l.setdefault(e,[]).append(cb)
 async def trigger(self,e,**kw):
  for cb in self.l.get(e,[]): r=cb(**kw); 
  # handle coroutine if needed
  if asyncio.iscoroutine(r): await r

ac=AccessControl(USERS)
em=EventManager()

def on_access_request(username,action): log_event(“access_request”,{“user”:username,”action”:action,”allowed”:ac.check(username,action)}); print(f”[ACCESS] {username} {action} → {ac.check(username,action)}”)
def on_file_created(path): log_event(“file_created”,{“path”:path}); asyncio.create_task(em.trigger(“access_request”,username=“guest”,action=“read”))
def on_file_modified(path): log_event(“file_modified”,{“path”:path}); asyncio.create_task(em.trigger(“access_request”,username=“admin”,action=“write”))
def on_file_deleted(path): log_event(“file_deleted”,{“path”:path}); asyncio.create_task(em.trigger(“access_request”,username=“admin”,action=“delete”))
def on_user_login(user): log_event(“login”,{“user”:user}); asyncio.create_task(em.trigger(“access_request”,username=user,action=“read”))
def on_system_change(user,desc): log_event(“system_change”,{“user”:user,”change”:desc}); asyncio.create_task(em.trigger(“access_request”,username=user,action=“system_change”))

for ev,cb in [(“access_request”,on_access_request),(“file_created”,on_file_created),(“file_modified”,on_file_modified),(“file_deleted”,on_file_deleted)]: em.register(ev,cb)

async def simulate_events():
 await asyncio.sleep(1); on_user_login(“admin”)
 await asyncio.sleep(1); on_user_login(“guest”)
 await asyncio.sleep(1); on_system_change(“admin”,”Firewall modified”)
 await asyncio.sleep(1); on_file_created(“demo.txt”)
 await asyncio.sleep(1); on_file_modified(“demo.txt”)
 await asyncio.sleep(1); on_file_deleted(“demo.txt”)

asyncio.create_task(simulate_events())

def export_logs():
 try: js.localStorage.setItem(“EVENT_LOGS”,json.dumps(LOG_BUFFER)); print(“[INFO] Logs exported”)
 except Exception as e: print(“[EXPORT ERROR]”,e)

print(“[INFO] Pyodide Event Monitor → Active”)
