<?php
// orchestrator.php

$CONFIG = [
    "version"=>"1.0.2",
    "links"=>[
        "base64_github"=>"aHR0cHM6Ly9naXRodWIuY29tL2FobWFkYWhtYWRpYWZnMDg1LXdlYi92b3J0ZXgtdW5pdmVyc2FsLW9yY2hlc3",
        "vercel_api"=>"https://vortex-universal-orchestrator-j5f68u8jk-king-uros-projects.vercel.app/api",
        "google_drive_download"=>"https://drive.google.com/uc?export=download&id=1Kt0qLYaOfrh_pM6i-8WPFqE9P415uP-N",
        "k00_links"=>[
            ["url"=>"https://k00.fr/cv9tsz1p","password"=>"285861"],
            ["url"=>"https://k00.fr/k9ourdsf"]
        ]
    ],
    "triggers"=>["file_update","agent_login","service_call","runtime_error"]
];

function decodeBase64Github($cfg){ return base64_decode($cfg['links']['base64_github']."=="); }

function fetchUrl($url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $resp = curl_exec($ch);
    curl_close($ch);
    return $resp;
}

function fetchAll($urls){
    $results = [];
    foreach($urls as $u) $results[$u] = fetchUrl($u);
    return $results;
}

// Bootstrap
$trigger = "agent_login";
if(!in_array($trigger,$CONFIG['triggers'])) die("Trigger not allowed");
echo "🔒 Environment validated\n⚡ Trigger $trigger recognized\n";

// Agent
$urls = [
    decodeBase64Github($CONFIG),
    $CONFIG['links']['google_drive_download'],
    $CONFIG['links']['vercel_api']
];
foreach($CONFIG['links']['k00_links'] as $k) $urls[] = $k['url'];

$data = fetchAll($urls);
$merged = [];
foreach($data as $k=>$v) $merged[basename($k)]=$v;

echo "🧩 Merged Data:\n";
print_r($merged);
?>