import threading
import time
import datetime

class LogEntry:
    def __init__(self, source, event_type, description):
        self.timestamp = datetime.datetime.now()
        self.source = source
        self.event_type = event_type
        self.description = description

    def __str__(self):
        return f”[{self.timestamp.strftime(‘%Y-%m-%d %H:%M:%S’)}] ({self.source}) [{self.event_type}] {self.description}”


class LogsViewer:
    def __init__(self, max_entries=1000):
        self.logs = []
        self.lock = threading.Lock()
        self.max_entries = max_entries
        print(“[LogsViewer] Initialized”)

    def add_log(self, source, event_type, description):
        with self.lock:
            log_entry = LogEntry(source, event_type, description)
            self.logs.append(log_entry)
            if len(self.logs) > self.max_entries:
                self.logs.pop(0)  # حفظ حداکثر تعداد
            print(str(log_entry))  # نمایش فوری در کنسول

    def get_logs(self, count=50):
        with self.lock:
            return self.logs[-count:]  # آخرین count لاگ

    def monitor_trigger(self, trigger_name, trigger_type):
        self.add_log(source=“TriggerManager”, event_type=trigger_type,
                     description=f”Triggered: {trigger_name}”)

    def monitor_system_event(self, event_name, description):
        self.add_log(source=“System”, event_type=“SystemEvent”, description=f”{event_name}: {description}”)

    def monitor_security_event(self, description):
        self.add_log(source=“Security”, event_type=“Alert”, description=description)

    def run_live_simulation(self):
        “””
        شبیه‌سازی برخی رویدادها برای تست
        “””
        threading.Thread(target=self._simulate_events, daemon=True).start()

    def _simulate_events(self):
        counter = 1
        while True:
            self.monitor_trigger(f”SimTrigger{counter}”, “timer”)
            if counter % 3 == 0:
                self.monitor_system_event(“Offline”, “Connection lost”)
            if counter % 5 == 0:
                self.monitor_security_event(“Unauthorized access attempt”)
            counter += 1
            time.sleep(2)  # هر 2 ثانیه یک event شبیه‌سازی می‌شود


# =========================
# مثال استفاده
# =========================
if __name__ == “__main__”:
    viewer = LogsViewer(max_entries=200)
    viewer.run_live_simulation()

    try:
        while True:
            time.sleep(5)
            logs = viewer.get_logs(10)
            print(“\n— Last 10 logs —“)
            for log in logs:
                print(str(log))
    except KeyboardInterrupt:
        print(“\n[LogsViewer] Terminated by user”)