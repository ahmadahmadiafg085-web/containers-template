# ============================================================
# 🌐 VortexHub Telemetry Core (v1.0-STABLE-ENTERPRISE)
# Author: Dr. S. M. H. Sadat / VortexHub Labs
# Purpose: Secure telemetry relay between local anomaly modules and API Core
# Dependencies: asyncio, aiohttp, anomaly_detector, memory_handler
# ============================================================

import os
import sys
import time
import json
import asyncio
import hashlib
import traceback
import random
import aiohttp
from datetime import datetime
from typing import Dict, Any

# ============================================================
# 🔰 GLOBAL CONFIGURATION
# ============================================================

CONFIG = {
    "tag": "04_vortex_telemetry",
    "version": "v1.0-STABLE-ENTERPRISE",
    "telemetry_endpoint": "https://api.vortexhub.app/telemetry",
    "auth_token": "vx_secure_token",
    "max_retry": 3,
    "cooldown_sec": 15,
    "cache_path": "./runtime/telemetry_cache.json",
    "log_path": "./logs/telemetry_events.json",
    "linked_modules": [
        "./03_anomaly_detector.py",
        "./07_ai_memory_handler.v01.py",
    ],
}

os.makedirs(os.path.dirname(CONFIG["cache_path"]), exist_ok=True)
os.makedirs(os.path.dirname(CONFIG["log_path"]), exist_ok=True)

# ============================================================
# ⚙️ UTILITIES
# ============================================================

def safe_json_load(path: str):
    try:
        if os.path.exists(path) and os.path.getsize(path) > 0:
            with open(path, "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def log_event(event_type: str, details: Dict[str, Any]):
    """Centralized logging for telemetry operations."""
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "type": event_type,
        "details": details
    }
    try:
        data = []
        if os.path.exists(CONFIG["log_path"]):
            with open(CONFIG["log_path"], "r", encoding="utf-8") as f:
                data = json.load(f)
        data.append(entry)
        with open(CONFIG["log_path"], "w", encoding="utf-8") as f:
            json.dump(data[-1000:], f, indent=2)
    except Exception as e:
        print(f"[LOG_ERROR] {e}")

def calc_file_hash(file_path: str) -> str:
    """SHA256 hash utility for verification."""
    try:
        with open(file_path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return "ERR_HASH"

# ============================================================
# 📡 TELEMETRY CORE ENGINE
# ============================================================

async def send_payload(session: aiohttp.ClientSession, payload: Dict[str, Any]):
    """Send payload securely to telemetry API."""
    headers = {
        "Authorization": f"Bearer {CONFIG['auth_token']}",
        "Content-Type": "application/json"
    }
    try:
        async with session.post(CONFIG["telemetry_endpoint"], json=payload, headers=headers) as resp:
            text = await resp.text()
            if resp.status == 200:
                log_event("telemetry_sent", {"status": resp.status, "response": text})
            else:
                log_event("telemetry_error", {"status": resp.status, "response": text})
    except Exception as e:
        log_event("telemetry_exception", {"error": str(e)})

async def send_telemetry_report(data: Dict[str, Any]):
    """Core async sender with retry and fallback."""
    retry = 0
    async with aiohttp.ClientSession() as session:
        while retry < CONFIG["max_retry"]:
            try:
                payload = {
                    "tag": CONFIG["tag"],
                    "version": CONFIG["version"],
                    "timestamp": datetime.utcnow().isoformat(),
                    "system": os.uname().sysname if hasattr(os, "uname") else "UNKNOWN",
                    "data": data
                }
                await send_payload(session, payload)
                return True
            except Exception as e:
                retry += 1
                log_event("retry", {"attempt": retry, "error": str(e)})
                await asyncio.sleep(CONFIG["cooldown_sec"])
    log_event("telemetry_failed", {"data": data})
    return False

# ============================================================
# 🧠 AUTO DATA COLLECTION (Integration Bridge)
# ============================================================

def collect_anomaly_summary() -> Dict[str, Any]:
    """Pull data from anomaly logs for remote sync."""
    anomaly_log = safe_json_load("./logs/anomaly_alerts.json")
    summary = {
        "total_events": len(anomaly_log) if isinstance(anomaly_log, list) else 0,
        "last_event": anomaly_log[-1] if isinstance(anomaly_log, list) and anomaly_log else {},
        "avg_cpu_score": 0.0,
        "avg_latency_score": 0.0
    }

    # Compute average metrics
    if isinstance(anomaly_log, list):
        metrics = [e for e in anomaly_log if e.get("type") == "metrics_collected"]
        if metrics:
            avg_cpu = sum(x["details"]["cpu"] for x in metrics) / len(metrics)
            avg_latency = sum(x["details"]["latency"] for x in metrics) / len(metrics)
            summary["avg_cpu_score"] = round(avg_cpu, 3)
            summary["avg_latency_score"] = round(avg_latency, 3)

    return summary

# ============================================================
# 🔄 TELEMETRY LOOP
# ============================================================

async def telemetry_cycle():
    """Periodic telemetry cycle that runs autonomously."""
    while True:
        try:
            summary = collect_anomaly_summary()
            summary["hash_check"] = calc_file_hash("./03_anomaly_detector.py")
            summary["random_seed"] = random.randint(10000, 99999)
            await send_telemetry_report(summary)
            await asyncio.sleep(CONFIG["cooldown_sec"])
        except Exception as e:
            log_event("telemetry_cycle_error", {"error": str(e)})
            await asyncio.sleep(10)

# ============================================================
# 🛰 EXECUTION ENGINE
# ============================================================

def start_telemetry_loop():
    """Launch telemetry loop asynchronously in safe mode."""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(telemetry_cycle())
    except KeyboardInterrupt:
        print("Telemetry stopped manually.")
    except Exception as e:
        log_event("telemetry_fatal", {"error": str(e)})

# ============================================================
# 🌀 ENTRY POINT
# ============================================================

if __name__ == "__main__":
    print(f"[VortexHub Telemetry] Running {CONFIG['version']}")
    log_event("telemetry_start", {"version": CONFIG["version"]})
    start_telemetry_loop()
    