# financial_intelligence_core_live.py
import json
import statistics
from datetime import datetime
from typing import List, Dict, Any, Optional
import os

# ======================= Transaction Model =======================
class Transaction:
    def __init__(
        self,
        tx_id: str,
        source: str,
        destination: str,
        amount: float,
        currency: str,
        metadata: Dict[str, Any],
        receipt: Optional[Dict[str, Any]] = None
    ):
        self.tx_id = tx_id
        self.source = source
        self.destination = destination
        self.amount = amount
        self.currency = currency
        self.metadata = metadata
        self.receipt = receipt or {}
        self.timestamp = datetime.utcnow()

# ======================= Risk Analyzers =======================
class RiskProfile:
    “””Core risk evaluation per transaction.”””
    @staticmethod
    def amount_risk(amount: float) -> float:
        if amount >= 100000:
            return 0.9
        if amount >= 50000:
            return 0.7
        if amount >= 10000:
            return 0.4
        return 0.1

    @staticmethod
    def velocity_risk(history: List[Transaction], tx: Transaction) -> float:
        amounts = [t.amount for t in history[-10:]]
        if not amounts:
            return 0.0

        avg = statistics.mean(amounts)
        std = statistics.stdev(amounts) if len(amounts) > 1 else 0

        if tx.amount > avg + 3 * (std + 1):
            return 0.8
        return 0.1

    @staticmethod
    def metadata_risk(metadata: Dict[str, Any]) -> float:
        risk = 0.0
        if metadata.get(“channel”) in [“TOR”, “UnknownVPN”]:
            risk += 0.8
        if metadata.get(“client_type”) == “unverified”:
            risk += 0.5
        if metadata.get(“device_change”):
            risk += 0.3
        return min(risk, 1.0)

# ======================= Business Logic Rules =======================
class Rule:
    def __init__(self, name: str, condition: str, action: str):
        self.name = name
        self.condition = condition
        self.action = action

# ======================= Financial Engine =======================
class FinancialScenarioEngine:
    def __init__(self, db_path: str = “transactions.json”):
        self.transactions: List[Transaction] = []
        self.rules: List[Rule] = []
        self.db_path = db_path
        self._load_transactions()

    # -—— Persistent Storage -——
    def _load_transactions(self):
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, “r”, encoding=“utf-8”) as f:
                    data = json.load(f)
                    for t in data:
                        tx = Transaction(
                            tx_id=t[“tx_id”],
                            source=t[“source”],
                            destination=t[“destination”],
                            amount=t[“amount”],
                            currency=t[“currency”],
                            metadata=t.get(“metadata”, {}),
                            receipt=t.get(“receipt”, {})
                        )
                        self.transactions.append(tx)
            except Exception as e:
                print(f”[Warning] Failed to load transactions: {str(e)}”)

    def _save_transactions(self):
        try:
            with open(self.db_path, “w”, encoding=“utf-8”) as f:
                json.dump([self._tx_to_dict(t) for t in self.transactions], f, default=str, indent=2)
        except Exception as e:
            print(f”[Error] Failed to save transactions: {str(e)}”)

    def _tx_to_dict(self, tx: Transaction) -> Dict[str, Any]:
        return {
            “tx_id”: tx.tx_id,
            “source”: tx.source,
            “destination”: tx.destination,
            “amount”: tx.amount,
            “currency”: tx.currency,
            “metadata”: tx.metadata,
            “receipt”: tx.receipt,
            “timestamp”: tx.timestamp.isoformat()
        }

    # -—— Transaction Management -——
    def add_transaction(self, tx: Transaction):
        self.transactions.append(tx)
        self._save_transactions()

    def add_rule(self, rule: Rule):
        self.rules.append(rule)

    # -—— Core Transaction Analysis -——
    def analyze_transaction(self, tx: Transaction) -> Dict[str, Any]:
        # Filter history by same source for velocity check
        history = [t for t in self.transactions if t.source == tx.source]

        risk_amount = RiskProfile.amount_risk(tx.amount)
        risk_velocity = RiskProfile.velocity_risk(history, tx)
        risk_meta = RiskProfile.metadata_risk(tx.metadata)
        total_risk = min(risk_amount + risk_velocity + risk_meta, 1.0)

        # Transaction capability logic
        limit = tx.metadata.get(“limit”, 50000)
        capability = “allowed” if tx.amount <= limit else “blocked”

        return {
            “amount_risk”: risk_amount,
            “velocity_risk”: risk_velocity,
            “metadata_risk”: risk_meta,
            “total_risk”: total_risk,
            “capability”: capability,
            “limit”: limit
        }

    # -—— Rule-based Post Analysis -——
    def evaluate_rules(self, tx: Transaction) -> List[str]:
        actions_taken = []
        for rule in self.rules:
            try:
                if eval(rule.condition, {“tx”: tx}):
                    actions_taken.append(rule.action)
            except Exception as e:
                actions_taken.append(f”Rule error: {rule.name}: {str(e)}”)
        return actions_taken

    # -—— Process Transaction -——
    def process(self, tx: Transaction) -> str:
        analysis = self.analyze_transaction(tx)
        rules = self.evaluate_rules(tx)

        # Update persistent storage after analysis
        self.add_transaction(tx)

        return json.dumps({
            “tx_id”: tx.tx_id,
            “timestamp”: tx.timestamp.isoformat(),
            “source”: tx.source,
            “destination”: tx.destination,
            “amount”: tx.amount,
            “currency”: tx.currency,
            “metadata”: tx.metadata,
            “receipt”: tx.receipt,
            “analysis”: analysis,
            “rules_triggered”: rules
        }, default=str, indent=2)

# ======================= Example =======================
if __name__ == “__main__”:
    engine = FinancialScenarioEngine()

    # Add rules for analysis
    engine.add_rule(Rule(
        name=“Large EUR Transfer”,
        condition=“tx.currency == ‘EUR’ and tx.amount > 20000”,
        action=“Require Supervisor Approval”
    ))
    engine.add_rule(Rule(
        name=“New Device”,
        condition=“’device_change’ in tx.metadata and tx.metadata[‘device_change’]”,
        action=“2FA Challenge”
    ))
    engine.add_rule(Rule(
        name=“High Risk Channel”,
        condition=“tx.metadata.get(‘channel’) in [‘TOR’, ‘UnknownVPN’]”,
        action=“Flag for manual review”
    ))

    # Example transaction
    tx = Transaction(
        tx_id=“TX1001”,
        source=“ClientA”,
        destination=“MerchantB”,
        amount=120000,
        currency=“EUR”,
        metadata={“channel”: “API”, “client_type”: “verified”, “device_change”: True, “limit”: 100000},
        receipt={“reference”: “INV-1001”}
    )

    output = engine.process(tx)
    print(output)