# ================= main_adapters_final.py =================
from typing import Dict, Any, List, Callable
import asyncio, importlib, logging, hashlib, subprocess, json, os, time, tracemalloc, base64, random, resource
from pathlib import Path
from datetime import datetime
from ctypes import cdll

# ================= Logger =================
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter(‘%(asctime)s - %(levelname)s - %(message)s’))
logger.addHandler(ch)
tracemalloc.start()

# ================= DistributedInternalToAdminAdapter =================
class DistributedInternalToAdminAdapter:
    def __init__(self, service, language=“en”, node=“local”):
        self.s = service
        self.lang = language
        self.node = node
        self.cache: Dict[str, Any] = {}
        self.permissions: Dict[str, List[str]] = {}
        self.events: Dict[str, List[Callable]] = {}
        self.trace_enabled = True
        self.policy = {“allow”: set(), “deny”: set(), “rate_limits”: {}, “signatures”: {}}
        self.metrics: Dict[str, List[float]] = {}

    def check_permission(self, role, action) -> bool:
        if role in self.permissions and action in self.permissions[role]: return True
        logger.warning(f”[Permission Denied] {role}:{action}”)
        return False

    def _cget(self, key: str, expire: int = 120):
        v = self.cache.get(key)
        if not v or time.time() - v[“t”] > expire: return None
        return v[“v”]

    def _cset(self, key: str, value: Any):
        self.cache[key] = {“v”: value, “t”: time.time()}

    def _format_user(self, u: dict) -> Dict[str, Any]:
        return {“id”: u.get(“id”), “name”: u.get(“full_name”), “email”: u.get(“email”),
                “role”: u.get(“role”), “status”: u.get(“status”, “active”),
                “last_login”: u.get(“last_login”).isoformat() if u.get(“last_login”) else None}

    def _format_tx(self, t: dict) -> Dict[str, Any]:
        return {“id”: t.get(“id”), “user_id”: t.get(“user_id”), “amount”: float(t.get(“amount”, 0)),
                “status”: t.get(“status”, “pending”),
                “created_at”: t.get(“created_at”).isoformat() if t.get(“created_at”) else None,
                “description”: t.get(“description”, “”)}

    async def get_users(self, force=False):
        c = None if force else self._cget(“users”)
        if not c: c = [self._format_user(x) for x in await asyncio.to_thread(self.s.fetch_all_users)]
        self._cset(“users”, c)
        await self.publish_event(“users_fetched”, {“count”: len(c)})
        return c

    async def get_transactions(self, force=False):
        c = None if force else self._cget(“txs”)
        if not c: c = [self._format_tx(x) for x in await asyncio.to_thread(self.s.fetch_transactions)]
        self._cset(“txs”, c)
        await self.publish_event(“transactions_fetched”, {“count”: len(c)})
        return c

    async def update_user_role(self, user_id: int, role: str, admin_role: str):
        if not self.check_permission(admin_role, “update_user_role”): return False
        try: return await asyncio.to_thread(self.s.set_user_role, user_id, role)
        except Exception as e: logger.error(e); return False

    async def approve_transaction(self, tx_id: int, admin_role: str):
        if not self.check_permission(admin_role, “approve_transaction”): return False
        try: return await asyncio.to_thread(self.s.approve_transaction, tx_id)
        except Exception as e: logger.error(e); return False

    async def get_device_data(self, device_id: str):
        try:
            d = await asyncio.to_thread(self.s.fetch_device_data, device_id)
            await self.publish_event(“device_data_fetched”, {“device_id”: device_id})
            return {“id”: device_id, “status”: d.get(“status”), “last_seen”: d.get(“last_seen”), “metrics”: d.get(“metrics”, {})}
        except Exception as e: logger.error(e); return None

    def encrypt(self, payload: dict) -> str:
        return base64.b64encode(json.dumps(payload).encode()).decode()

    def decrypt(self, payload: str) -> dict:
        return json.loads(base64.b64decode(payload.encode()))

    async def generate_user_report(self):
        users = await self.get_users()
        report = {“total_users”: len(users), “active_users”: sum(1 for u in users if u[“status”] == “active”), “roles”: {}}
        for u in users: report[“roles”][u[“role”]] = report[“roles”].get(u[“role”], 0) + 1
        await self.publish_event(“report_generated”, {“report_type”: “user”})
        return report

    def _log_flow(self, name: str, args, res, start, end, node=None):
        logger.info(f”[FLOW] {name} | node={node or self.node} | dur={(end-start).total_seconds()} | res={str(res)[:150]}”)

    async def publish_event(self, event_type: str, payload: dict):
        for cb in self.events.get(event_type, []):
            if asyncio.iscoroutinefunction(cb): await cb(payload)
            else: await asyncio.to_thread(cb, payload)

    def on_event(self, event_type: str, callback: Callable):
        self.events.setdefault(event_type, []).append(callback)


# ================= LoaderToAdminAdapter =================
class LoaderToAdminAdapter:
    def __init__(self, base: str, admin: DistributedInternalToAdminAdapter, node_id=None):
        self.base = Path(base)
        self.admin = admin
        self.lazy: Dict[str, Any] = {}
        self.reg: Dict[str, dict] = {}
        self.hooks: Dict[str, dict] = {}
        self.metrics: Dict[str, List[float]] = {}
        self.cache: Dict[str, dict] = {}
        self.cache_exp = 120
        self.policy = {“allow”: set(), “deny”: set(), “rate_limits”: {}, “signatures”: {}}
        self.trace_enabled = True
        self.tc: Dict[str, dict] = {}
        self.lock = asyncio.Lock()
        self.node = node_id or os.getenv(“NODE_ID”, “local”)
        tracemalloc.start()
        self._register_modules()
        self._assign_priorities()
        self._build_dependency_graph()

    def _hash_file(self, p: Path) -> str:
        try:
            h = hashlib.sha256()
            with p.open(“rb”) as f:
                for c in iter(lambda: f.read(4096), b””): h.update(c)
            return h.hexdigest()
        except: return “0”*64

    def _register_modules(self):
        for p in (self.base / “loader_modules”).glob(“**/*”):
            if p.suffix in [“.py”, “.js”, “.ts”, “.wasm”, “.so”, “.dll”, “.whl”]:
                n = “.”.join(p.relative_to(self.base).with_suffix(“”).parts)
                self.lazy[n] = None
                self.reg[n] = {“path”: p, “type”: p.suffix, “loaded”: False, “checksum”: self._hash_file(p),
                               “dependencies”: [], “priority”: 0, “version”: None, “healthy”: True}
                self.hooks[n] = {“pre”: [], “post”: []}

    def _assign_priorities(self):
        for m in self.reg.values():
            m[“priority”] = 10 if m[“type”] == “.py” else 6 if m[“type”] in [“.js”, “.ts”] else 4 if m[“type”] == “.wasm” else 2

    def _build_dependency_graph(self):
        for m in self.reg.values():
            m[“dependencies”] = m.get(“dependencies”, [])

    def _sandbox(self, fn, *a, **k):
        try:
            resource.setrlimit(resource.RLIMIT_CPU, (2,2))
            resource.setrlimit(resource.RLIMIT_AS, (512*1024*1024, 512*1024*1024))
            return fn(*a, **k)
        except Exception as e:
            return {“sandbox_error”: str(e)}

    def _policy_check(self, module, func):
        if module in self.policy[“deny”]: raise PermissionError(“denied”)
        if self.policy[“allow”] and module not in self.policy[“allow”]: raise PermissionError(“blocked”)
        rl = self.policy[“rate_limits”].get(module)
        if rl: rl[“count”] += 1; 
        if rl and rl[“count”] > rl.get(“max”, 0): raise RuntimeError(“rate_limit_exceeded”)

    def _signature_check(self, module):
        sig = self.policy[“signatures”].get(module)
        if sig and self.reg[module][“checksum”] != sig: raise ValueError(“tampered”)

    def _trace_start(self, module, func):
        if not self.trace_enabled: return None
        tid = f”{time.time()}-{random.randint(1000,9999)}”
        self.tc[tid] = {“module”: module, “func”: func, “start”: datetime.utcnow().isoformat()}
        return tid

    def _trace_end(self, tid, res):
        if tid in self.tc: self.tc[tid].update({“end”: datetime.utcnow().isoformat(), “res”: str(res)[:200]})

    def _cache_get(self, key):
        v = self.cache.get(key)
        if not v or time.time() - v[“t”] > self.cache_exp: return None
        return v[“v”]

    def _cache_set(self, key, val):
        self.cache[key] = {“v”: val, “t”: time.time()}

    def load_module(self, name: str, force=False):
        if name not in self.lazy: raise ValueError(f”Module {name} not registered”)
        m = self.reg[name]; ext = m[“type”]
        if self.lazy[name] is None or force:
            try:
                for h in self.hooks[name][“pre”]: h(name)
                for d in m.get(“dependencies”, []): self.load_module(d, force)
                if ext == “.py”: self.lazy[name] = importlib.import_module(name) if not force else importlib.reload(self.lazy[name])
                elif ext in [“.so”, “.dll”]: self.lazy[name] = cdll.LoadLibrary(str(m[“path”]))
                elif ext in [“.js”, “.ts”]: subprocess.run([“node”, str(m[“path”])], check=True)
                m.update({“loaded”: True, “version”: datetime.utcnow().isoformat()})
                self.reg[name][“last_code”] = m[“path”].read_text()
                for h in self.hooks[name][“post”]: h(name)
            except Exception as e: m[“healthy”] = False; logger.error(e)
        return self.lazy[name]

    async def run(self, module, func, *a, timeout=None, retries=0, cache=False, sandbox=True, **k):
        async with self.lock:
            self._policy_check(module, func)
            self._signature_check(module)
            key = f”{module}:{func}:{a}:{k}”
            cv = self._cache_get(key) if cache else None
            if cv is not None: return cv
            mod = self.load_module(module)
            fn = getattr(mod, func, None)
            if not callable(fn): return None
            start, att, res = datetime.utcnow(), 0, None
            runner = self._sandbox if sandbox else lambda f, *x, **y: f(*x, **y)
            tid = self._trace_start(module, func)
            while att <= retries:
                try:
                    res = await asyncio.wait_for(fn(*a, **k), timeout=timeout) if asyncio.iscoroutinefunction(fn) else runner(fn, *a, **k)
                    break
                except Exception as e:
                    att += 1
                    logger.error(e)
                    if att > retries: raise
                finally:
                    self.metrics.setdefault(f”{module}.{func}”, []).append((datetime.utcnow()-start).total_seconds())
                    self.admin._log_flow(f”loader_{module}_{func}”, {“args”:a, “kwargs”:k}, res, start, datetime.utcnow(), node=self.node)
            if cache: self._cache_set(key, res)
            self._trace_end(tid, res)
            return res

    async def batch(self, evs: List[Dict[str, Any]]):
        return await asyncio.gather(*[self.run(e[“module”], e[“func”], *e.get(“args”, []), **e.get(“kwargs”, {})) for e in evs], return_exceptions=True)


# ================= AdapterOrchestratorToAdmin =================
class AdapterOrchestratorToAdmin:
    def __init__(self, adapters: List[Any]):
        self.adapters = adapters
        self.events: Dict[str, List[Callable]] = {}
        self.metrics: Dict[str, List[float]] = {}
        self.lock = asyncio.Lock()

    async def publish_event(self, event_type: str, payload: dict):
        for a in self.adapters:
            if hasattr(a, “publish_event”): await a.publish_event(event_type, payload)
        for cb in self.events.get(event_type, []):
            if asyncio.iscoroutinefunction(cb): await cb(payload)
            else: await asyncio.to_thread(cb, payload)

    def on_event(self, event_type: str, callback: Callable):
        self.events.setdefault(event_type, []).append(callback)

    async def _run_with_trace(self, adapter, func_name, fn, *args, timeout=None, retries=0, cache=False, sandbox=True, **kwargs):
        start, att, res = datetime.utcnow(), 0, None
        while att <= retries:
            try: res = await asyncio.wait_for(fn(*args, **kwargs), timeout=timeout) if asyncio.iscoroutinefunction(fn) else fn(*args, **kwargs); break
            except Exception as e: att += 1; logger.error(f”[Orchestrator] Adapter {getattr(adapter,’node’,None)} Func {func_name} Error: {e}”); raise if att>retries else None
            finally: duration = (datetime.utcnow()-start).total_seconds(); self.metrics.setdefault(f”{getattr(adapter,’node’,None)}.{func_name}”, []).append(duration); logger.info(f”[Orchestrator TRACE] Adapter={getattr(adapter,’node’,None)} Func={func_name} Duration={duration} Res={str(res)[:150]}”)
        return res

    async def run_on_all_adapters(self, func_name: str, *args, timeout=None, retries=0, cache=False, sandbox=True, **kwargs):
        async with self.lock:
            tasks = [self._run_with_trace(a, func_name, getattr(a, func_name), *args, timeout=timeout, retries=retries, cache=cache, sandbox=sandbox, **kwargs) for a in self.adapters if callable(getattr(a, func_name, None))]
            results_list = await asyncio.gather(*tasks, return_exceptions=True)
            return {getattr(a, “node”, f”adapter_{i}”): results_list[i] for i, a in enumerate(self.adapters)}

    async def batch(self, calls: List[Dict[str, Any]]):
        return await asyncio.gather(*[self._run_with_trace(c[“adapter”], c[“func”], getattr(c[“adapter”], c[“func”]), *c.get(“args”, []), **c.get(“kwargs”, {})) for c in calls], return_exceptions=True)


# ================= GLOBAL SINGLETON =================
# internal_service should be injected here
internal = DistributedInternalToAdminAdapter(service=None)
loader = LoaderToAdminAdapter(base=“./“, admin=internal)
orchestrator = AdapterOrchestratorToAdmin([internal, loader])
