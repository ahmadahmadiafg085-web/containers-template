# actuator_health_monitor.py
import asyncio, aiohttp, logging, time, random
from typing import Dict, List

logging.basicConfig(level=logging.INFO, format=‘[%(levelname)s] %(asctime)s - %(message)s’)

def timestamp(): return time.strftime(“%Y-%m-%d %H:%M:%S”)

# ======= Actuator Health Monitor =======
class ActuatorHealthMonitor:
    “””
    Lightweight actuator health monitor.
    Async, event-driven, browser-friendly (no backend server needed).
    “””
    def __init__(self, actuators: Dict[str, Dict], check_interval: float = 5.0):
        self.actuators = actuators          # { “actuator_name”: { “url”: ..., “status”: ... } }
        self.check_interval = check_interval
        self.fail_score: Dict[str, int] = {}   # Count of consecutive failures

    async def _check_actuator(self, name: str, url: str):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=5) as resp:
                    if resp.status == 200:
                        self.actuators[name][“status”] = “healthy”
                        self.fail_score[name] = 0
                        logging.info(f”[HEALTH] {name} is healthy at {timestamp()}”)
                    else:
                        raise Exception(f”Status code {resp.status}”)
        except Exception as e:
            self.fail_score[name] = self.fail_score.get(name, 0) + 1
            self.actuators[name][“status”] = “unhealthy”
            logging.warning(f”[HEALTH] {name} unhealthy at {timestamp()} | Failures: {self.fail_score[name]} | {e}”)

    async def monitor_loop(self):
        while True:
            tasks = []
            for name, info in self.actuators.items():
                url = info.get(“url”)
                if url:
                    tasks.append(self._check_actuator(name, url))
            if tasks:
                await asyncio.gather(*tasks)
            await asyncio.sleep(self.check_interval)

    def add_actuator(self, name: str, url: str):
        self.actuators[name] = {“url”: url, “status”: “unknown”}
        logging.info(f”[MONITOR] Added actuator {name} with URL {url}”)

# ======= Example Usage =======
async def main():
    # Example actuators
    actuators = {
        “pump_1”: {“url”: “http://localhost:8000/actuator/pump_1”, “status”: “unknown”},
        “valve_1”: {“url”: “http://localhost:8000/actuator/valve_1”, “status”: “unknown”}
    }

    monitor = ActuatorHealthMonitor(actuators, check_interval=5)
    asyncio.create_task(monitor.monitor_loop())

    # Example: dynamically add actuator
    await asyncio.sleep(10)
    monitor.add_actuator(“cooling_fan”, “http://localhost:8000/actuator/fan”)

    try:
        while True:
            await asyncio.sleep(3600)
    except KeyboardInterrupt:
        logging.info(“[MONITOR] Stopped.”)

if __name__ == “__main__”:
    asyncio.run(main())
    