// ===========================================================
//   adapter_rust_to_py-2.rs
//   VORTEXHUB RUST ↔ PYTHON ADAPTER (RUNTIME & ANALYZER)
//   Multi‑Protocol / Dynamic Ports / WS / HTTP / Agent Pools
//   Designed for Real-Time AI, WASM-Python, Pyodide Bridge
// ===========================================================

use std::sync::{Arc, Mutex};
use std::collections::HashMap;
use std::net::{TcpListener, TcpStream};
use std::io::{Read, Write};

use rand::{thread_rng, Rng};
use rand::distributions::Alphanumeric;

use pyo3::prelude::*;
use pyo3::types::PyDict;

// WebSocket
use tungstenite::server::accept;

// Async runtime
use tokio::task;
use tokio::sync::mpsc;

// HTTP server
use tiny_http::{Server, Response};

// JSON / Serialization
use serde::{Serialize, Deserialize};
use serde_json::json;

// ===========================================================
//   PYTHOID-LIKE SERIALIZER FOR PYTHON BRIDGE
// ===========================================================

#[derive(Serialize, Deserialize, Clone)]
pub struct PythoidPacket {
    pub ty: String,
    pub content: serde_json::Value,
    pub sha256: String,
    pub timestamp: u64
}

impl PythoidPacket {
    pub fn new(ty:&str, content:serde_json::Value) -> Self {
        let data = content.to_string();
        let sha256 = format!("{:x}", sha2::Sha256::digest(data.as_bytes()));

        Self {
            ty: ty.to_string(),
            content,
            sha256,
            timestamp: chrono::Utc::now().timestamp_millis() as u64
        }
    }
}

// ===========================================================
//   GLOBAL STRUCTS
// ===========================================================

#[derive(Clone)]
pub struct Agent {
    pub id: String,
    pub channel: mpsc::Sender<String>,
}

#[derive(Clone)]
pub struct AdapterRuntime {
    pub agents: Arc<Mutex<HashMap<String, Agent>>>,
    pub protocol_cache: Arc<Mutex<HashMap<String,String>>>,
}

impl AdapterRuntime {
    pub fn new() -> Self {
        Self {
            agents: Arc::new(Mutex::new(HashMap::new())),
            protocol_cache: Arc::new(Mutex::new(HashMap::new()))
        }
    }
}

// ===========================================================
//   UTILS
// ===========================================================

fn random_id() -> String {
    thread_rng().sample_iter(&Alphanumeric).take(16).map(char::from).collect()
}

fn dynamic_port() -> u16 {
    let port: u16 = thread_rng().gen_range(30000..45000);
    port
}

// ===========================================================
//   PYTHON EXECUTOR
// ===========================================================

fn execute_python(
    pycode:String, 
    args:serde_json::Value
) -> PyResult<serde_json::Value> {

    Python::with_gil(|py| {
        let dict = PyDict::new(py);
        dict.set_item("args", args.to_string())?;

        let ret = py.run(&pycode, None, Some(dict));
        match ret {
            Ok(_) => Ok(json!({"status":"ok"})),
            Err(e) => Ok(json!({"status":"error", "detail": format!("{:?}",e)}))
        }
    })
}

// ===========================================================
//   AUTO‑PROTOCOL DETECTOR
// ===========================================================

fn detect_protocol(data:&[u8]) -> String {
    let txt = String::from_utf8_lossy(data);

    if txt.starts_with("GET ") { return "HTTP".into(); }
    if txt.contains("upgrade: websocket") { return "WEBSOCKET".into(); }
    if txt.starts_with("{") && txt.ends_with("}") { return "JSON".into(); }
    if data.starts_with(&[0, 97, 115, 109]) { return "WASM".into(); }

    "BINARY".into()
}

// ===========================================================
//   TCP WORKER (PORT ROTATOR)
// ===========================================================

fn spawn_worker(rt:AdapterRuntime, port:u16) {
    std::thread::spawn(move || {
        let listener = TcpListener::bind(("0.0.0.0", port))
            .expect("could not bind worker port");

        loop {
            if let Ok((mut stream, _)) = listener.accept() {
                let rt_cl = rt.clone();

                std::thread::spawn(move || {
                    let mut buf = vec![0u8; 4096];
                    if let Ok(n) = stream.read(&mut buf) {
                        let proto = detect_protocol(&buf[..n]);

                        {
                            let mut p = rt_cl.protocol_cache.lock().unwrap();
                            p.insert(random_id(), proto.clone());
                        }

                        // ROUTE PAYLOAD BASED ON PROTOCOL
                        match proto.as_str() {
                            "JSON" => {
                                let data = String::from_utf8_lossy(&buf[..n]).to_string();
                                let _ = stream.write(b"JSON RECEIVED");
                                forward_to_agents(rt_cl.clone(), data);
                            },
                            "HTTP" => {
                                let _ = stream.write(b"HTTP/1.1 200 OK\r\n\r\nVortexHub Rust Adapter");
                            },
                            "WEBSOCKET" => {
                                let _ = stream.write(b"WebSocket accepted");
                            },
                            "WASM" => {
                                let _ = stream.write(b"WASM Module Accepted");
                            }
                            _ => {
                                let _ = stream.write(b"BINARY RECEIVED");
                            }
                        }
                    }
                });
            }
        }
    });
}

// ===========================================================
//   AGENT POOL DISPATCH
// ===========================================================

fn forward_to_agents(rt:AdapterRuntime, data:String) {
    let agents = rt.agents.lock().unwrap();
    for (_, ag) in agents.iter() {
        let _ = ag.channel.try_send(data.clone());
    }
}

fn spawn_agent(rt:AdapterRuntime) {
    let id = random_id();
    let (tx, mut rx) = mpsc::channel::<String>(32);

    {
        let mut agents = rt.agents.lock().unwrap();
        agents.insert(id.clone(), Agent { id:id.clone(), channel:tx });
    }

    tokio::spawn(async move {
        while let Some(msg) = rx.recv().await {
            println!("[AGENT {} RECEIVED] {}", id, msg);
        }
    });
}

// ===========================================================
//   DYNAMIC HTTP + WEBSOCKET SERVER
// ===========================================================

fn spawn_http_server(rt:AdapterRuntime) {
    let port = dynamic_port();
    let server = Server::http(format!("0.0.0.0:{}", port)).unwrap();

    println!("[HTTP] Live server running on port {}", port);

    std::thread::spawn(move || {
        for rq in server.incoming_requests() {
            let resp = Response::from_string("VortexHub Rust Runtime OK");
            let _ = rq.respond(resp);
        }
    });
}

// ===========================================================
//   MAIN ADAPTER FACADE
// ===========================================================

pub fn start_runtime() {
    println!("=== VORTEXHUB RUST → PYTHON MULTI-RUNTIME ADAPTER ===");

    let rt = AdapterRuntime::new();

    // Spawn multiple workers for load balancing
    for _ in 0..5 {
        let p = dynamic_port();
        println!("[WORKER] Listening on dynamic port {}", p);
        spawn_worker(rt.clone(), p);
    }

    // Agents / Workers
    for _ in 0..4 {
        spawn_agent(rt.clone());
    }

    // HTTP / Web server
    spawn_http_server(rt.clone());

    println!("[SYSTEM] Adapter runtime fully initialized.");
}
