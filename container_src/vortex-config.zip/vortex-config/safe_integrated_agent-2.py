# auto_detect_agent.py
import os,time,threading,logging,psutil,json,random,subprocess
from pathlib import Path
from typing import Dict,Any,Callable,Optional
import importlib.util,traceback
try: import GPUtil
except: GPUtil=None

logging.basicConfig(level=logging.INFO,format=‘[%(levelname)s] %(asctime)s - %(message)s’)
CTX={“history”:[],”errors”:[],”loaded_modules”:{},”score”:0.0,”actions”:[],”weights”:{},”count”:0}

def alert_admin(msg:str): logging.warning(f”ALERT: {msg}”); CTX[“errors”].append({“msg”:msg,”time”:time.time()})
def safe_exec(func:Callable,ctx:Optional[Dict]=None,name:str=“unknown”): 
    try: return func(ctx or {})
    except Exception as e: alert_admin(f”[{name}] Execution error: {e}”); return None
def score(trigger:str,val:bool): CTX[“score”]+=CTX[“weights”].get(trigger,1.0)*(1 if val else 0); CTX[“history”].append((trigger,val,time.time()))
def combo(status:Dict[str,bool]): s=sum(1 for v in status.values() if v); return “ultra_combo” if s>=4 else “triple_combo” if s==3 else “double_combo” if s==2 else None

# —————— Auto-detect Triggers ——————
def auto_detect_triggers()->Dict[str,Callable]:
    triggers={}
    # CPU
    triggers[“cpu_spike”]=lambda ctx=None: psutil.cpu_percent(interval=0.5)>85
    # RAM
    triggers[“ram_pressure”]=lambda ctx=None: psutil.virtual_memory().percent>80
    # GPU
    triggers[“gpu_usage”]=lambda ctx=None: max([g.load*100 for g in GPUtil.getGPUs()])>70 if GPUtil else random.randint(0,100)>70
    # Battery
    triggers[“battery_low”]=lambda ctx=None: (psutil.sensors_battery().percent<15 if psutil.sensors_battery() else False)
    # Network
    triggers[“network_down”]=lambda ctx=None: not any(n.isup for n in psutil.net_if_stats().values())
    # Process
    triggers[“process_start”]=lambda ctx=None: any(p.name()==“python” for p in psutil.process_iter())
    # Temperature Sensor
    triggers[“temp_high”]=lambda ctx=None: max([t.current for t in psutil.sensors_temperatures().get(‘coretemp’,[25])])>70 if hasattr(psutil,’sensors_temperatures’) else False
    # USB Connect
    triggers[“usb_connect”]=lambda ctx=None: True
    # File & Macro Checks
    triggers[“file_stego”]=lambda ctx=None: Path(“secret.txt”).exists()
    triggers[“vba_macro”]=lambda ctx=None: Path(“macro.xlsm”).exists()
    return triggers

TRIGGERS=auto_detect_triggers()

# —————— Actions ——————
def perform_action(a:Dict,ctx:Optional[Dict]=None):
    t=a.get(“type”)
    if t==“notify_admin”: alert_admin(a.get(“message”,”No message”))
    elif t==“adjust_weight”: CTX[“weights”][a.get(“trigger”)]=a.get(“weight”,1.0)
    elif t==“ai_reinforce”: CTX[“score”]+=5
    elif t==“restart_service”: subprocess.run([“systemctl”,”restart”,a.get(“service”)],check=False)
    elif t==“snapshot”: json.dump(CTX,open(“ctx_snapshot.json”,”w”))
    else: logging.info(f”Unknown action: {t}”)

# —————— Evaluate ——————
def evaluate_triggers(triggers:Dict[str,Callable],ctx:Optional[Dict]=None):
    ctx=ctx or {}; status={}
    for k,f in triggers.items():
        res=safe_exec(lambda c: f(),ctx,k)
        status[k]=bool(res)
        CTX[“history”].append((k,bool(res),time.time()))
        CTX[“score”]+=CTX[“weights”].get(k,1.0)*(1 if res else 0)
    cmb=combo(status); cmb and status.update({f”combo:{cmb}”:True})
    return status

# —————— Agents ——————
class MicroAgent:
    def __init__(self,cfg:Optional[Dict]=None): self.cfg=cfg or {}; self.status={}; self.wake=“sleep”; self.last=time.time()
    def update_wake(self):
        now=time.time(); active=any(self.status.values())
        if active:self.last=now; self.wake=“full_wake” if sum(bool(v) for v in self.status.values())>=2 else “semi_wake”
        elif now-self.last>5:self.wake=“sleep”
    def listen(self): self.status=evaluate_triggers(TRIGGERS); self.update_wake(); return self.status

class MacroAgent:
    def __init__(self,cfg:Optional[Dict]=None): self.cfg=cfg or {}; 
    def evaluate(self,status:Dict[str,bool],wake:str):
        if wake==“sleep”: return
        for a in self.cfg.get(“actions”,[]):
            sh=False; cond=a.get(“condition”,”all”)
            if cond==“all” and all(status.values()): sh=True
            elif cond==“any” and any(status.values()): sh=True
            elif cond==“combo” and any(k.startswith(“combo:”) for k in status): sh=True
            elif cond==“custom”: 
                try: sh=eval(a.get(“expr”,”False”),{},status)
                except: sh=False
            if sh: self.exec(a)
    def exec(self,a): t=a.get(“type”); CTX[“actions”].append(t); CTX[“count”]=CTX.get(“count”,0)+1; safe_exec(lambda c: perform_action(a,ctx=c),CTX); logging.info(f”Macro action executed: {t}”)

# —————— Main Loop ——————
def main_loop(cfg:Optional[Dict]=None):
    micro=MicroAgent(cfg); macro=MacroAgent(cfg)
    while True:
        st=micro.listen()
        if micro.wake!=“sleep”:
            logging.info({“status”:st,”wake”:micro.wake,”score”:CTX[“score”],”history”:CTX[“history”][-10:]})
            macro.evaluate(st,micro.wake)
        time.sleep(0.5 if micro.wake!=“sleep” else 2)

if __name__==“__main__”:
    threading.Thread(target=main_loop,daemon=True).start()