// loggingMiddleware.js

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const DEFAULT_LEVELS = ['debug', 'info', 'warn', 'error', 'fatal'];

const LEVEL_PRIORITY = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
  fatal: 50
};

function ensureDirSync(dirPath) {
  if (!dirPath) return;
  if (fs.existsSync(dirPath)) return;
  fs.mkdirSync(dirPath, { recursive: true });
}

function safeStringify(value) {
  try {
    return JSON.stringify(value);
  } catch (e) {
    return '"[unserializable]"';
  }
}

function formatDate(date) {
  const pad = n => (n < 10 ? '0' + n : '' + n);
  const year = date.getFullYear();
  const month = pad(date.getMonth() + 1);
  const day = pad(date.getDate());
  const h = pad(date.getHours());
  const m = pad(date.getMinutes());
  const s = pad(date.getSeconds());
  const ms = date.getMilliseconds().toString().padStart(3, '0');
  return `${year}-${month}-${day}T${h}:${m}:${s}.${ms}Z`;
}

function buildBaseLog(options) {
  const hostname = os.hostname();
  const service = options.serviceName || 'node-service';
  const env = options.env || process.env.NODE_ENV || 'development';
  return { hostname, service, env };
}

function resolveLogFile(options, date) {
  if (!options.logDir) return null;
  ensureDirSync(options.logDir);
  if (options.logPerDay) {
    const pad = n => (n < 10 ? '0' + n : '' + n);
    const year = date.getFullYear();
    const month = pad(date.getMonth() + 1);
    const day = pad(date.getDate());
    const filename = `${options.filePrefix || 'access'}-${year}-${month}-${day}.log`;
    return path.join(options.logDir, filename);
  }
  return path.join(options.logDir, options.fileName || 'access.log');
}

function writeToFile(filePath, line) {
  if (!filePath) return;
  try {
    fs.appendFile(filePath, line + os.EOL, () => {});
  } catch (_) {}
}

function createLevelLogger(options) {
  const minLevel = options.logLevel || 'debug';
  const minPriority = LEVEL_PRIORITY[minLevel] || LEVEL_PRIORITY.debug;
  const base = buildBaseLog(options);

  function log(level, payload) {
    const priority = LEVEL_PRIORITY[level] || LEVEL_PRIORITY.info;
    if (priority < minPriority) return;
    const now = new Date();
    const record = Object.assign({}, base, payload, {
      level,
      timestamp: formatDate(now)
    });
    const line = safeStringify(record);
    if (options.console !== false) {
      if (priority >= LEVEL_PRIORITY.error) {
        console.error(line);
      } else {
        console.log(line);
      }
    }
    const filePath = resolveLogFile(options, now);
    if (options.file !== false && filePath) {
      writeToFile(filePath, line);
    }
  }

  return {
    debug: payload => log('debug', payload),
    info: payload => log('info', payload),
    warn: payload => log('warn', payload),
    error: payload => log('error', payload),
    fatal: payload => log('fatal', payload)
  };
}

function redactHeaders(headers, keys) {
  if (!headers) return {};
  if (!Array.isArray(keys) || !keys.length) return headers;
  const clone = {};
  Object.keys(headers).forEach(k => {
    if (keys.includes(k.toLowerCase())) {
      clone[k] = '[redacted]';
    } else {
      clone[k] = headers[k];
    }
  });
  return clone;
}

function cloneSafeBody(body, maxLength) {
  if (!body) return undefined;
  let data = body;
  if (Buffer.isBuffer(body)) {
    data = body.toString('utf8');
  }
  if (typeof data === 'string') {
    if (maxLength && data.length > maxLength) {
      return data.slice(0, maxLength) + '...[truncated]';
    }
    return data;
  }
  const stringified = safeStringify(body);
  if (maxLength && stringified.length > maxLength) {
    return stringified.slice(0, maxLength) + '...[truncated]';
  }
  return stringified;
}

function generateRequestId(req, headerName) {
  const incoming = req.headers[headerName.toLowerCase()];
  if (incoming && typeof incoming === 'string') return incoming;
  return crypto.randomBytes(12).toString('hex');
}

function attachRequestId(req, res, headerName, value) {
  const name = headerName;
  req.requestId = value;
  res.setHeader(name, value);
}

function createLoggingMiddleware(rawOptions = {}) {
  const options = Object.assign(
    {
      logLevel: 'debug',
      logDir: path.join(process.cwd(), 'logs'),
      logPerDay: true,
      file: true,
      console: true,
      filePrefix: 'access',
      env: process.env.NODE_ENV || 'development',
      serviceName: 'node-service',
      requestIdHeader: 'x-request-id',
      redactHeaders: ['authorization', 'cookie'],
      maxBodyLength: 2048,
      logRequestBody: true,
      logResponseBody: true,
      logOnErrorLevel: 'error',
      sampleRate: 1.0,
      skipPaths: [],
      skipMethods: [],
      trackUserAgent: true,
      trackIp: true
    },
    rawOptions || {}
  );

  const logger = createLevelLogger(options);

  function shouldSkip(req) {
    if (options.sampleRate >= 0 && options.sampleRate < 1) {
      if (Math.random() > options.sampleRate) return true;
    }
    if (Array.isArray(options.skipMethods) && options.skipMethods.length) {
      if (options.skipMethods.includes(req.method)) return true;
    }
    if (Array.isArray(options.skipPaths) && options.skipPaths.length) {
      const url = req.originalUrl || req.url || '';
      for (const pattern of options.skipPaths) {
        if (!pattern) continue;
        if (pattern instanceof RegExp && pattern.test(url)) return true;
        if (typeof pattern === 'string' && url.startsWith(pattern)) return true;
      }
    }
    return false;
  }

  function captureRequestBody(req, done) {
    if (!options.logRequestBody) {
      return done();
    }
    if (req.readableEnded || req.body) {
      req._rawBody = cloneSafeBody(req.body, options.maxBodyLength);
      return done();
    }
    const chunks = [];
    let length = 0;
    req.on('data', chunk => {
      chunks.push(chunk);
      length += chunk.length;
      if (options.maxBodyLength && length > options.maxBodyLength * 2) {
        req.pause();
      }
    });
    req.on('end', () => {
      const buf = Buffer.concat(chunks, length);
      req._rawBody = cloneSafeBody(buf, options.maxBodyLength);
      done();
    });
    req.on('error', () => {
      done();
    });
  }

  function wrapResponse(res, ctx) {
    const originalWrite = res.write;
    const originalEnd = res.end;
    const chunks = [];
    let length = 0;

    res.write = function (chunk, encoding, cb) {
      try {
        if (options.logResponseBody && chunk) {
          const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk, encoding || 'utf8');
          chunks.push(buf);
          length += buf.length;
        }
      } catch (_) {}
      return originalWrite.call(this, chunk, encoding, cb);
    };

    res.end = function (chunk, encoding, cb) {
      try {
        if (options.logResponseBody && chunk) {
          const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk, encoding || 'utf8');
          chunks.push(buf);
          length += buf.length;
        }
      } catch (_) {}
      originalEnd.call(this, chunk, encoding, cb);
    };

    res.on('finish', () => {
      const statusCode = res.statusCode;
      let responseBody;
      if (options.logResponseBody && chunks.length) {
        const bodyBuffer = Buffer.concat(chunks, length);
        responseBody = cloneSafeBody(bodyBuffer, options.maxBodyLength);
      }
      const elapsedMs = Date.now() - ctx.startAt;
      const level = statusCode >= 500 ? 'error' : statusCode >= 400 ? 'warn' : 'info';
      const headers = redactHeaders(res.getHeaders(), options.redactHeaders);
      const payload = {
        type: 'http-access',
        requestId: ctx.requestId,
        method: ctx.method,
        path: ctx.path,
        route: ctx.route || undefined,
        query: ctx.query,
        statusCode,
        elapsedMs,
        requestHeaders: ctx.requestHeaders,
        responseHeaders: headers
      };
      if (options.logRequestBody) {
        payload.requestBody = ctx.body;
      }
      if (options.logResponseBody) {
        payload.responseBody = responseBody;
      }
      if (options.trackUserAgent && ctx.userAgent) {
        payload.userAgent = ctx.userAgent;
      }
      if (options.trackIp && ctx.ip) {
        payload.ip = ctx.ip;
      }
      logger[level](payload);
    });

    res.on('close', () => {
      if (res.writableFinished) return;
      const elapsedMs = Date.now() - ctx.startAt;
      const payload = {
        type: 'http-abort',
        requestId: ctx.requestId,
        method: ctx.method,
        path: ctx.path,
        statusCode: res.statusCode,
        elapsedMs
      };
      logger[options.logOnErrorLevel || 'error'](payload);
    });
  }

  function middleware(req, res, next) {
    if (shouldSkip(req)) return next();
    const startAt = Date.now();
    const pathValue = req.originalUrl || req.url || '';
    const requestId = generateRequestId(req, options.requestIdHeader);
    attachRequestId(req, res, options.requestIdHeader, requestId);
    const ctx = {
      requestId,
      startAt,
      method: req.method,
      path: pathValue,
      route: req.route && req.route.path ? req.route.path : undefined,
      query: req.query || {},
      userAgent: req.headers['user-agent'],
      ip:
        req.ip ||
        (req.connection && req.connection.remoteAddress) ||
        (req.socket && req.socket.remoteAddress) ||
        undefined,
      requestHeaders: redactHeaders(req.headers, options.redactHeaders),
      body: undefined
    };

    const handleError = err => {
      const elapsedMs = Date.now() - startAt;
      const payload = {
        type: 'http-error',
        requestId,
        method: ctx.method,
        path: ctx.path,
        message: err && err.message ? err.message : String(err),
        stack: err && err.stack ? err.stack : undefined,
        elapsedMs
      };
      logger[options.logOnErrorLevel || 'error'](payload);
    };

    let settled = false;
    const safeNext = err => {
      if (settled) return;
      settled = true;
      if (err) handleError(err);
      next(err);
    };

    try {
      captureRequestBody(req, () => {
        ctx.body = req._rawBody;
        wrapResponse(res, ctx);
        logger.info({
          type: 'http-start',
          requestId,
          method: ctx.method,
          path: ctx.path,
          route: ctx.route,
          query: ctx.query,
          ip: ctx.ip,
          userAgent: ctx.userAgent
        });
        safeNext();
      });
    } catch (err) {
      handleError(err);
      safeNext(err);
    }
  }

  middleware.logger = logger;
  middleware.levels = DEFAULT_LEVELS.slice();
  middleware.options = options;

  return middleware;
}

module.exports = createLoggingMiddleware;

