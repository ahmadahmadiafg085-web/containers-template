# lidar.py
import os
import json
import time
import math
import heapq
import struct
import numpy as np
from threading import Thread, Lock
from queue import Queue

# -——— تنظیمات و کانفیگ -———
DEFAULT_CONFIG = {
    “data_dir”: “./lidar_data”,
    “save_dir”: “./processed”,
    “max_queue_size”: 100,
    “voxel_size”: 0.1,        # ابعاد voxel برای downsampling
    “intensity_threshold”: 0, # حداقل شدت بازتاب
    “process_workers”: 4,
    “file_pattern”: “*.bin”,  # فایل‌های خام لیدار
    “log_level”: “info”
}

LEVELS = [“debug”, “info”, “warn”, “error”, “fatal”]

# -——— لاگر ساده داخلی -———
def log(msg, level=“info”):
    if LEVELS.index(level) >= LEVELS.index(DEFAULT_CONFIG[“log_level”]):
        print(f”[{level.upper()}] {time.strftime(‘%Y-%m-%d %H:%M:%S’)} - {msg}”)

# -——— کلاس داده LiDAR -———
class LiDARPointCloud:
    def __init__(self, points=None):
        # points: Nx4 array [x, y, z, intensity]
        self.points = np.array(points, dtype=np.float32) if points is not None else np.zeros((0,4), dtype=np.float32)

    def filter_intensity(self, threshold=0):
        mask = self.points[:,3] >= threshold
        self.points = self.points[mask]

    def voxel_downsample(self, voxel_size=0.1):
        if self.points.shape[0] == 0: return
        coords = np.floor(self.points[:,:3] / voxel_size).astype(np.int32)
        _, idx = np.unique(coords, axis=0, return_index=True)
        self.points = self.points[idx]

    def to_dict(self):
        return {“points”: self.points.tolist()}

    def save_json(self, filepath):
        with open(filepath, “w”) as f:
            json.dump(self.to_dict(), f)

# -——— بارگذاری فایل خام -———
def load_bin_file(filepath):
    try:
        raw = np.fromfile(filepath, dtype=np.float32)
        points = raw.reshape((-1,4))  # [x, y, z, intensity]
        return LiDARPointCloud(points)
    except Exception as e:
        log(f”Failed to load {filepath}: {e}”, “error”)
        return LiDARPointCloud()

# -——— پردازش چند-ورکری -———
class LiDARProcessor:
    def __init__(self, config=None):
        self.config = config or DEFAULT_CONFIG
        self.queue = Queue(maxsize=self.config[“max_queue_size”])
        self.lock = Lock()
        self.workers = []
        self.running = False

    def start(self):
        self.running = True
        for _ in range(self.config[“process_workers”]):
            t = Thread(target=self.worker_loop)
            t.start()
            self.workers.append(t)
        log(“LiDARProcessor started.”, “info”)

    def stop(self):
        self.running = False
        for t in self.workers:
            t.join()
        log(“LiDARProcessor stopped.”, “info”)

    def enqueue_file(self, filepath):
        try:
            self.queue.put(filepath, block=True, timeout=1)
            log(f”Enqueued {filepath}”, “debug”)
        except:
            log(f”Queue full. Failed to enqueue {filepath}”, “warn”)

    def worker_loop(self):
        while self.running or not self.queue.empty():
            try:
                filepath = self.queue.get(timeout=0.5)
            except:
                continue
            pc = load_bin_file(filepath)
            pc.filter_intensity(self.config[“intensity_threshold”])
            pc.voxel_downsample(self.config[“voxel_size”])
            save_path = os.path.join(self.config[“save_dir”], os.path.basename(filepath) + “.json”)
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            pc.save_json(save_path)
            log(f”Processed and saved: {save_path}”, “info”)
            self.queue.task_done()

# -——— نمونه استفاده -———
if __name__ == “__main__”:
    processor = LiDARProcessor()
    processor.start()

    data_files = [os.path.join(DEFAULT_CONFIG[“data_dir”], f) 
                  for f in os.listdir(DEFAULT_CONFIG[“data_dir”]) 
                  if f.endswith(“.bin”)]
    for f in data_files:
        processor.enqueue_file(f)

    processor.queue.join()
    processor.stop()