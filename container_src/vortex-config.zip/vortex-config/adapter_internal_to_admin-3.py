# ============================================================
# VortexHub Internal <-> Admin Quantum Adapter
# 300-Line Production Bridge Engine
# Author: VortexHub Labs - Dr. S.M.H. SADAT
# ============================================================

import time
import json
import threading
import traceback
import hashlib
import os
import uuid
import base64
import hmac
import queue
import random
from typing import Callable, Dict, Any, List, Optional

# ============================================================
# CONFIG
# ============================================================

class Config:
    SECRET_KEY = b”vortexhub-quantum-secret”
    TOKEN_EXPIRY = 3600
    RATE_PER_SEC = 50
    CACHE_TTL = 120
    MAX_QUEUE = 10000
    LOG_LEVEL = “DEBUG”
    PLUGIN_FOLDER = “./plugins”
    METRIC_INTERVAL = 5

# ============================================================
# LOGGER
# ============================================================

class Logger:
    @staticmethod
    def log(level, msg):
        if Config.LOG_LEVEL == “DEBUG” or level != “DEBUG”:
            t = time.strftime(“%H:%M:%S”)
            print(f”[{level}][{t}] {msg}”)

    @staticmethod
    def info(m): Logger.log(“INFO”, m)
    @staticmethod
    def debug(m): Logger.log(“DEBUG”, m)
    @staticmethod
    def warn(m): Logger.log(“WARN”, m)
    @staticmethod
    def error(m): Logger.log(“ERROR”, m)

# ============================================================
# ERROR MODEL
# ============================================================

class ErrorEnvelope:
    @staticmethod
    def wrap(err: str, code: int = 500):
        return {“ok”: False, “error”: err, “code”: code}

# ============================================================
# TOKEN AUTH
# ============================================================

class Auth:
    @staticmethod
    def create_token(user_id: str):
        ts = str(int(time.time()))
        sig = hmac.new(Config.SECRET_KEY, (user_id + ts).encode(), hashlib.sha256).hexdigest()
        payload = f”{user_id}:{ts}:{sig}”.encode()
        return base64.b64encode(payload).decode()

    @staticmethod
    def validate(token: str):
        try:
            raw = base64.b64decode(token).decode()
            uid, ts, sig = raw.split(“:”)
            if time.time() - int(ts) > Config.TOKEN_EXPIRY:
                return False
            exp = hmac.new(Config.SECRET_KEY, (uid + ts).encode(), hashlib.sha256).hexdigest()
            return hmac.compare_digest(sig, exp)
        except:
            return False

# ============================================================
# MEMORY CACHE
# ============================================================

class Cache:
    def __init__(self):
        self.data = {}
        self.lock = threading.Lock()

    def set(self, k, v, ttl=Config.CACHE_TTL):
        with self.lock:
            self.data[k] = (v, time.time() + ttl)

    def get(self, k):
        with self.lock:
            if k not in self.data:
                return None
            v, exp = self.data[k]
            if time.time() > exp:
                del self.data[k]
                return None
            return v

# ============================================================
# RATE LIMITER
# ============================================================

class RateLimiter:
    def __init__(self):
        self.calls = {}
        self.lock = threading.Lock()

    def allow(self, key):
        with self.lock:
            now = time.time()
            if key not in self.calls:
                self.calls[key] = []
            arr = self.calls[key]
            while arr and now - arr[0] > 1:
                arr.pop(0)
            if len(arr) >= Config.RATE_PER_SEC:
                return False
            arr.append(now)
            return True

# ============================================================
# FUNCTION REGISTRY
# ============================================================

class FunctionRegistry:
    def __init__(self):
        self.fns = {}

    def register(self, name, fn):
        self.fns[name] = fn

    def run(self, name, payload):
        if name not in self.fns:
            raise Exception(f”Function ‘{name}’ not registered”)
        return self.fns[name](payload)

# ============================================================
# EVENT BUS
# ============================================================

class EventBus:
    def __init__(self):
        self.handlers = {}

    def on(self, event, handler):
        self.handlers.setdefault(event, []).append(handler)

    def emit(self, event, data):
        if event not in self.handlers:
            return
        for h in self.handlers[event]:
            try:
                h(data)
            except Exception as e:
                Logger.error(f”Event handler error: {e}”)

# ============================================================
# BACKGROUND JOBS
# ============================================================

class Job:
    def __init__(self, fn, args, kw):
        self.fn = fn
        self.args = args
        self.kw = kw
        self.id = uuid.uuid4().hex

class JobEngine:
    def __init__(self):
        self.q = queue.Queue(Config.MAX_QUEUE)
        threading.Thread(target=self.worker, daemon=True).start()

    def add(self, fn, *a, **kw):
        job = Job(fn, a, kw)
        self.q.put(job)
        return job.id

    def worker(self):
        while True:
            job = self.q.get()
            try:
                job.fn(*job.args, **job.kw)
            except Exception as e:
                Logger.error(f”Job error: {e}”)

# ============================================================
# METRICS
# ============================================================

class Metrics:
    def __init__(self):
        self.data = {“requests”: 0, “errors”: 0}
        threading.Thread(target=self.loop, daemon=True).start()

    def inc(self, key):
        self.data[key] += 1

    def loop(self):
        while True:
            time.sleep(Config.METRIC_INTERVAL)
            Logger.info(f”Metrics: {self.data}”)

# ============================================================
# PLUGIN SANDBOX LOADER
# ============================================================

class PluginLoader:
    def __init__(self, registry):
        self.registry = registry

    def load(self):
        folder = Config.PLUGIN_FOLDER
        if not os.path.isdir(folder):
            return
        for f in os.listdir(folder):
            if f.endswith(“.py”):
                path = os.path.join(folder, f)
                try:
                    code = open(path).read()
                    env = {}
                    exec(code, env)
                    if “register” in env:
                        env[“register”](self.registry)
                        Logger.info(f”Plugin loaded: {f}”)
                except Exception as e:
                    Logger.error(f”Plugin load error {f}: {e}”)

# ============================================================
# REQUEST CONTEXT (Pipeline Context)
# ============================================================

class Context:
    def __init__(self, token, action, payload):
        self.token = token
        self.action = action
        self.payload = payload
        self.result = None
        self.error = None

# ============================================================
# PIPELINE MIDDLEWARES
# ============================================================

class MiddlewarePipeline:
    def __init__(self):
        self.steps = []

    def use(self, fn):
        self.steps.append(fn)

    def run(self, ctx: Context):
        for step in self.steps:
            try:
                step(ctx)
                if ctx.error:
                    return
            except Exception as e:
                ctx.error = str(e)
                return

# ============================================================
# ADAPTER ROUTER (NEW LOGIC)
# ============================================================

class QuantumRouter:
    def __init__(self, registry, cache, limiter, events):
        self.registry = registry
        self.cache = cache
        self.limiter = limiter
        self.events = events

        self.pipeline = MiddlewarePipeline()
        self.pipeline.use(self.mw_auth)
        self.pipeline.use(self.mw_rate)
        self.pipeline.use(self.mw_cache)

    # ——————————
    # Middleware: Authentication
    # ——————————
    def mw_auth(self, ctx):
        if not Auth.validate(ctx.token):
            ctx.error = “unauthorized”

    # ——————————
    # Middleware: Rate Limit
    # ——————————
    def mw_rate(self, ctx):
        key = hashlib.sha1(ctx.token.encode()).hexdigest()
        if not self.limiter.allow(key):
            ctx.error = “rate_limit”

    # ——————————
    # Middleware: Cache
    # ——————————
    def mw_cache(self, ctx):
        key = f”{ctx.action}:{json.dumps(ctx.payload)}”
        cached = self.cache.get(key)
        if cached:
            ctx.result = {“cached”: True, “data”: cached}

    # ——————————
    # Router Core
    # ——————————
    def process(self, token, action, payload):
        ctx = Context(token, action, payload)

        self.pipeline.run(ctx)
        if ctx.error:
            return ErrorEnvelope.wrap(ctx.error, 403)

        if ctx.result:
            return ctx.result

        try:
            result = self.registry.run(action, payload)
            key = f”{action}:{json.dumps(payload)}”
            self.cache.set(key, result)
            self.events.emit(“executed”, {“action”: action, “payload”: payload})
            return {“ok”: True, “data”: result}
        except Exception as e:
            Logger.error(traceback.format_exc())
            return ErrorEnvelope.wrap(str(e), 500)

# ============================================================
# MAIN ENGINE
# ============================================================

class InternalAdminAdapter:
    def __init__(self):
        self.registry = FunctionRegistry()
        self.cache = Cache()
        self.limiter = RateLimiter()
        self.events = EventBus()
        self.jobs = JobEngine()
        self.metrics = Metrics()

        self.router = QuantumRouter(
            self.registry,
            self.cache,
            self.limiter,
            self.events
        )

        self.load_core()
        PluginLoader(self.registry).load()

    # -————————
    # Core Functions
    # -————————
    def load_core(self):
        self.registry.register(“ping”, lambda p: {“pong”: True})

        def echo(payload):
            return {“echo”: payload, “ts”: time.time()}

        def heavy(payload):
            time.sleep(1)
            return {“processed”: True, “input”: payload}

        self.registry.register(“echo”, echo)
        self.registry.register(“heavy”, heavy)

    # -————————
    # Public Call
    # -————————
    def call(self, token, action, payload):
        self.metrics.inc(“requests”)
        res = self.router.process(token, action, payload)
        if “error” in res:
            self.metrics.inc(“errors”)
        return res

# ============================================================
# SELF TEST
# ============================================================

if __name__ == “__main__”:
    engine = InternalAdminAdapter()
    t = Auth.create_token(“admin”)
    print(engine.call(t, “ping”, {}))
    print(engine.call(t, “echo”, {“msg”: “hello”}))
    print(engine.call(t, “heavy”, {“x”: 55}))