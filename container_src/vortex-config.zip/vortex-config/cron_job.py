import os
import json
import time
import requests
import logging
from redis import Redis

# ===== Logging Setup =====
logging.basicConfig(filename="cron.log", level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(message)s")

# ===== Environment Variables =====
VALKEY_URL = os.getenv("VALKEY_URL", "redis://red-d4f8qishg0os738qkgt0:6379")
CDN_JSON_URLS = os.getenv("CDN_JSON_URLS", "https://repo1.example.com/agent_config.json,https://repo2.example.com/agent_config.json").split(",")

# ===== Redis Connection =====
redis = Redis.from_url(VALKEY_URL)

# ===== Fetch JSON with Fallback =====
def fetch_json():
    for url in CDN_JSON_URLS:
        try:
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            logging.info(f"Successfully fetched JSON from {url}")
            return data
        except Exception as e:
            logging.warning(f"Failed fetching JSON from {url}: {e}")
    logging.error("All CDN JSON fetch attempts failed.")
    return None

# ===== Validate JSON =====
def validate_json(data):
    try:
        # Basic check: must contain 'agents' and 'workers'
        assert "agents" in data and "workers" in data
        return True
    except Exception as e:
        logging.error(f"JSON validation failed: {e}")
        return False

# ===== Trigger Workers =====
def trigger_workers(data):
    for worker_name, worker in data.get("workers", {}).items():
        try:
            logging.info(f"Triggering worker: {worker_name} (assigned_agent: {worker['assigned_agent']})")
            # Example: push to Redis queue for worker processing
            redis.lpush("worker_queue", json.dumps(worker))
        except Exception as e:
            logging.error(f"Error triggering worker {worker_name}: {e}")

# ===== Main Execution =====
def main():
    json_data = fetch_json()
    if not json_data:
        return
    if validate_json(json_data):
        trigger_workers(json_data)

if __name__ == "__main__":
    main()