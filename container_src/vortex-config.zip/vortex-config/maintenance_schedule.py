# maintenance_schedule.py
import json
import os
from datetime import datetime, timedelta
from typing import List, Dict, Any
import threading
import time
import logging

# ======================= Logger Setup =======================
logging.basicConfig(
    level=logging.INFO,
    format=“[%(asctime)s] [%(levelname)s] %(message)s”,
    handlers=[logging.StreamHandler()]
)

# ======================= Maintenance Task Model =======================
class MaintenanceTask:
    def __init__(self, name: str, interval_hours: float, action: callable, last_run: str = None):
        self.name = name
        self.interval = timedelta(hours=interval_hours)
        self.action = action
        self.last_run = datetime.fromisoformat(last_run) if last_run else None

    def is_due(self) -> bool:
        if not self.last_run:
            return True
        return datetime.utcnow() >= self.last_run + self.interval

    def run(self):
        logging.info(f”Running maintenance task: {self.name}”)
        try:
            self.action()
            self.last_run = datetime.utcnow()
        except Exception as e:
            logging.error(f”Error executing task {self.name}: {str(e)}”)

# ======================= Scheduler =======================
class MaintenanceScheduler:
    def __init__(self, db_path: str = “maintenance_tasks.json”, check_interval: int = 60):
        self.tasks: List[MaintenanceTask] = []
        self.db_path = db_path
        self.check_interval = check_interval  # seconds
        self._load_tasks()
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._scheduler_loop, daemon=True)

    # -—— Persistent Storage -——
    def _load_tasks(self):
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, “r”, encoding=“utf-8”) as f:
                    data = json.load(f)
                    for t in data:
                        task = MaintenanceTask(
                            name=t[“name”],
                            interval_hours=t[“interval_hours”],
                            action=lambda: None,  # Action must be redefined in runtime
                            last_run=t.get(“last_run”)
                        )
                        self.tasks.append(task)
            except Exception as e:
                logging.warning(f”Failed to load maintenance tasks: {str(e)}”)

    def _save_tasks(self):
        try:
            with open(self.db_path, “w”, encoding=“utf-8”) as f:
                json.dump([{
                    “name”: t.name,
                    “interval_hours”: t.interval.total_seconds() / 3600,
                    “last_run”: t.last_run.isoformat() if t.last_run else None
                } for t in self.tasks], f, indent=2)
        except Exception as e:
            logging.error(f”Failed to save maintenance tasks: {str(e)}”)

    # -—— Task Management -——
    def add_task(self, task: MaintenanceTask):
        self.tasks.append(task)
        self._save_tasks()

    def remove_task(self, task_name: str):
        self.tasks = [t for t in self.tasks if t.name != task_name]
        self._save_tasks()

    # -—— Scheduler Loop -——
    def _scheduler_loop(self):
        logging.info(“Maintenance scheduler started.”)
        while not self._stop_event.is_set():
            for task in self.tasks:
                if task.is_due():
                    task.run()
            self._save_tasks()
            time.sleep(self.check_interval)

    def start(self):
        if not self._thread.is_alive():
            self._thread.start()

    def stop(self):
        self._stop_event.set()
        self._thread.join()
        logging.info(“Maintenance scheduler stopped.”)

# ======================= Example Maintenance Actions =======================
def cleanup_temp_files():
    logging.info(“Cleaning up temporary files...”)
    # اضافه کردن منطق پاکسازی فایل‌ها یا کش‌ها
    # os.remove(...) یا shutil.rmtree(...) با اطمینان

def backup_database():
    logging.info(“Backing up database...”)
    # اضافه کردن منطق بکاپ گیری
    # مثل export JSON یا call to DB backup API

def restart_services():
    logging.info(“Restarting critical services...”)
    # اضافه کردن restart سرویس‌ها
    # subprocess.call([“systemctl”, “restart”, “myservice”]) یا مشابه

# ======================= Example Usage =======================
if __name__ == “__main__”:
    scheduler = MaintenanceScheduler()

    # افزودن تسک‌ها
    scheduler.add_task(MaintenanceTask(name=“CleanupTemp”, interval_hours=12, action=cleanup_temp_files))
    scheduler.add_task(MaintenanceTask(name=“BackupDB”, interval_hours=24, action=backup_database))
    scheduler.add_task(MaintenanceTask(name=“RestartServices”, interval_hours=48, action=restart_services))

    # شروع لوپ نگهداری
    scheduler.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        scheduler.stop()