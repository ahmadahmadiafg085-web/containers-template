# ============================================================
# VortexHub Internal <-> Admin Quantum Adapter (WASM Edition)
# Pyodide / Browser / Zero-Backend Compatible
# Author: VortexHub Labs - Dr. S.M.H. SADAT
# ============================================================

import time
import json
import asyncio
import hashlib
import base64
import uuid
import hmac
import random
from typing import Dict, Any, Callable, List, Optional

# ============================================================
# CONFIG
# ============================================================

class Config:
    SECRET_KEY = b”vortexhub-quantum-secret”
    TOKEN_EXPIRY = 3600
    RATE_PER_SEC = 20
    CACHE_TTL = 90
    LOG_LEVEL = “DEBUG”
    METRIC_INTERVAL = 3

# ============================================================
# LOGGER
# ============================================================

class Logger:
    @staticmethod
    def log(level, msg):
        if Config.LOG_LEVEL == “DEBUG” or level != “DEBUG”:
            print(f”[{level}] {msg}”)

    @staticmethod
    def info(m): Logger.log(“INFO”, m)
    @staticmethod
    def debug(m): Logger.log(“DEBUG”, m)
    @staticmethod
    def warn(m): Logger.log(“WARN”, m)
    @staticmethod
    def error(m): Logger.log(“ERROR”, m)

# ============================================================
# ERROR MODEL
# ============================================================

class ErrorEnvelope:
    @staticmethod
    def wrap(err, code=500):
        return {“ok”: False, “error”: err, “code”: code}

# ============================================================
# TOKEN AUTH
# ============================================================

class Auth:
    @staticmethod
    def create_token(uid):
        ts = str(int(time.time()))
        sig = hmac.new(Config.SECRET_KEY, (uid + ts).encode(), hashlib.sha256).hexdigest()
        raw = f”{uid}:{ts}:{sig}”.encode()
        return base64.b64encode(raw).decode()

    @staticmethod
    def validate(token):
        try:
            raw = base64.b64decode(token).decode()
            uid, ts, sig = raw.split(“:”)
            if time.time() - int(ts) > Config.TOKEN_EXPIRY:
                return False
            exp = hmac.new(Config.SECRET_KEY, (uid + ts).encode(), hashlib.sha256).hexdigest()
            return hmac.compare_digest(exp, sig)
        except:
            return False

# ============================================================
# IN-MEMORY CACHE (Browser Safe)
# ============================================================

class Cache:
    def __init__(self):
        self.data = {}

    def set(self, k, v, ttl=Config.CACHE_TTL):
        self.data[k] = (v, time.time() + ttl)

    def get(self, k):
        if k not in self.data:
            return None
        v, exp = self.data[k]
        if time.time() > exp:
            del self.data[k]
            return None
        return v

# ============================================================
# RATE LIMITER (Browser Async)
# ============================================================

class RateLimiter:
    def __init__(self):
        self.calls = {}

    def allow(self, key):
        now = time.time()
        arr = self.calls.get(key, [])
        arr = [t for t in arr if now - t < 1]
        if len(arr) >= Config.RATE_PER_SEC:
            return False
        arr.append(now)
        self.calls[key] = arr
        return True

# ============================================================
# FUNCTION REGISTRY
# ============================================================

class FunctionRegistry:
    def __init__(self):
        self.fns = {}

    def register(self, name, fn):
        self.fns[name] = fn

    async def run(self, name, payload):
        if name not in self.fns:
            raise Exception(f”Function ‘{name}’ not registered”)
        fn = self.fns[name]
        if asyncio.iscoroutinefunction(fn):
            return await fn(payload)
        return fn(payload)

# ============================================================
# EVENT BUS (Browser Safe)
# ============================================================

class EventBus:
    def __init__(self):
        self.handlers = {}

    def on(self, event, handler):
        self.handlers.setdefault(event, []).append(handler)

    def emit(self, event, data):
        for fn in self.handlers.get(event, []):
            try:
                fn(data)
            except Exception as e:
                Logger.error(f”EventBus error: {e}”)

# ============================================================
# BACKGROUND JOB ENGINE (WASM/Async)
# ============================================================

class JobEngine:
    def __init__(self):
        self.queue = asyncio.Queue()
        asyncio.create_task(self.worker())

    async def add(self, fn, *a, **kw):
        job_id = uuid.uuid4().hex
        await self.queue.put((job_id, fn, a, kw))
        return job_id

    async def worker(self):
        while True:
            job_id, fn, a, kw = await self.queue.get()
            try:
                if asyncio.iscoroutinefunction(fn):
                    await fn(*a, **kw)
                else:
                    fn(*a, **kw)
            except Exception as e:
                Logger.error(f”Job error: {e}”)

# ============================================================
# METRICS LOOP
# ============================================================

class Metrics:
    def __init__(self):
        self.data = {“requests”: 0, “errors”: 0}
        asyncio.create_task(self.loop())

    async def inc(self, key):
        self.data[key] += 1

    async def loop(self):
        while True:
            await asyncio.sleep(Config.METRIC_INTERVAL)
            Logger.info(f”Metrics: {self.data}”)

# ============================================================
# CONTEXT
# ============================================================

class Context:
    def __init__(self, token, action, payload):
        self.token = token
        self.action = action
        self.payload = payload
        self.result = None
        self.error = None

# ============================================================
# PIPELINE
# ============================================================

class MiddlewarePipeline:
    def __init__(self):
        self.steps = []

    def use(self, fn):
        self.steps.append(fn)

    async def run(self, ctx):
        for fn in self.steps:
            try:
                if asyncio.iscoroutinefunction(fn):
                    await fn(ctx)
                else:
                    fn(ctx)
                if ctx.error:
                    return
            except Exception as e:
                ctx.error = str(e)
                return

# ============================================================
# QUANTUM ROUTER (WASM)
# ============================================================

class QuantumRouter:
    def __init__(self, registry, cache, limiter, events):
        self.registry = registry
        self.cache = cache
        self.limiter = limiter
        self.events = events

        self.pipeline = MiddlewarePipeline()
        self.pipeline.use(self.mw_auth)
        self.pipeline.use(self.mw_rate)
        self.pipeline.use(self.mw_cache)

    # -————————
    # MW: Auth
    # -————————
    def mw_auth(self, ctx):
        if not Auth.validate(ctx.token):
            ctx.error = “unauthorized”

    # -————————
    # MW: Rate
    # -————————
    def mw_rate(self, ctx):
        key = hashlib.sha1(ctx.token.encode()).hexdigest()
        if not self.limiter.allow(key):
            ctx.error = “rate_limit”

    # -————————
    # MW: Cache
    # -————————
    def mw_cache(self, ctx):
        ck = f”{ctx.action}:{json.dumps(ctx.payload)}”
        cached = self.cache.get(ck)
        if cached:
            ctx.result = {“cached”: True, “data”: cached}

    # -————————
    # Core Processor
    # -————————
    async def process(self, token, action, payload):
        ctx = Context(token, action, payload)
        await self.pipeline.run(ctx)

        if ctx.error:
            return ErrorEnvelope.wrap(ctx.error, 403)
        if ctx.result:
            return ctx.result

        try:
            res = await self.registry.run(action, payload)
            ck = f”{action}:{json.dumps(payload)}”
            self.cache.set(ck, res)
            self.events.emit(“executed”, {“action”: action})
            return {“ok”: True, “data”: res}
        except Exception as e:
            return ErrorEnvelope.wrap(str(e), 500)

# ============================================================
# MAIN ENGINE
# ============================================================

class InternalAdminAdapter:
    def __init__(self):
        self.registry = FunctionRegistry()
        self.cache = Cache()
        self.limiter = RateLimiter()
        self.events = EventBus()
        self.jobs = JobEngine()
        self.metrics = Metrics()

        self.router = QuantumRouter(
            self.registry,
            self.cache,
            self.limiter,
            self.events
        )

        self.load_core()

    # Core functions
    def load_core(self):
        self.registry.register(“ping”, lambda p: {“pong”: True})

        async def echo(p):
            await asyncio.sleep(0)
            return {“echo”: p}

        async def heavy(p):
            await asyncio.sleep(0.3)
            return {“processed”: True, “input”: p}

        self.registry.register(“echo”, echo)
        self.registry.register(“heavy”, heavy)

    async def call(self, token, action, payload):
        await self.metrics.inc(“requests”)
        res = await self.router.process(token, action, payload)
        if “error” in res:
            await self.metrics.inc(“errors”)
        return res

# ============================================================
# SELF TEST (Pyodide Safe)
# ============================================================

async def self_test():
    eng = InternalAdminAdapter()
    t = Auth.create_token(“admin”)
    print(await eng.call(t, “ping”, {}))
    print(await eng.call(t, “echo”, {“msg”: “hi”}))
    print(await eng.call(t, “heavy”, {“x”: 99}))

# Uncomment ONLY when running inside Pyodide:
# asyncio.ensure_future(self_test())
