# adaptive_communication_protocols-2_live_final.py
import json
import re
import threading
from typing import List, Dict, Any, Union, Callable
from datetime import datetime
from collections import defaultdict
import queue
import time

# ================= Message Object =================
class LiveMessage:
    “””Live message: type, protocol, metadata, dynamic analysis.”””
    def __init__(self, content: Union[str, bytes], source: str = “unknown”, protocol: str = “auto”):
        self.content = content
        self.source = source
        self.protocol = protocol if protocol != “auto” else self.detect_protocol(content)
        self.timestamp = datetime.utcnow()
        self.type = self.detect_type(content)
        self.patterns: List[str] = []
        self.metadata: Dict[str, Any] = self.extract_metadata()

    def detect_type(self, content: Union[str, bytes]) -> str:
        if isinstance(content, bytes):
            return “binary”
        elif isinstance(content, str):
            try:
                json.loads(content)
                return “json”
            except:
                if re.search(r”<[a-zA-Z]+>.*</[a-zA-Z]+>”, content, re.DOTALL):
                    return “xml”
                return “text”
        else:
            return “unknown”

    def detect_protocol(self, content: Union[str, bytes]) -> str:
        if isinstance(content, bytes):
            return “binary”
        if isinstance(content, str):
            if re.match(r”^\{.*\}$”, content.strip()):
                return “HTTP/REST”
            if re.match(r”^<\?xml.*\?>|<\w+>.*</\w+>$”, content.strip(), re.DOTALL):
                return “XML”
            if any(keyword in content for keyword in [“CONNECT”, “SUBSCRIBE”, “PUBLISH”]):
                return “MQTT”
            return “Text”
        return “unknown”

    def extract_metadata(self) -> Dict[str, Any]:
        length = len(self.content) if isinstance(self.content, str) else len(self.content)
        return {“length”: length, “source”: self.source, “timestamp”: self.timestamp}

# ================= Message Analyzer =================
class LiveMessageAnalyzer:
    “””Live analyzer: patterns, metadata, adaptive learning.”””
    DEFAULT_PATTERNS = [
        r”\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b”,
        r”http[s]?://[^\s]+”,
        r”\b\d{2,}\b”,
    ]

    def __init__(self):
        self.learned_patterns: Dict[str, int] = defaultdict(int)

    def extract_patterns(self, msg: LiveMessage) -> List[str]:
        content_str = msg.content.decode() if isinstance(msg.content, bytes) else msg.content
        results = []
        for pattern in self.DEFAULT_PATTERNS + list(self.learned_patterns.keys()):
            matches = re.findall(pattern, content_str)
            results.extend(matches)
            for match in matches:
                self.learn_pattern(match)
        msg.patterns = results
        return results

    def learn_pattern(self, snippet: str):
        self.learned_patterns[snippet] += 1

    def summarize(self, msg: LiveMessage) -> str:
        return (f”[{msg.timestamp}] Source: {msg.source}, Protocol: {msg.protocol}, “
                f”Type: {msg.type}, Length: {msg.metadata[‘length’]}, Patterns: {len(msg.patterns)}”)

# ================= Message Generator =================
class LiveMessageGenerator:
    “””Generate dynamic adaptive responses.”””
    def generate_response(self, template: str, context: Dict[str, Any]) -> str:
        result = template
        for k, v in context.items():
            result = result.replace(f”{{{{{k}}}}}”, str(v))
        return result

# ================= Live Communication Runtime =================
class LiveCommunicationRuntime:
    “””Live runtime: message processing, adaptive responses, popups, voice.”””
    def __init__(self):
        self.messages: Dict[str, LiveMessage] = {}
        self.analyzer = LiveMessageAnalyzer()
        self.generator = LiveMessageGenerator()
        self.log: List[Dict[str, Any]] = []
        self.queue = queue.Queue()
        self.live_callbacks: List[Callable[[LiveMessage], None]] = []
        self.running = False

    # Receive messages
    def receive_message(self, name: str, content: Union[str, bytes], source: str = “unknown”, protocol: str = “auto”):
        msg = LiveMessage(content, source, protocol)
        self.analyzer.extract_patterns(msg)
        self.messages[name] = msg
        self.log.append({“name”: name, “summary”: self.analyzer.summarize(msg)})
        self.queue.put(msg)
        # Trigger live callbacks
        for cb in self.live_callbacks:
            cb(msg)

    # Analyze single message
    def analyze_message(self, name: str) -> str:
        if name not in self.messages:
            return f”[Error] Message ‘{name}’ not found”
        return self.analyzer.summarize(self.messages[name])

    # Merge multiple messages
    def merge_messages(self, name: str, sources: List[str], delimiter: str = “\n”) -> str:
        merged_content = delimiter.join([
            self.messages[s].content.decode() if isinstance(self.messages[s].content, bytes) else self.messages[s].content
            for s in sources if s in self.messages
        ])
        merged_msg = LiveMessage(merged_content, source=“merged”, protocol=“mixed”)
        self.analyzer.extract_patterns(merged_msg)
        self.messages[name] = merged_msg
        self.log.append({“name”: name, “summary”: self.analyzer.summarize(merged_msg)})
        return merged_content

    # Generate adaptive response
    def generate_response(self, name: str, template: str, context: Dict[str, Any]) -> str:
        response = self.generator.generate_response(template, context)
        response_msg = LiveMessage(response, source=“generated”, protocol=“Text”)
        self.analyzer.extract_patterns(response_msg)
        self.messages[name+”_response”] = response_msg
        self.log.append({“name”: name+”_response”, “summary”: self.analyzer.summarize(response_msg)})
        return response

    # Register live monitoring callback
    def on_live_message(self, callback: Callable[[LiveMessage], None]):
        self.live_callbacks.append(callback)

    # Start live monitoring thread
    def start_live_monitoring(self):
        if self.running:
            return
        self.running = True
        def monitor():
            while self.running:
                try:
                    msg = self.queue.get(timeout=1)
                    print(f”[LIVE] {self.analyzer.summarize(msg)}”)
                except queue.Empty:
                    continue
        t = threading.Thread(target=monitor, daemon=True)
        t.start()

    def stop_live_monitoring(self):
        self.running = False

    def get_log(self) -> List[Dict[str, Any]]:
        return self.log

# ================= Example Usage =================
if __name__ == “__main__”:
    runtime = LiveCommunicationRuntime()

    # Live callback example
    def live_callback(msg: LiveMessage):
        print(f”[CALLBACK] New message from {msg.source}: {msg.content}”)

    runtime.on_live_message(live_callback)
    runtime.start_live_monitoring()

    # Simulate live messages
    runtime.receive_message(“msg1”, ‘{“user”:”Alice”,”task”:”report”}’, source=“client1”)
    runtime.receive_message(“msg2”, “<note><to>Bob</to><task>Review</task></note>”, source=“client2”)
    runtime.receive_message(“msg3”, b”\x00\x01\x02\x03”, source=“client3”)

    # Merge messages
    runtime.merge_messages(“merged_msgs”, [“msg1”, “msg2”])
    
    # Generate adaptive response
    template = “Hello {{user}}, your task ‘{{task}}’ is processed via {{protocol}}.”
    response = runtime.generate_response(“msg1”, template, {“user”:”Alice”,”task”:”report”,”protocol”:”HTTP”})
    print(“Generated Response:\n”, response)

    # Stop live monitoring gracefully
    time.sleep(2)
    runtime.stop_live_monitoring()

    # View log
    print(“Communication Log:”)
    for entry in runtime.get_log():
        print(entry)