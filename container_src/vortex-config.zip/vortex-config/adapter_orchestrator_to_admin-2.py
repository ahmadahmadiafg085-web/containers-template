import asyncio, json, hashlib, time, traceback
from pyodide.ffi import create_proxy
import js
import base64

# ——————————————
# Utility: hashing, encoding, sandbox safe-run
# ——————————————
def sha256(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()

def encode(data: str) -> str:
    return base64.b64encode(data.encode()).decode()

def decode(data: str) -> str:
    return base64.b64decode(data.encode()).decode()

async def sandbox_run(code: str):
    “””
    اجرای ایزوله – بدون اجازه دسترسی به سیستم.
    “””
    allowed = {“len”: len, “sum”: sum, “min”: min, “max”: max, “range”: range}

    try:
        exec(code, {“__builtins__”: allowed}, {})
        return {“status”: “OK”}
    except Exception as e:
        return {“status”: “ERROR”, “message”: str(e)}

# ——————————————
# Threat Analyzer: رفتارشناسی + الگوهای مشکوک
# ——————————————
class ThreatAnalyzer:
    DANGEROUS_PATTERNS = [
        “eval(“, “exec(“, “import os”, “subprocess”, “socket”, “open(“
    ]

    def analyze(self, code: str):
        findings = []

        for p in self.DANGEROUS_PATTERNS:
            if p in code:
                findings.append(f”Suspicious pattern: {p}”)

        if “for” in code and “while” in code and “lambda” in code:
            findings.append(“Potential obfuscated logic”)

        return findings


# ——————————————
# Real-Time Mirror (internal WebSocket-like)
# ——————————————
class Mirror:
    def __init__(self):
        self.listeners = []

    def subscribe(self, cb):
        self.listeners.append(cb)

    def broadcast(self, event, data):
        for cb in self.listeners:
            cb({“event”: event, “data”: data})


mirror = Mirror()


# ——————————————
# Scenario Queue Scheduler
# ——————————————
class ScenarioQueue:
    def __init__(self):
        self.queue = asyncio.Queue()

    async def add(self, scenario):
        await self.queue.put(scenario)

    async def next(self):
        return await self.queue.get()


scenario_queue = ScenarioQueue()


# ——————————————
# Worker Agent (Self-Healing + Multi-Worker)
# ——————————————
class Worker:
    def __init__(self, wid, analyzer):
        self.wid = wid
        self.analyzer = analyzer
        self.health = 100

    async def run(self):
        while True:
            scenario = await scenario_queue.next()

            try:
                mirror.broadcast(“worker-received”, {
                    “worker”: self.wid,
                    “scenario”: scenario[“name”]
                })

                await self.execute_scenario(scenario)

            except Exception as e:
                self.health -= 20
                mirror.broadcast(“worker-error”, {
                    “worker”: self.wid,
                    “error”: str(e),
                    “trace”: traceback.format_exc()
                })
                await asyncio.sleep(0.5)

            if self.health <= 0:
                mirror.broadcast(“worker-dead”, {“worker”: self.wid})
                break  # worker self-terminates

    async def execute_scenario(self, scenario):
        code = scenario[“code”]

        # Threat analysis
        findings = self.analyzer.analyze(code)
        if findings:
            mirror.broadcast(“threat-detected”, {
                “worker”: self.wid,
                “scenario”: scenario[“name”],
                “findings”: findings
            })
            # still run but inside deeper sandbox
            result = await sandbox_run(code)
        else:
            result = await sandbox_run(code)

        mirror.broadcast(“scenario-result”, {
            “worker”: self.wid,
            “scenario”: scenario[“name”],
            “result”: result
        })


# ——————————————
# Orchestrator with Hot-Reload + Live Mirror
# ——————————————
class Orchestrator:
    def __init__(self, workers=3, hot_reload_interval=3.0):
        self.analyzer = ThreatAnalyzer()
        self.workers = [Worker(i, self.analyzer) for i in range(workers)]
        self.hot_reload_interval = hot_reload_interval
        self.running = True

    async def start(self):
        mirror.broadcast(“orchestrator-start”, {“workers”: len(self.workers)})

        for w in self.workers:
            asyncio.create_task(w.run())

        asyncio.create_task(self.hot_reload())

    async def hot_reload(self):
        while self.running:
            try:
                data = await js.fetch(“./json/scenario-map.json”).then(lambda r: r.text())
                scenarios = json.loads(data)

                for sc in scenarios.get(“queue”, []):
                    await scenario_queue.add(sc)

                mirror.broadcast(“hot-reload”, {“count”: len(scenarios.get(“queue”, []))})

            except Exception as e:
                mirror.broadcast(“hot-reload-error”, {“error”: str(e)})

            await asyncio.sleep(self.hot_reload_interval)


# ——————————————
# Realtime Event Listener (like WebSocket)
# ——————————————
def print_event(ev):
    print(f”[EVENT] {ev[‘event’]} => {ev[‘data’]}”)

mirror.subscribe(print_event)


# ——————————————
# Start the whole runtime
# ——————————————
async def start_runtime():
    orch = Orchestrator(workers=4)
    await orch.start()

asyncio.ensure_future(start_runtime())