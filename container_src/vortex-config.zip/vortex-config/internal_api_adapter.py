import asyncio, logging, traceback
from typing import Callable, Any, Dict, List, Optional
from datetime import datetime
import time

from adapters.adapter_internal_to_admin import DistributedInternalToAdminAdapter

class InternalAPIAdapterConfig:
    def __init__(
        self,
        enable_metrics: bool = True,
        enable_logging: bool = True,
        enable_context_tracking: bool = True,
        max_retries: int = 3,
        retry_delay: int = 2,
        enable_hot_reload: bool = True,
        enable_scheduled_tasks: bool = True,
        enable_dag_execution: bool = True
    ):
        self.enable_metrics = enable_metrics
        self.enable_logging = enable_logging
        self.enable_context_tracking = enable_context_tracking
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.enable_hot_reload = enable_hot_reload
        self.enable_scheduled_tasks = enable_scheduled_tasks
        self.enable_dag_execution = enable_dag_execution

class InternalAPIAdapter:
    def __init__(
        self,
        config: InternalAPIAdapterConfig,
        backend_execute: Callable,
        internal_adapter: DistributedInternalToAdminAdapter
    ):
        self.config = config
        self.backend_execute = backend_execute
        self.internal_adapter = internal_adapter
        self.logger = logging.getLogger(“InternalAPIAdapter”)
        logging.basicConfig(level=logging.INFO)
        
        self.module_states: Dict[str, str] = {}
        self.module_dependencies: Dict[str, List[str]] = {}
        self.execution_history: Dict[str, List[Dict[str, Any]]] = {}
        self.retry_counts: Dict[str, int] = {}
        self._executing_modules: Dict[str, asyncio.Lock] = {}
        self.message_context: Dict[str, List[str]] = {}
        self._scheduled_task: Optional[asyncio.Task] = None

    # -————————
    # Context tracking
    # -————————
    def add_message_context(self, recipient: str, content: str):
        if not self.config.enable_context_tracking:
            return
        self.message_context.setdefault(recipient, []).append(content)
        self.message_context[recipient] = self.message_context[recipient][-50:]

    # -————————
    # Module execution
    # -————————
    async def execute_module(self, module_name: str, args: List[str] = []):
        if module_name not in self._executing_modules:
            self._executing_modules[module_name] = asyncio.Lock()
        async with self._executing_modules[module_name]:
            # DAG execution
            if self.config.enable_dag_execution:
                for dep in self.module_dependencies.get(module_name, []):
                    await self.execute_module(dep, [])
            retries = 0
            while retries <= self.config.max_retries:
                try:
                    self.module_states[module_name] = “running”
                    await self.backend_execute(“internal”, module_name, args)
                    self.module_states[module_name] = “completed”
                    record = {“timestamp”: datetime.utcnow().isoformat(), “args”: args, “status”: “completed”}
                    self.execution_history.setdefault(module_name, []).append(record)
                    if self.config.enable_metrics:
                        await self.internal_adapter.record_execution(module_name, record)
                    return
                except Exception as e:
                    retries += 1
                    self.retry_counts[module_name] = retries
                    self.module_states[module_name] = “failed”
                    record = {“timestamp”: datetime.utcnow().isoformat(), “args”: args, “status”: “failed”, “error”: str(e)}
                    self.execution_history.setdefault(module_name, []).append(record)
                    if self.config.enable_logging:
                        self.logger.error(f”[InternalAPIAdapter] Module {module_name} failed attempt {retries}: {e}”)
                        traceback.print_exc()
                    if retries > self.config.max_retries:
                        return
                    # exponential backoff
                    await asyncio.sleep(self.config.retry_delay * (2 ** (retries - 1)))

    # -————————
    # Hot reload support
    # -————————
    async def hot_reload_module(self, module_name: str):
        if not self.config.enable_hot_reload:
            return
        try:
            await self.backend_execute(“internal”, module_name, [“—reload”])
            self.logger.info(f”[InternalAPIAdapter] Module {module_name} hot reloaded”)
        except Exception as e:
            self.logger.error(f”[InternalAPIAdapter] Hot reload failed for {module_name}: {e}”)
            traceback.print_exc()

    # -————————
    # Dry run for testing
    # -————————
    async def dry_run_module(self, module_name: str):
        try:
            await self.backend_execute(“internal”, module_name, [“—dry-run”])
        except Exception as e:
            self.logger.error(f”[InternalAPIAdapter] Dry run failed for {module_name}: {e}”)
            traceback.print_exc()

    # -————————
    # Scheduled module execution
    # -————————
    async def run_scheduled_modules(self):
        if not self.config.enable_scheduled_tasks:
            return
        while True:
            for module_name, state in self.module_states.items():
                if state == “scheduled”:
                    await self.execute_module(module_name)
            await asyncio.sleep(60)

    # -————————
    # Bootstrap
    # -————————
    def start(self):
        if self.config.enable_scheduled_tasks:
            self._scheduled_task = asyncio.create_task(self.run_scheduled_modules())
        if self.config.enable_logging:
            self.logger.info(“[InternalAPIAdapter] Adapter started with scheduled tasks” if self.config.enable_scheduled_tasks else “[InternalAPIAdapter] Adapter started”) # ================== internal_api_adapter_full.py ==================
import asyncio, logging, time, random, traceback, requests, aiohttp
from typing import List, Dict, Callable, Optional, Any
from datetime import datetime

logger = logging.getLogger(“InternalAPIAdapter”)
logger.setLevel(logging.INFO)

# ================== Config ==================
class InternalAPIAdapterConfig:
    def __init__(self, base_url:str, auth_token:Optional[str]=None,
                 timeout:int=10, max_retries:int=3, enable_hooks:bool=True,
                 sandbox:bool=True, enable_metrics:bool=True):
        self.base_url = base_url
        self.auth_token = auth_token
        self.timeout = timeout
        self.max_retries = max_retries
        self.enable_hooks = enable_hooks
        self.sandbox = sandbox
        self.enable_metrics = enable_metrics

# ================== Adapter ==================
class InternalAPIAdapter:
    def __init__(self, config:InternalAPIAdapterConfig, backend_execute:Callable,
                 loader_adapter, internal_adapter, orchestrator_adapter):
        self.config = config
        self.backend_execute = backend_execute
        self.loader_adapter = loader_adapter
        self.internal_adapter = internal_adapter
        self.orchestrator_adapter = orchestrator_adapter

        self.events:Dict[str,List[Callable]] = {}
        self.metrics:Dict[str,List[float]] = {}
        self.cache:Dict[str,Any] = {}
        self.lock = asyncio.Lock()
        self.trace_cache:Dict[str,Dict] = {}

    async def publish_event(self, event_type:str, payload:dict):
        for cb in self.events.get(event_type,[]):
            try:
                if asyncio.iscoroutinefunction(cb):
                    await cb(payload)
                else:
                    await asyncio.to_thread(cb,payload)
            except Exception as e:
                logger.error(f”[Event Error] {event_type}: {e}”)

    def on_event(self, event_type:str, callback:Callable):
        self.events.setdefault(event_type,[]).append(callback)

    async def run_module_safe(self, module:str, func:str, *args, retries:int=None, cache:bool=False, sandbox:bool=None, **kwargs):
        retries = retries or self.config.max_retries
        sandbox = self.config.sandbox if sandbox is None else sandbox
        key=f”{module}:{func}:{args}:{kwargs}”
        if cache and key in self.cache: return self.cache[key]

        attempt=0; result=None
        tid=f”{time.time()}-{random.randint(1000,9999)}”
        self.trace_cache[tid]={“module”:module,”func”:func,”start”:datetime.utcnow().isoformat()}

        while attempt<=retries:
            try:
                mod=self.loader_adapter.load_module(module)
                fn=getattr(mod,func,None)
                if not callable(fn): raise ValueError(f”Function {func} not callable in module {module}”)
                if asyncio.iscoroutinefunction(fn):
                    result = await fn(*args,**kwargs)
                else:
                    if sandbox:
                        result = await asyncio.to_thread(fn,*args,**kwargs)
                    else:
                        result = fn(*args,**kwargs)
                break
            except Exception as e:
                attempt+=1
                logger.error(f”[InternalAPIAdapter Module Error] {module}.{func} Attempt {attempt}: {e}”)
                if attempt>retries: raise
            finally:
                elapsed=(datetime.utcnow()-datetime.fromisoformat(self.trace_cache[tid][“start”])).total_seconds()
                self.metrics.setdefault(f”{module}.{func}”,[]).append(elapsed)

        self.trace_cache[tid].update({“end”:datetime.utcnow().isoformat(),”result”:str(result)[:200]})
        if cache: self.cache[key]=result
        await self.internal_adapter.record_execution(f”internalapi_{module}_{func}”, {“args”:args,”kwargs”:kwargs,”result”:result})
        return result

    async def call_api(self, endpoint:str, method:str=“GET”, params:dict=None, data:dict=None, headers:dict=None):
        url=f”{self.config.base_url}/{endpoint.lstrip(‘/‘)}”
        headers=headers or {}
        if self.config.auth_token:
            headers[“Authorization”]=f”Bearer {self.config.auth_token}”

        attempt=0
        result=None
        while attempt<=self.config.max_retries:
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.config.timeout)) as session:
                    async with session.request(method.upper(), url, params=params, json=data, headers=headers) as resp:
                        result = await resp.json()
                        break
            except Exception as e:
                attempt+=1
                logger.error(f”[InternalAPIAdapter API Call Error] {url} Attempt {attempt}: {e}”)
                if attempt>self.config.max_retries: raise
        return result

“””
1. Trigger workflow داخلی بر اساس request دریافتی
2. Rate-limit API calls
3. Cache responses از API برای کاهش load
4. Retry خودکار در صورت failure
5. اجرای sandbox برای ماژول‌های داخلی
6. Hot-reload ماژول‌های پردازش API
7. Dry-run برای تست ماژول‌ها بدون call واقعی
8. Event-driven hooks بعد از API call
9. DAG visualization جریان API calls
10. Metrics: latency, response time, success/failure
11. اجرای async batch request
12. Trigger multi-adapter workflow (Email + Discord + Internal API)
13. بررسی checksum / tamper detection روی payload
14. Template سازی payload برای ماژول‌ها
15. Logging کامل همه request و response ها
16. اتصال به DB برای ذخیره لاگ‌ها
17. Notification در صورت failure یا slow response
18. Scheduler برای درخواست‌های دوره‌ای
19. بررسی validation روی payload
20. اتصال به NLP یا ML modules برای تحلیل محتوا
21. Trigger بر اساس status code خاص
22. Auto-forward داده‌ها به دیگر ماژول‌ها
23. Cleanup cache خودکار
24. اجرای retry exponential backoff
25. اجرای dry-run برای integration testing
26. اتصال به authentication provider
27. بررسی allowed IP / rate-limiting مشتریان
28. Integration با task scheduler داخلی
29. ایجاد dashboard مدیریتی مشابه Discord و Email
30. دسته‌بندی endpointها و workflowهای مختلف بر اساس priority
“””# ================== internal_api_adapter.py ==================
import asyncio
import logging
import datetime
import traceback
import random
import time
from typing import Dict, List, Callable, Optional, Any

# ================== IMPORT EXISTING ADAPTERS ==================
from adapters.adapter_internal_to_admin import DistributedInternalToAdminAdapter
from orchestrator.orchestrator_adapter import AdapterOrchestratorToAdmin
from loader.loader_adapter import LoaderToAdminAdapter
from discord_integrated_adapter import DiscordAdapter
from email_adapter_full import EmailAdapter, EmailAdapterConfig

# ================== Logger ==================
logger = logging.getLogger(“InternalAPIAdapter”)
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter(‘%(asctime)s - %(levelname)s - %(message)s’))
logger.addHandler(ch)

# ================== Config ==================
class InternalAPIAdapterConfig:
    def __init__(
        self,
        allowed_endpoints: Optional[List[str]] = None,
        max_retries: int = 3,
        retry_delay: int = 2,
        enable_sandbox: bool = True,
        enable_metrics: bool = True,
        enable_dry_run: bool = True,
        scheduled_check_interval: int = 60,
        enable_hot_reload: bool = True,
        enable_context_aware: bool = True,
        enable_pre_post_hooks: bool = True
    ):
        self.allowed_endpoints = allowed_endpoints or []
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.enable_sandbox = enable_sandbox
        self.enable_metrics = enable_metrics
        self.enable_dry_run = enable_dry_run
        self.scheduled_check_interval = scheduled_check_interval
        self.enable_hot_reload = enable_hot_reload
        self.enable_context_aware = enable_context_aware
        self.enable_pre_post_hooks = enable_pre_post_hooks

# ================== InternalAPIAdapter ==================
class InternalAPIAdapter:
    def __init__(self, config: InternalAPIAdapterConfig,
                 internal_adapter: DistributedInternalToAdminAdapter,
                 loader_adapter: LoaderToAdminAdapter,
                 orchestrator_adapter: AdapterOrchestratorToAdmin,
                 discord_adapter: Optional[DiscordAdapter] = None,
                 email_adapter: Optional[EmailAdapter] = None):

        self.config = config
        self.internal_adapter = internal_adapter
        self.loader_adapter = loader_adapter
        self.orchestrator_adapter = orchestrator_adapter
        self.discord_adapter = discord_adapter
        self.email_adapter = email_adapter

        self.metrics: Dict[str, List[float]] = {}
        self.policy = {“allow”: set(), “deny”: set(), “rate_limits”: {}, “signatures”: {}}
        self.trace_enabled = True
        self.tc: Dict[str, dict] = {}
        self.endpoint_states: Dict[str, str] = {}  # idle, running, failed, completed, scheduled
        self._executing_endpoints: Dict[str, asyncio.Lock] = {}
        self.execution_history: Dict[str, List[Dict[str, Any]]] = {}
        self.retry_counts: Dict[str, int] = {}
        self.module_dependencies: Dict[str, List[str]] = {}  # DAG execution
        self.message_context: Dict[str, List[str]] = {}  # برای context-aware execution

        self._scheduled_task: Optional[asyncio.Task] = None

    # -————— Trace & Metrics -—————
    def _trace_start(self, endpoint, func):
        if not self.trace_enabled: return None
        tid = f”{time.time()}-{random.randint(1000,9999)}”
        self.tc[tid] = {“endpoint”: endpoint, “func”: func, “start”: datetime.datetime.utcnow().isoformat()}
        return tid

    def _trace_end(self, tid, res):
        if tid in self.tc:
            self.tc[tid].update({“end”: datetime.datetime.utcnow().isoformat(), “res”: str(res)[:200]})

    # -————— Policy & Rate Limit -—————
    def _policy_check(self, endpoint):
        if endpoint in self.policy[“deny”]: raise PermissionError(“Endpoint denied”)
        if self.policy[“allow”] and endpoint not in self.policy[“allow”]: raise PermissionError(“Endpoint blocked”)
        rl = self.policy[“rate_limits”].get(endpoint)
        if rl:
            rl[“count”] = rl.get(“count”, 0) + 1
            if rl[“count”] > rl.get(“max”, 0): raise RuntimeError(“rate_limit_exceeded”)

    # -————— Context Management -—————
    def add_context(self, source: str, content: str):
        if not self.config.enable_context_aware: return
        if source not in self.message_context:
            self.message_context[source] = []
        self.message_context[source].append(content)
        self.message_context[source] = self.message_context[source][-20:]

    # -————— Core Execution -—————
    async def call_endpoint(self, endpoint_name: str, args: Optional[List[Any]] = None, kwargs: Optional[Dict[str, Any]] = None):
        args = args or []
        kwargs = kwargs or {}

        if endpoint_name not in self._executing_endpoints:
            self._executing_endpoints[endpoint_name] = asyncio.Lock()

        async with self._executing_endpoints[endpoint_name]:
            # DAG dependencies
            for dep in self.module_dependencies.get(endpoint_name, []):
                await self.call_endpoint(dep)

            retries = 0
            tid = self._trace_start(endpoint_name, “call_endpoint”)
            while retries <= self.config.max_retries:
                try:
                    self._policy_check(endpoint_name)
                    self.endpoint_states[endpoint_name] = “running”

                    # Pre-hook
                    if self.config.enable_pre_post_hooks:
                        await self.loader_adapter.run(endpoint_name, “pre_hook”, *args, **kwargs)

                    # Sandbox / Dry-run support
                    if self.config.enable_sandbox or self.config.enable_dry_run:
                        logger.info(f”[SANDBOX] Executing endpoint `{endpoint_name}` with args={args}, kwargs={kwargs}”)
                        res = {“sandbox”: True}
                    else:
                        # Integration with Loader & Orchestrator
                        res = await self.loader_adapter.run(endpoint_name, “main”, *args, **kwargs)

                    # Post-hook
                    if self.config.enable_pre_post_hooks:
                        await self.loader_adapter.run(endpoint_name, “post_hook”, *args, **kwargs)

                    self.endpoint_states[endpoint_name] = “completed”
                    self.execution_history.setdefault(endpoint_name, []).append({
                        “timestamp”: datetime.datetime.utcnow().isoformat(),
                        “args”: args,
                        “kwargs”: kwargs,
                        “status”: “completed”
                    })

                    # Record metrics
                    if self.config.enable_metrics:
                        self.metrics.setdefault(endpoint_name, []).append(datetime.datetime.utcnow())
                    await self.internal_adapter.record_execution(endpoint_name, self.execution_history[endpoint_name][-1])

                    self._trace_end(tid, res)
                    return res
                except Exception as e:
                    retries += 1
                    self.retry_counts[endpoint_name] = retries
                    self.endpoint_states[endpoint_name] = “failed”
                    self.execution_history.setdefault(endpoint_name, []).append({
                        “timestamp”: datetime.datetime.utcnow().isoformat(),
                        “args”: args,
                        “kwargs”: kwargs,
                        “status”: “failed”,
                        “error”: str(e)
                    })
                    logger.error(f”[InternalAPIAdapter] Endpoint `{endpoint_name}` failed attempt {retries}: {e}”)
                    traceback.print_exc()
                    await asyncio.sleep(self.config.retry_delay)
                    if retries > self.config.max_retries:
                        # Notify via Discord or Email if integrated
                        if self.discord_adapter:
                            await self.discord_adapter._execute_backend_module_safe(“internal_api”, None, [endpoint_name])
                        if self.email_adapter:
                            await self.email_adapter.send_email(
                                recipient=self.email_adapter.config.default_sender or “admin@example.com”,
                                subject=f”❌ Endpoint {endpoint_name} Failed”,
                                body=f”Endpoint `{endpoint_name}` failed after {retries} retries: {e}”
                            )
                        raise

    # -————— Batch Execution -—————
    async def batch_call(self, calls: List[Dict[str, Any]]):
        tasks = [
            self.call_endpoint(c[“endpoint”], c.get(“args”, []), c.get(“kwargs”, {}))
            for c in calls
        ]
        return await asyncio.gather(*tasks, return_exceptions=True)

    # -————— Scheduled Execution -—————
    async def run_scheduled_endpoints(self):
        while True:
            for endpoint, state in self.endpoint_states.items():
                if state == “scheduled”:
                    await self.call_endpoint(endpoint)
            await asyncio.sleep(self.config.scheduled_check_interval)

    # -————— Hot Reload -—————
    async def hot_reload_endpoint(self, endpoint_name: str):
        if not self.config.enable_hot_reload: return
        await self.loader_adapter.run(endpoint_name, “main”, “—reload”)
        logger.info(f”[InternalAPIAdapter] Hot reload executed for `{endpoint_name}`”)

    # -————— Dry Run -—————
    async def dry_run_endpoint(self, endpoint_name: str):
        if not self.config.enable_dry_run: return
        await self.loader_adapter.run(endpoint_name, “main”, “—dry-run”)
        logger.info(f”[InternalAPIAdapter] Dry run executed for `{endpoint_name}`”)

# ================== GLOBAL SINGLETON ==================
internal = DistributedInternalToAdminAdapter(service=None)
loader = LoaderToAdminAdapter(base=“./“, admin=internal)
orchestrator = AdapterOrchestratorToAdmin([internal, loader])

# Discord and Email adapters can be injected optionally
discord_adapter = None
email_config = EmailAdapterConfig(smtp_server=“smtp.example.com”, username=“user@example.com”, password=“secret”)
email_adapter = EmailAdapter(email_config, internal, loader, orchestrator)

internal_api_config = InternalAPIAdapterConfig()
internal_api_adapter = InternalAPIAdapter(
    internal_api_config,
    internal,
    loader,
    orchestrator,
    discord_adapter=discord_adapter, # ================== integrated_adapters.py ==================
import asyncio
import logging
import datetime
import traceback
from typing import Dict, Any, Callable, Optional, List
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib

# -—————————
# IMPORT EXISTING MODULES
# -—————————
from adapters.adapter_internal_to_admin import DistributedInternalToAdminAdapter
from orchestrator.orchestrator_adapter import AdapterOrchestratorToAdmin
from loader.loader_adapter import LoaderToAdminAdapter

# ================== Logger ==================
logger = logging.getLogger(“IntegratedAdapter”)
logger.setLevel(logging.INFO)
logging.basicConfig(level=logging.INFO)

# ================== Email Adapter Config ==================
class EmailAdapterConfig:
    def __init__(self, smtp_server:str, smtp_port:int, username:str, password:str,
                 use_tls: bool=True, default_sender: Optional[str]=None,
                 allowed_recipients: Optional[List[str]]=None,
                 max_retries:int=3, retry_delay:int=2,
                 enable_metrics: bool=True,
                 enable_context_tracking: bool=True,
                 enable_html_emails: bool=True,
                 enable_dag_execution: bool=True,
                 enable_bulk_send: bool=True,
                 enable_template_support: bool=True,
                 enable_interactive_feedback: bool=True,
                 enable_scheduled_tasks: bool=True,
                 enable_admin_dashboard: bool=True):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.use_tls = use_tls
        self.default_sender = default_sender or username
        self.allowed_recipients = allowed_recipients or []
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.enable_metrics = enable_metrics
        self.enable_context_tracking = enable_context_tracking
        self.enable_html_emails = enable_html_emails
        self.enable_dag_execution = enable_dag_execution
        self.enable_bulk_send = enable_bulk_send
        self.enable_template_support = enable_template_support
        self.enable_interactive_feedback = enable_interactive_feedback
        self.enable_scheduled_tasks = enable_scheduled_tasks
        self.enable_admin_dashboard = enable_admin_dashboard

# ================== Email Adapter ==================
class EmailAdapter:
    def __init__(self, config: EmailAdapterConfig, backend_execute: Callable,
                 loader_adapter: LoaderToAdminAdapter,
                 internal_adapter: DistributedInternalToAdminAdapter,
                 orchestrator_adapter: AdapterOrchestratorToAdmin):
        self.config = config
        self.backend_execute = backend_execute
        self.loader_adapter = loader_adapter
        self.internal_adapter = internal_adapter
        self.orchestrator_adapter = orchestrator_adapter

        self.module_states: Dict[str,str] = {}
        self.module_dependencies: Dict[str,List[str]] = {}
        self.execution_history: Dict[str,List[Dict[str,Any]]] = {}
        self.retry_counts: Dict[str,int] = {}
        self._executing_modules: Dict[str, asyncio.Lock] = {}
        self.message_context: Dict[str,List[str]] = {}
        self._scheduled_task: Optional[asyncio.Task] = None

    def add_message_context(self, recipient: str, content: str):
        if not self.config.enable_context_tracking: return
        self.message_context.setdefault(recipient, [])
        self.message_context[recipient].append(content)
        self.message_context[recipient] = self.message_context[recipient][-50:]

    async def send_email(self, to: str, subject: str, body: str, html: bool=False):
        if self.config.allowed_recipients and to not in self.config.allowed_recipients:
            logger.warning(f”Recipient {to} not allowed”)
            return False
        msg = MIMEMultipart()
        msg[‘From’] = self.config.default_sender
        msg[‘To’] = to
        msg[‘Subject’] = subject
        msg.attach(MIMEText(body,’html’ if html and self.config.enable_html_emails else ‘plain’))

        retries = 0
        while retries <= self.config.max_retries:
            try:
                server = smtplib.SMTP(self.config.smtp_server, self.config.smtp_port)
                if self.config.use_tls: server.starttls()
                server.login(self.config.username, self.config.password)
                server.sendmail(self.config.default_sender, to, msg.as_string())
                server.quit()
                logger.info(f”Email sent to {to}”)
                self.add_message_context(to, body)
                return True
            except Exception as e:
                retries += 1
                self.retry_counts[to] = retries
                logger.error(f”Failed to send email to {to} attempt {retries}: {e}”)
                traceback.print_exc()
                if retries > self.config.max_retries: return False
                await asyncio.sleep(self.config.retry_delay)

    async def send_bulk_email(self, recipients: List[str], subject: str, body: str, html: bool=False):
        if not self.config.enable_bulk_send:
            logger.warning(“Bulk send disabled”)
            return
        for r in recipients:
            await self.send_email(r, subject, body, html)

    async def execute_module_safe(self, module_name: str, args: List[str]):
        if module_name not in self._executing_modules: self._executing_modules[module_name] = asyncio.Lock()
        async with self._executing_modules[module_name]:
            for d in self.module_dependencies.get(module_name, []):
                await self.execute_module_safe(d, [])
            retries = 0
            while retries <= self.config.max_retries:
                try:
                    self.module_states[module_name] = “running”
                    await self.backend_execute(“email”, module_name, [“—pre-hook”]+args)
                    await self.backend_execute(“email”, module_name, args)
                    await self.backend_execute(“email”, module_name, [“—post-hook”]+args)
                    self.module_states[module_name] = “completed”
                    self.execution_history.setdefault(module_name, []).append({
                        “timestamp”: datetime.datetime.utcnow().isoformat(),
                        “args”: args,
                        “status”: “completed”
                    })
                    await self.internal_adapter.record_execution(module_name, self.execution_history[module_name][-1])
                    return
                except Exception as e:
                    retries += 1
                    self.retry_counts[module_name] = retries
                    self.module_states[module_name] = “failed”
                    self.execution_history.setdefault(module_name, []).append({
                        “timestamp”: datetime.datetime.utcnow().isoformat(),
                        “args”: args,
                        “status”: “failed”,
                        “error”: str(e)
                    })
                    logger.error(f”[EmailAdapter] Module {module_name} failed attempt {retries}: {e}”)
                    traceback.print_exc()
                    if retries > self.config.max_retries: return
                    await asyncio.sleep(self.config.retry_delay)

    async def hot_reload_module(self, module_name: str):
        try:
            await self.backend_execute(“email”, module_name, [“—reload”])
            logger.info(f”[EmailAdapter] Module {module_name} hot reloaded”)
        except Exception as e:
            logger.error(f”[EmailAdapter] Hot reload failed for {module_name}: {e}”)
            traceback.print_exc()

    async def dry_run_module(self, module_name: str):
        try:
            await self.backend_execute(“email”, module_name, [“—dry-run”])
        except Exception as e:
            logger.error(f”[EmailAdapter] Dry run failed for {module_name}: {e}”)
            traceback.print_exc()

# ================== Internal API Adapter Config ==================
class InternalAPIAdapterConfig:
    def __init__(self,
                 enable_metrics: bool=True,
                 enable_context_tracking: bool=True,
                 max_concurrent_requests: int=10,
                 allowed_clients: Optional[List[str]]=None):
        self.enable_metrics = enable_metrics
        self.enable_context_tracking = enable_context_tracking
        self.max_concurrent_requests = max_concurrent_requests
        self.allowed_clients = allowed_clients or []

# ================== Internal API Adapter ==================
class InternalAPIAdapter:
    def __init__(self,
                 email_adapter: EmailAdapter,
                 loader_adapter: LoaderToAdminAdapter,
                 internal_adapter: DistributedInternalToAdminAdapter,
                 orchestrator_adapter: AdapterOrchestratorToAdmin,
                 config: InternalAPIAdapterConfig):
        self.email_adapter = email_adapter
        self.loader_adapter = loader_adapter
        self.internal_adapter = internal_adapter
        self.orchestrator_adapter = orchestrator_adapter
        self.config = config
        self._locks: Dict[str, asyncio.Lock] = {}
        self.request_history: Dict[str, List[Dict[str, Any]]] = {}
        self.metrics: Dict[str, Any] = {}

    async def handle_request(self, client_id: str, action: str, payload: Dict[str, Any]):
        “””Main entry point for internal API requests”””
        if self.config.allowed_clients and client_id not in self.config.allowed_clients:
            logger.warning(f”Client {client_id} not allowed”)
            return {“status”: “error”, “reason”: “client not allowed”}

        if action not in self._locks:
            self._locks[action] = asyncio.Lock()

        async with self._locks[action]:
            try:
                self.request_history.setdefault(action, []).append({
                    “client_id”: client_id,
                    “timestamp”: datetime.datetime.utcnow().isoformat(),
                    “payload”: payload
                })

                # Dispatch actions
                dispatch_map = {
                    “send_email”: self.email_adapter.send_email,
                    “send_bulk_email”: self.email_adapter.send_bulk_email,
                    “execute_module”: self.email_adapter.execute_module_safe,
                    “hot_reload_module”: self.email_adapter.hot_reload_module,
                    “dry_run_module”: self.email_adapter.dry_run_module
                }

                if action in dispatch_map:
                    method = dispatch_map[action]
                    return {“status”: “success”} if await method(**payload) else {“status”: “failed”}
                else:
                    return {“status”: “error”, “reason”: “unknown action”}

            except Exception as e:
                logger.error(f”[InternalAPIAdapter] Error handling request: {e}”)
                traceback.print_exc()
                return {“status”: “error”, “reason”: str(e)}

    async def get_metrics(self):
        if not self.config.enable_metrics:
            return {}
        return {
            “module_states”: self.email_adapter.module_states,
            “execution_history”: self.email_adapter.execution_history,
            “retry_counts”: self.email_adapter.retry_counts
        }

    async def get_context(self, recipient: str):
        if not self.config.enable_context_tracking:
            return {}
        return self.email_adapter.message_context.get(recipient, [])

# ================== Factory Functions ==================
def create_email_adapter(config: EmailAdapterConfig, backend_execute: Callable,
                         loader_adapter: LoaderToAdminAdapter,
                         internal_adapter: DistributedInternalToAdminAdapter,
                         orchestrator_adapter: AdapterOrchestratorToAdmin):
    adapter = EmailAdapter(config, backend_execute, loader_adapter, internal_adapter, orchestrator_adapter)
    return adapter

def create_internal_api_adapter(email_adapter: EmailAdapter,
                                loader_adapter: LoaderToAdminAdapter,
                                internal_adapter: DistributedInternalToAdminAdapter,
                                orchestrator_adapter: AdapterOrchestratorToAdmin,
                                config: InternalAPIAdapterConfig):
    return InternalAPIAdapter(email_adapter, loader_adapter, internal_adapter, orchestrator_adapter, config)
    email_adapter=email_adapter
) # ================== internal_api_adapter.py (Full Integrated Version) ==================
import asyncio
import logging
import datetime
import traceback
from typing import Dict, List, Callable, Any, Optional, Union

# ——————————
# IMPORT EXISTING MODULES
# ——————————
from adapters.adapter_internal_to_admin import DistributedInternalToAdminAdapter
from orchestrator.orchestrator_adapter import AdapterOrchestratorToAdmin
from loader.loader_adapter import LoaderToAdminAdapter
from email_adapter_full import EmailAdapter, EmailAdapterConfig

# ——————————
# CONFIGURATION CLASS
# ——————————
class InternalAPIAdapterConfig:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: int = 10,
        max_retries: int = 3,
        retry_delay: int = 2,
        allowed_endpoints: Optional[List[str]] = None,
        allowed_roles: Optional[List[str]] = None,
        enable_metrics: bool = True,
        enable_context_tracking: bool = True,
        enable_dag_execution: bool = True,
        enable_scheduled_tasks: bool = True,
        enable_dry_run: bool = True,
        enable_hot_reload: bool = True,
        enable_interactive_feedback: bool = True,
        enable_bulk_requests: bool = True,
        enable_response_caching: bool = True,
        enable_error_notifications: bool = True,
        enable_admin_dashboard: bool = True
    ):
        self.base_url = base_url
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.allowed_endpoints = allowed_endpoints or []
        self.allowed_roles = allowed_roles or []
        self.enable_metrics = enable_metrics
        self.enable_context_tracking = enable_context_tracking
        self.enable_dag_execution = enable_dag_execution
        self.enable_scheduled_tasks = enable_scheduled_tasks
        self.enable_dry_run = enable_dry_run
        self.enable_hot_reload = enable_hot_reload
        self.enable_interactive_feedback = enable_interactive_feedback
        self.enable_bulk_requests = enable_bulk_requests
        self.enable_response_caching = enable_response_caching
        self.enable_error_notifications = enable_error_notifications
        self.enable_admin_dashboard = enable_admin_dashboard

# ——————————
# INTERNAL API ADAPTER
# ——————————
class InternalAPIAdapter:
    def __init__(self,
                 config: InternalAPIAdapterConfig,
                 backend_execute: Callable,
                 loader_adapter: LoaderToAdminAdapter,
                 internal_adapter: DistributedInternalToAdminAdapter,
                 orchestrator_adapter: AdapterOrchestratorToAdmin,
                 email_adapter: Optional[EmailAdapter] = None):
        self.config = config
        self.backend_execute = backend_execute
        self.loader_adapter = loader_adapter
        self.internal_adapter = internal_adapter
        self.orchestrator_adapter = orchestrator_adapter
        self.email_adapter = email_adapter

        self.logger = logging.getLogger(“InternalAPIAdapter”)
        logging.basicConfig(level=logging.INFO)

        self.module_states: Dict[str, str] = {}  # idle, running, failed, completed, scheduled
        self.module_dependencies: Dict[str, List[str]] = {}  # DAG mapping
        self.execution_history: Dict[str, List[Dict[str, Any]]] = {}
        self.retry_counts: Dict[str, int] = {}
        self._executing_modules: Dict[str, asyncio.Lock] = {}
        self.message_context: Dict[str, List[str]] = {}
        self.response_cache: Dict[str, Any] = {}
        self._scheduled_task: Optional[asyncio.Task] = None

    # ——————————
    # CONTEXT TRACKING
    # ——————————
    def add_context(self, user_id: str, data: str):
        if not self.config.enable_context_tracking:
            return
        if user_id not in self.message_context:
            self.message_context[user_id] = []
        self.message_context[user_id].append(data)
        # Keep last 50 messages
        self.message_context[user_id] = self.message_context[user_id][-50:]

    # ——————————
    # ROLE CHECK
    # ——————————
    def user_has_permission(self, user_roles: List[str], endpoint: str):
        if not self.config.allowed_roles:
            return True
        return any(role in user_roles for role in self.config.allowed_roles)

    # ——————————
    # SAFE MODULE EXECUTION WITH DAG + HOOKS + RETRY + METRICS
    # ——————————
    async def execute_module_safe(self, module_name: str, args: List[str]):
        if module_name not in self._executing_modules:
            self._executing_modules[module_name] = asyncio.Lock()

        async with self._executing_modules[module_name]:
            # DAG dependencies
            deps = self.module_dependencies.get(module_name, [])
            for dep in deps:
                await self.execute_module_safe(dep, [])

            retries = 0
            while retries <= self.config.max_retries:
                try:
                    self.module_states[module_name] = “running”
                    # pre-hook
                    await self.backend_execute(“internal_api”, module_name, [“—pre-hook”] + args)
                    # main execution
                    await self.backend_execute(“internal_api”, module_name, args)
                    # post-hook
                    await self.backend_execute(“internal_api”, module_name, [“—post-hook”] + args)

                    self.module_states[module_name] = “completed”
                    # record execution
                    record = {
                        “timestamp”: datetime.datetime.utcnow().isoformat(),
                        “args”: args,
                        “status”: “completed”
                    }
                    self.execution_history.setdefault(module_name, []).append(record)
                    await self.internal_adapter.record_execution(module_name, record)
                    # cache response if enabled
                    if self.config.enable_response_caching:
                        self.response_cache[module_name] = record
                    return
                except Exception as e:
                    retries += 1
                    self.retry_counts[module_name] = retries
                    self.module_states[module_name] = “failed”
                    record = {
                        “timestamp”: datetime.datetime.utcnow().isoformat(),
                        “args”: args,
                        “status”: “failed”,
                        “error”: str(e)
                    }
                    self.execution_history.setdefault(module_name, []).append(record)
                    self.logger.error(f”[InternalAPIAdapter] Module {module_name} failed attempt {retries}: {e}”)
                    traceback.print_exc()
                    if self.email_adapter and self.config.enable_error_notifications:
                        await self.email_adapter.send_email(
                            to=self.email_adapter.config.default_sender,
                            subject=f”[InternalAPIAdapter] Module {module_name} Failed”,
                            body=f”Module {module_name} failed attempt {retries}:\n{e}”
                        )
                    if retries > self.config.max_retries:
                        return
                    await asyncio.sleep(self.config.retry_delay)

    # ——————————
    # HOT RELOAD / DRY RUN
    # ——————————
    async def hot_reload_module(self, module_name: str):
        if not self.config.enable_hot_reload:
            return
        try:
            await self.backend_execute(“internal_api”, module_name, [“—reload”])
            self.logger.info(f”[InternalAPIAdapter] Module {module_name} hot reloaded”)
        except Exception as e:
            self.logger.error(f”[InternalAPIAdapter] Hot reload failed for {module_name}: {e}”)
            traceback.print_exc()

    async def dry_run_module(self, module_name: str):
        if not self.config.enable_dry_run:
            return
        try:
            await self.backend_execute(“internal_api”, module_name, [“—dry-run”])
        except Exception as e:
            self.logger.error(f”[InternalAPIAdapter] Dry run failed for {module_name}: {e}”)
            traceback.print_exc()

    # ——————————
    # BULK EXECUTION
    # ——————————
    async def bulk_execute(self, modules: List[str], args_list: Optional[List[List[str]]] = None):
        args_list = args_list or [[] for _ in modules]
        tasks = []
        for mod, args in zip(modules, args_list):
            tasks.append(self.execute_module_safe(mod, args))
        await asyncio.gather(*tasks)

    # ——————————
    # SCHEDULED TASKS
    # ——————————
    async def run_scheduled_modules(self):
        if not self.config.enable_scheduled_tasks:
            return
        while True:
            for module_name, state in self.module_states.items():
                if state == “scheduled”:
                    await self.execute_module_safe(module_name, [])
            await asyncio.sleep(60)

    # ——————————
    # METRICS
    # ——————————
    def metrics_summary(self, module_name: Optional[str] = None):
        if module_name:
            return self.execution_history.get(module_name, [])
        return self.execution_history

# ——————————
# CREATE INSTANCE
# ——————————
def create_internal_api_adapter(config: InternalAPIAdapterConfig,
                                backend_execute: Callable,
                                loader_adapter: LoaderToAdminAdapter,
                                internal_adapter: DistributedInternalToAdminAdapter,
                                orchestrator_adapter: AdapterOrchestratorToAdmin,
                                email_adapter: Optional[EmailAdapter] = None):
    adapter = InternalAPIAdapter(config, backend_execute, loader_adapter, internal_adapter, orchestrator_adapter, email_adapter)
    if config.enable_scheduled_tasks:
        adapter._scheduled_task = asyncio.create_task(adapter.run_scheduled_modules())
    return adapter
    