import asyncio,json,uuid,time,aiofiles,aiohttp,hashlib
from pathlib import Path
from typing import List,Dict,Any,Callable

def generate_uuid()->str: return str(uuid.uuid4())
def timestamp()->str: return time.strftime("%Y-%m-%d %H:%M:%S")
def hash_json(obj:Dict[str,Any])->str: return hashlib.sha256(json.dumps(obj,sort_keys=True).encode()).hexdigest()

class JSONManager:
    def __init__(self,files_paths:List[str],central_json:str=None):
        self.files_paths,self.central_json,self.data,self.history,self.queue={},central_json,{},{},asyncio.PriorityQueue()
        self.module_intervals,self.last_module_run,self.module_hashes={}, {}, {}
        self.webhook_rate_limit=50; self.webhook_interval=1/self.webhook_rate_limit

    async def load_file(self,path:str)->Dict[str,Any]:
        f=Path(path)
        if not f.exists(): return {}
        try: async with aiofiles.open(f,'r') as file: return json.loads(await file.read())
        except: return {}

    async def aggregate(self)->Dict[str,Any]:
        agg={"_id":generate_uuid(),"_timestamp":timestamp(),"modules":{}}
        if self.central_json: agg["modules"]["central"]=await self.load_file(self.central_json)
        results=await asyncio.gather(*[self.load_file(p) for p in self.files_paths])
        for p,res in zip(self.files_paths,results): agg["modules"][Path(p).stem]=res
        self.data=agg; self.history.append(agg); return agg

    async def save(self,out_path="aggregated.json"):
        try: async with aiofiles.open(out_path,'w') as f: await f.write(json.dumps(self.data,indent=2))
        except: pass

    def detect_delta(self,module_name:str,new_data:Dict[str,Any])->Dict[str,Any]:
        new_hash=hash_json(new_data); old_hash=self.module_hashes.get(module_name)
        self.module_hashes[module_name]=new_hash
        return new_data if old_hash!=new_hash else {}

    def get_module_interval(self,module_name:str)->float:
        base=self.module_intervals.get(module_name,5.0)
        elapsed=time.time()-self.last_module_run.get(module_name,0)
        self.last_module_run[module_name]=time.time()
        return max(1.0,base-elapsed*0.1)

    async def trigger_all(self,condition_key:str,action:Callable[[Dict[str,Any]],Any],threshold:float=0):
        for name,module in self.data.get("modules",{}).items():
            val=module.get(condition_key,0)
            if val>threshold:
                delta=self.detect_delta(name,module)
                if not delta: continue
                priority=int(100-val)
                await self.queue.put((priority,{"module":name,"data":delta,"aggregated":self.data,"action":action}))

    async def process_queue(self):
        while True:
            priority,item=await self.queue.get()
            action=item.get("action")
            if asyncio.iscoroutinefunction(action): await action(item)
            else: action(item)
            await asyncio.sleep(self.webhook_interval)
            self.queue.task_done()

    async def send_webhook(self,payload:Dict[str,Any]):
        url=payload["data"].get("webhook_url") or payload["aggregated"].get("modules",{}).get("central",{}).get("webhook_url")
        if not url: return
        retries,delay=3,1
        async with aiohttp.ClientSession() as session:
            for _ in range(retries):
                try:
                    async with session.post(url,json=payload,timeout=5) as resp:
                        if resp.status==200: break
                except: await asyncio.sleep(delay); delay*=2

    async def run_module_periodic(self,module_name:str,condition_key:str,threshold:float=0):
        while True:
            await self.aggregate()
            await self.trigger_all(condition_key,self.send_webhook,threshold)
            await asyncio.sleep(self.get_module_interval(module_name))

async def main():
    files=["webhook_module.json","cpu_control.json","worker_tuning.json"]
    central="central_config.json"
    manager=JSONManager(files,central)
    asyncio.create_task(manager.process_queue())
    for module in files+[central]: asyncio.create_task(manager.run_module_periodic(Path(module).stem,"cpu_usage_percent",80))
    while True: await asyncio.sleep(3600)

if __name__=="__main__": asyncio.run(main())