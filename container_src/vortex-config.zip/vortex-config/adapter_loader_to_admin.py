from typing import Dict, Any, List, Callable
import asyncio, importlib, logging, hashlib, subprocess, json, os, time, tracemalloc, base64, random, resource
from pathlib import Path
from datetime import datetime
from ctypes import cdll

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter(‘%(asctime)s - %(levelname)s - %(message)s’))
logger.addHandler(ch)
tracemalloc.start()

class DistributedInternalToAdminAdapter:
    def __init__(self, internal_service, language=“en”, node=“local”):
        self.s = internal_service
        self.lang = language
        self.node = node
        self.cache: Dict[str, Any] = {}
        self.permissions: Dict[str, List[str]] = {}
        self.events: Dict[str, List[Callable]] = {}
        self.trace_enabled = True
        self.policy = {“allow”: set(), “deny”: set(), “rate_limits”: {}, “signatures”: {}}
        self.metrics: Dict[str, List[float]] = {}

    def check_permission(self, role: str, action: str) -> bool:
        if role in self.permissions and action in self.permissions[role]: return True
        logger.warning(f”[Permission Denied] {role}:{action}”)
        return False

    def _cget(self, key: str, expire: int = 120):
        v = self.cache.get(key)
        if not v: return None
        if time.time() - v[“t”] > expire: del self.cache[key]; return None
        return v[“v”]

    def _cset(self, key: str, value: Any): self.cache[key] = {“v”: value, “t”: time.time()}

    def _format_user(self, u: dict) -> Dict[str, Any]:
        return {“id”: u.get(“id”), “name”: u.get(“full_name”), “email”: u.get(“email”), “role”: u.get(“role”),
                “status”: u.get(“status”,”active”), “last_login”: u.get(“last_login”).isoformat() if u.get(“last_login”) else None}

    def _format_tx(self, t: dict) -> Dict[str, Any]:
        return {“id”: t.get(“id”), “user_id”: t.get(“user_id”), “amount”: float(t.get(“amount”,0)),
                “status”: t.get(“status”,”pending”), “created_at”: t.get(“created_at”).isoformat() if t.get(“created_at”) else None,
                “description”: t.get(“description”,””)}

    async def get_users(self, force=False):
        if not force: c=self._cget(“users”); 
        if c: return c
        d=[self._format_user(x) for x in await asyncio.to_thread(self.s.fetch_all_users)]
        self._cset(“users”,d)
        await self.publish_event(“users_fetched”,{“count”:len(d)})
        return d

    async def get_transactions(self, force=False):
        if not force: c=self._cget(“txs”)
        if c: return c
        d=[self._format_tx(x) for x in await asyncio.to_thread(self.s.fetch_transactions)]
        self._cset(“txs”,d)
        await self.publish_event(“transactions_fetched”,{“count”:len(d)})
        return d

    async def update_user_role(self, user_id:int, role:str, admin_role:str):
        if not self.check_permission(admin_role,”update_user_role”): return False
        try: return await asyncio.to_thread(self.s.set_user_role,user_id,role)
        except Exception as e: logger.error(e); return False

    async def approve_transaction(self, tx_id:int, admin_role:str):
        if not self.check_permission(admin_role,”approve_transaction”): return False
        try: return await asyncio.to_thread(self.s.approve_transaction,tx_id)
        except Exception as e: logger.error(e); return False

    async def get_device_data(self, device_id:str):
        try:
            d = await asyncio.to_thread(self.s.fetch_device_data,device_id)
            await self.publish_event(“device_data_fetched”,{“device_id”:device_id})
            return {“id”:device_id,”status”:d.get(“status”),”last_seen”:d.get(“last_seen”),”metrics”:d.get(“metrics”,{})}
        except Exception as e: logger.error(e); return None

    def encrypt(self,payload:dict)->str: return base64.b64encode(json.dumps(payload).encode()).decode()
    def decrypt(self,payload:str)->dict: return json.loads(base64.b64decode(payload.encode()))

    async def generate_user_report(self):
        users=await self.get_users()
        report={“total_users”:len(users),”active_users”:sum(1 for u in users if u[“status”]==“active”),”roles”:{}}
        for u in users: report[“roles”][u[“role”]] = report[“roles”].get(u[“role”],0)+1
        await self.publish_event(“report_generated”,{“report_type”:”user”})
        return report

    def _log_flow(self,name:str,args,res,start,end,node=None):
        logger.info(f”[FLOW] {name} | node={node or self.node} | dur={(end-start).total_seconds()} | res={str(res)[:150]}”)

    async def publish_event(self,event_type:str,payload:dict):
        for cb in self.events.get(event_type,[]):
            if asyncio.iscoroutinefunction(cb): await cb(payload)
            else: await asyncio.to_thread(cb,payload)

    def on_event(self,event_type:str,callback:Callable): self.events.setdefault(event_type,[]).append(callback)

class LoaderToAdminAdapter:
    def __init__(self, base:str, admin:DistributedInternalToAdminAdapter, node_id=None):
        self.base=Path(base)
        self.admin=admin
        self.lazy:Dict[str,Any]={}
        self.reg:Dict[str,dict]={}
        self.lock=asyncio.Lock()
        self.node=node_id or os.getenv(“NODE_ID”,”local”)
        self.hooks:Dict[str,dict]={}
        self.metrics:Dict[str,List[float}]={}
        self.cache:Dict[str,dict]={}
        self.cache_exp=120
        self.policy={“allow”:set(),”deny”:set(),”rate_limits”:{},”signatures”:{}}
        self.trace_enabled=True
        self.tc:Dict[str,dict]={}
        tracemalloc.start()
        self._register_modules()
        self._assign_priorities()
        self._build_dependency_graph()

    def _hash_file(self,p:Path)->str:
        try: h=hashlib.sha256(); 
        with p.open(“rb”) as f: 
            for c in iter(lambda:f.read(4096),b””): h.update(c)
        return h.hexdigest()
        except: return “0”*64

    def _register_modules(self):
        for p in (self.base/“loader_modules”).glob(“**/*”):
            if p.suffix in [“.py”,”.js”,”.ts”,”.wasm”,”.so”,”.dll”,”.whl”]:
                n=“.”.join(p.relative_to(self.base).with_suffix(“”).parts)
                self.lazy[n]=None
                self.reg[n]={“path”:p,”type”:p.suffix,”loaded”:False,”checksum”:self._hash_file(p),
                             “dependencies”:[],”priority”:0,”version”:None,”healthy”:True}
                self.hooks[n]={“pre”:[],”post”:[]}

    def _assign_priorities(self):
        for n,m in self.reg.items(): m[“priority”]=10 if m[“type”]==“.py” else 6 if m[“type”] in [“.js”,”.ts”] else 4 if m[“type”]==“.wasm” else 2

    def _build_dependency_graph(self):
        for n,m in self.reg.items(): m[“dependencies”]=m.get(“dependencies”,[])

    def _sandbox(self,fn,*a,**k):
        try:
            resource.setrlimit(resource.RLIMIT_CPU,(2,2))
            resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
            return fn(*a,**k)
        except Exception as e: return {“sandbox_error”:str(e)}

    def _policy_check(self,module,func):
        if module in self.policy[“deny”]: raise PermissionError(“denied”)
        if self.policy[“allow”] and module not in self.policy[“allow”]: raise PermissionError(“blocked”)
        rl=self.policy[“rate_limits”].get(module)
        if rl:
            if rl[“count”]>=rl[“max”]: raise RuntimeError(“limit”)
            rl[“count”]+=1

    def _signature_check(self,module):
        sig=self.policy[“signatures”].get(module)
        if sig and self.reg[module][“checksum”]!=sig: raise ValueError(“tampered”)

    def _trace_start(self,module,func):
        if not self.trace_enabled: return None
        tid=str(time.time())+”-“+str(random.randint(1000,9999))
        self.tc[tid]={“module”:module,”func”:func,”start”:datetime.utcnow().isoformat()}
        return tid

    def _trace_end(self,tid,res):
        if tid in self.tc: self.tc[tid].update({“end”:datetime.utcnow().isoformat(),”res”:str(res)[:200]})

    def _cache_get(self,key): 
        v=self.cache.get(key)
        if not v: return None
        if time.time()-v[“t”]>self.cache_exp: del self.cache[key]; return None
        return v[“v”]

    def _cache_set(self,key,val): self.cache[key]={“v”:val,”t”:time.time()}

    def load_module(self,name:str,force=False):
        if name not in self.lazy: raise ValueError(f”Module {name} not registered”)
        m=self.reg[name]; ext=m[“type”]; p=str(m[“path”])
        if self.lazy[name] is None or force:
            try:
                for h in self.hooks[name][“pre”]: h(name)
                for d in m[“dependencies”]: self.load_module(d,force)
                if ext==“.py”: self.lazy[name]=importlib.import_module(name) if not force else importlib.reload(self.lazy[name])
                elif ext in [“.so”,”.dll”]: self.lazy[name]=cdll.LoadLibrary(p)
                elif ext==“.wasm”: import wasmer; self.lazy[name]=wasmer.Instance(p)
                elif ext==“.whl”: subprocess.run([“pip”,”install”,p],check=True); self.lazy[name]=importlib.import_module(name)
                elif ext in [“.js”,”.ts”]: subprocess.run([“node”,p],check=True)
                m[“loaded”]=True; m[“version”]=datetime.utcnow().isoformat()
                self.reg[name][“last_code”]=m[“path”].read_text()
                for h in self.hooks[name][“post”]: h(name)
            except Exception as e: m[“healthy”]=False; logger.error(e)
        return self.lazy[name]

    async def run(self,module,func,*a,timeout=None,retries=0,cache=False,sandbox=True,**k):
        async with self.lock:
            self._policy_check(module,func); self._signature_check(module)
            key=f”{module}:{func}:{a}:{k}”
            if cache: cv=self._cache_get(key); 
            if cache and cv is not None: return cv
            mod=self.load_module(module)
            fn=getattr(mod,func,None)
            if not callable(fn): return None
            start=datetime.utcnow(); att=0; res=None; tid=self._trace_start(module,func)
            runner=self._sandbox if sandbox else lambda f,*x,**y:f(*x,**y)
            while att<=retries:
                try:
                    if asyncio.iscoroutinefunction(fn): res=await asyncio.wait_for(fn(*a,**k),timeout=timeout)
                    else: res=runner(fn,*a,**k)
                    break
                except Exception as e: att+=1; logger.error(e)
                    if att>retries: raise
                finally:
                    self.metrics.setdefault(f”{module}.{func}”,[]).append((datetime.utcnow()-start).total_seconds())
                    self.admin._log_flow(f”loader_{module}_{func}”,{“args”:a,”kwargs”:k},res,start,datetime.utcnow(),node=self.node)
            if cache: self._cache_set(key,res)
            self._trace_end(tid,res)
            return res

    async def batch(self,evs:List[Dict[str,Any]]):
        return await asyncio.gather(*[self.run(e[“module”],e[“func”],*e.get(“args”,[]),**e.get(“kwargs”,{})) for e in evs],return_exceptions=True)
        