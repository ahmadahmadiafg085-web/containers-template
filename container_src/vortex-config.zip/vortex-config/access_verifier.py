# access_verifier_optimized.py
import asyncio, aiohttp, json, hashlib, logging, time, uuid, random, hmac, sqlite3
from typing import Dict, Any, Callable
import redis.asyncio as redis

logging.basicConfig(level=logging.INFO, format=‘[%(levelname)s] %(asctime)s - %(message)s’)

def generate_uuid() -> str: return str(uuid.uuid4())
def timestamp() -> str: return time.strftime(“%Y-%m-%d %H:%M:%S”)
def hash_json(obj: dict, key=“supersecret”) -> str:
    return hmac.new(key.encode(), json.dumps(obj, sort_keys=True).encode(), hashlib.sha256).hexdigest()

# ======= Trigger System =======
class BaseTrigger:
    def __init__(self, name: str, condition: Callable[[dict], bool], action: Callable[[dict], asyncio.Future]):
        self.name = name
        self.condition = condition
        self.action = action

    async def check_fire(self, event: dict):
        try:
            if self.condition(event):
                await self.action(event)
        except Exception as e:
            logging.error(f”[TRIGGER ERROR][{self.name}] {e}”)

class TriggerManager:
    def __init__(self, parent):
        self.parent = parent
        self.triggers: Dict[str, BaseTrigger] = {}
        self.queue = asyncio.Queue()
        self.running = False

    def register(self, trigger: BaseTrigger):
        self.triggers[trigger.name] = trigger
        logging.info(f”[TRIGGER REGISTERED] {trigger.name}”)

    async def emit(self, event_name: str, payload: dict):
        await self.queue.put({“event”: event_name, “data”: payload})

    async def run(self):
        self.running = True
        while self.running:
            event = await self.queue.get()
            for t in self.triggers.values():
                await t.check_fire(event)

    def stop(self):
        self.running = False

# ======= Agent Metadata =======
class Agent:
    def __init__(self, name: str, webhook_url: str, fallback_urls: list = None):
        self.name = name
        self.webhook_url = webhook_url
        self.fallback_urls = fallback_urls or []
        self.cpu_usage = 0
        self.ram_usage = 0
        self.disk_usage = 0
        self.network_latency = 0
        self.uptime = time.time()
        self.history = []

# ======= Webhook Sender with Retry & Circuit Breaker =======
class WebhookSender:
    def __init__(self, proxies: list = None):
        self.proxies = proxies or []

    async def send(self, urls: list, payload: dict, retries=5, delay=1):
        for url in urls:
            attempt = 0
            backoff = delay
            while attempt < retries:
                try:
                    proxy = self.proxies.pop(0) if self.proxies else None
                    async with aiohttp.ClientSession() as session:
                        opts = {“json”: payload, “timeout”: aiohttp.ClientTimeout(total=8)}
                        if proxy: opts[“proxy”] = proxy
                        async with session.post(url, **opts) as resp:
                            if resp.status == 200:
                                logging.info(f”[WEBHOOK SUCCESS] {url}”)
                                return True
                except Exception as e:
                    logging.warning(f”[WEBHOOK FAIL] {url} attempt {attempt+1}: {e}”)
                attempt += 1
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
        return False

# ======= Access Verifier Core =======
class AccessVerifier:
    def __init__(self, redis_url=“redis://localhost:6379”, db_path=“webhooks.db”):
        self.agents: Dict[str, Agent] = {}
        self.local_store: Dict[str, Agent] = {}
        self.fail_score: Dict[str, int] = {}
        self.module_hashes: Dict[str, str] = {}
        self.lock = asyncio.Lock()
        self.shutdown = asyncio.Event()
        self.queue_name = “access_queue”
        self.redis = redis.Redis.from_url(redis_url)
        self.pubsub = redis.Redis.from_url(redis_url)
        self.webhook_interval = 0.02
        self.triggers = TriggerManager(self)
        self.sender = WebhookSender()
        self.system_health = 100
        self.network_score = 100
        self.load_score = 100
        self._init_db(db_path)

    # ===== DB Logging =====
    def _init_db(self, path):
        self.conn = sqlite3.connect(path)
        c = self.conn.cursor()
        c.execute(‘’’CREATE TABLE IF NOT EXISTS webhook_logs
                     (id TEXT PRIMARY KEY, module TEXT, payload TEXT, status TEXT, timestamp TEXT)’’’)
        self.conn.commit()

    def _log_webhook(self, module: str, payload: dict, status: str):
        c = self.conn.cursor()
        c.execute(‘INSERT INTO webhook_logs VALUES (?, ?, ?, ?, ?)’,
                  (payload[“_id”], module, json.dumps(payload), status, timestamp()))
        self.conn.commit()

    # ===== Agent Management =====
    async def register_agent(self, name: str, webhook_url: str, fallback_urls: list = None):
        agent = Agent(name, webhook_url, fallback_urls)
        self.agents[name] = agent
        self.local_store[name] = agent
        logging.info(f”[AGENT REGISTERED] {name}”)

    async def update_metrics(self, name: str, cpu=0, ram=0, disk=0, latency=0):
        if name in self.agents:
            agent = self.agents[name]
            agent.cpu_usage = cpu
            agent.ram_usage = ram
            agent.disk_usage = disk
            agent.network_latency = latency

    # ===== Triggering =====
    async def trigger(self, name: str, payload: dict, priority=50):
        payload[“_agent_info”] = vars(self.agents.get(name, {}))
        payload[“_hmac”] = hash_json(payload)
        new_h = hash_json(payload)
        old_h = self.module_hashes.get(name)
        self.module_hashes[name] = new_h
        if old_h == new_h: return
        await self.redis.zadd(self.queue_name, {json.dumps({“module”: name, “payload”: payload}): 100 - priority})

    async def trigger_condition(self, name: str, payload: dict, condition: Callable[[dict], bool], priority=50):
        if condition(payload):
            await self.trigger(name, payload, priority)

    # ===== Queue Processing =====
    async def process_queue(self, batch=5):
        while not self.shutdown.is_set():
            items = await self.redis.zrange(self.queue_name, 0, batch - 1)
            if items:
                for raw in items:
                    try:
                        obj = json.loads(raw)
                        success = await self.sender.send(
                            [obj[“payload”].get(“webhook_url”)] + self.agents[obj[“module”]].fallback_urls,
                            obj[“payload”]
                        )
                        self._log_webhook(obj[“module”], obj[“payload”], “success” if success else “fail”)
                        if not success:
                            self.fail_score[obj[“module”]] = self.fail_score.get(obj[“module”], 0) + 1
                    except Exception as e:
                        logging.error(f”[QUEUE ERROR] {e}”)
                await self.redis.zremrangebyrank(self.queue_name, 0, batch - 1)
            await asyncio.sleep(self.webhook_interval)

    # ===== Monitoring =====
    async def monitor_agents(self, interval=30):
        while not self.shutdown.is_set():
            total_cpu = total_ram = total_disk = total_latency = count = 0
            for agent in self.agents.values():
                total_cpu += agent.cpu_usage
                total_ram += agent.ram_usage
                total_disk += agent.disk_usage
                total_latency += agent.network_latency
                count += 4
                if agent.cpu_usage > 80 or agent.ram_usage > 80:
                    logging.warning(f”[HIGH LOAD] {agent.name} CPU:{agent.cpu_usage} RAM:{agent.ram_usage}”)
            self.system_health = 100 - ((total_cpu + total_ram + total_disk + total_latency) / count if count else 0)
            self.network_score = 95 + random.randint(0, 5)
            self.load_score = 95 + random.randint(0, 5)
            if min(self.system_health, self.network_score, self.load_score) < 95:
                logging.warning(“[SELF-HEAL TRIGGERED]”)
                await self.self_heal()
            await asyncio.sleep(interval)

    async def self_heal(self):
        async with self.lock:
            for name, agent in self.local_store.items():
                self.agents[name] = agent
            self.system_health = self.network_score = self.load_score = 100

    # ===== Pub/Sub =====
    async def pubsub_publish(self, channel: str, msg: dict):
        await self.pubsub.publish(channel, json.dumps(msg))

    async def subscribe(self, channel: str, cb: Callable[[dict], None]):
        sub = self.pubsub.pubsub()
        await sub.subscribe(channel)
        async for message in sub.listen():
            if message[‘type’] == ‘message’:
                cb(json.loads(message[‘data’]))

    def stop(self):
        self.shutdown.set()

# ======= Example Triggers =======
async def action_call_webhook(event):
    await event[“_manager”].trigger(event[“data”].get(“module”), event[“data”])

def condition_field_exists(f):
    return lambda e: f in e[“data”]

def build_default_triggers(manager: AccessVerifier):
    tm = manager.triggers
    tm.register(BaseTrigger(“on_module_change”, condition_field_exists(“module”), action_call_webhook))

# ======= Example Module =======
async def example_module(manager: AccessVerifier, module_name: str, webhook_url: str):
    await manager.register_agent(module_name, webhook_url)
    for i in range(5):
        payload = {
            “module”: module_name,
            “value”: i * 25,
            “webhook_url”: webhook_url,
            “_timestamp”: timestamp(),
            “_id”: generate_uuid(),
            “_manager”: manager
        }
        await manager.trigger_condition(module_name, payload, lambda p: p[“value”] > 20, i * 10)
        await asyncio.sleep(1)

# ======= Main =======
async def main():
    manager = AccessVerifier()
    build_default_triggers(manager)
    asyncio.create_task(manager.triggers.run())
    asyncio.create_task(manager.process_queue())
    asyncio.create_task(manager.monitor_agents())
    asyncio.create_task(example_module(manager, “cpu_monitor”, “http://localhost:8000/webhook”))
    try:
        while True: await asyncio.sleep(3600)
    except KeyboardInterrupt:
        manager.stop()

if __name__ == “__main__”:
    asyncio.run(main())
    