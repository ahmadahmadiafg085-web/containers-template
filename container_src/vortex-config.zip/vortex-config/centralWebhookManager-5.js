import fetch from ‘node-fetch’;
import Redis from ‘ioredis’;
import crypto from ‘crypto’;
import { v4 as uuidv4 } from ‘uuid’;

class DistributedWebhookManager {
    constructor(redisUrl = ‘redis://localhost’, queueName = ‘webhook_queue’, webhookRateLimit = 50) {
        this.redis = new Redis(redisUrl);
        this.queueName = queueName;
        this.webhookRateLimit = webhookRateLimit;
        this.webhookInterval = 1000 / webhookRateLimit;
        this.moduleHashes = {};
        this.moduleFailScore = {};
        this.moduleAgents = {};
        this.localSecureStore = {};
        this.systemHealth = 100;
        this.networkScore = 100;
        this.loadScore = 100;
        this.shutdown = false;
        this.proxies = []; // لیست VPN یا Proxy
    }

    async registerAgent(moduleName, agentInfo) {
        this.moduleAgents[moduleName] = agentInfo;
        this.localSecureStore[moduleName] = { ...agentInfo };
    }

    hashJson(obj) {
        try {
            return crypto.createHash(‘sha256’).update(JSON.stringify(obj)).digest(‘hex’);
        } catch {
            return Date.now().toString();
        }
    }

    async trigger(moduleName, payload, priority = 50) {
        payload._agent_info = this.moduleAgents[moduleName] || {};
        const newHash = this.hashJson(payload);
        const oldHash = this.moduleHashes[moduleName];
        this.moduleHashes[moduleName] = newHash;
        if (oldHash === newHash) return;
        const item = JSON.stringify({ module: moduleName, payload });
        await this.redis.zadd(this.queueName, 100 - priority, item);
        console.log(`Webhook queued: ${moduleName}, priority: ${100 - priority}`);
    }

    async triggerCondition(moduleName, payload, condition, priority = 50) {
        if (condition(payload)) await this.trigger(moduleName, payload, priority);
    }

    async processQueue(batchSize = 5) {
        while (!this.shutdown) {
            const items = await this.redis.zrange(this.queueName, 0, batchSize - 1);
            if (items.length) {
                await Promise.all(items.map(async i => {
                    const obj = JSON.parse(i);
                    await this.sendWebhook(obj.payload, obj.module);
                }));
                await this.redis.zremrangebyrank(this.queueName, 0, batchSize - 1);
            }
            await new Promise(r => setTimeout(r, this.webhookInterval));
        }
    }

    async sendWebhook(payload, moduleName) {
        const urls = [payload.webhook_url, ...(this.moduleAgents[moduleName]?.fallback_urls || [])].filter(Boolean);
        if (!urls.length) return;

        let retries = 5, delay = 1000;
        const proxies = [...this.proxies];
        for (const url of urls) {
            for (let attempt = 0; attempt < retries; attempt++) {
                try {
                    const proxy = proxies.length ? proxies.shift() : null; // rotation
                    const options = { method: ‘POST’, body: JSON.stringify(payload), headers: { ‘Content-Type’: ‘application/json’ } };
                    if (proxy) options.agent = proxy; // می‌تونی Proxy Agent تنظیم کنی
                    const resp = await fetch(url, options);
                    if (resp.status === 200) { console.log(`Webhook sent: ${moduleName} -> ${url}`); return; }
                    console.warn(`Webhook ${moduleName} error ${resp.status}`);
                } catch (e) {
                    console.error(`Webhook ${moduleName} attempt ${attempt + 1} failed:`, e.message);
                }
                await new Promise(r => setTimeout(r, delay));
                delay = Math.min(delay * 2, 30000);
            }
        }
        this.moduleFailScore[moduleName] = (this.moduleFailScore[moduleName] || 0) + 1;
        console.error(`Webhook FAILED: ${moduleName} -> ${urls}`);
    }

    async monitorAgents(interval = 30000) {
        while (!this.shutdown) {
            let totalCPU = 0, totalRAM = 0, count = 0;
            for (const [module, info] of Object.entries(this.moduleAgents)) {
                const cpu = info.cpu_usage || 0;
                const ram = info.ram_usage || 0;
                totalCPU += cpu; totalRAM += ram; count += 2;
                if (cpu > 80 || ram > 80) console.warn(`High load: ${module} CPU:${cpu}% RAM:${ram}%`);
            }
            this.systemHealth = count ? 100 - (totalCPU + totalRAM) / count : 100;
            this.networkScore = 90 + Math.floor(Math.random() * 10);
            this.loadScore = 90 + Math.floor(Math.random() * 10);
            if (this.systemHealth < 95 || this.networkScore < 95 || this.loadScore < 95) {
                console.warn(`System low: ${this.systemHealth}% network:${this.networkScore}% load:${this.loadScore}%, self-heal`);
                await this.selfHeal();
            }
            await new Promise(r => setTimeout(r, interval));
        }
    }

    async selfHeal() {
        for (const module of Object.keys(this.moduleAgents)) {
            const agent = this.localSecureStore[module];
            if (agent) this.moduleAgents[module] = { ...agent };
        }
        this.systemHealth = this.networkScore = this.loadScore = 100;
        console.info(‘Self-heal complete, system restored’);
    }

    stop() { this.shutdown = true; }
}

// — Example —
async function exampleModule(manager, moduleName, webhookUrl) {
    await manager.registerAgent(moduleName, { webhook_url: webhookUrl, cpu_usage: 0, ram_usage: 0, fallback_urls: [] });
    for (let i = 0; i < 10; i++) {
        const payload = { module: moduleName, value: i * 10, webhook_url: webhookUrl, _timestamp: new Date().toISOString(), _id: uuidv4() };
        await manager.triggerCondition(moduleName, payload, p => p.value > 20, i * 10);
        await new Promise(r => setTimeout(r, 500));
    }
}

async function main() {
    const manager = new DistributedWebhookManager();
    manager.proxies = [‘http://127.0.0.1:8080’, ‘http://127.0.0.1:8081’]; // rotation proxy
    manager.processQueue();
    manager.monitorAgents();
    exampleModule(manager, ‘cpu_monitor’, ‘http://localhost:8000/webhook’);
    exampleModule(manager, ‘memory_monitor’, ‘http://localhost:8000/webhook’);
}

main();
