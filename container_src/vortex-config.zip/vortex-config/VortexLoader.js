// VortexLoader.js
class VortexLoader {
  constructor({ protoRoot, cdnUrls = [], mirrors = [], cache = window.localStorage, maxRetries = 10 }) {
    this.root = protoRoot; // انتظار protoRoot از protobufjs.load یا Root.fromJSON
    this.cdnUrls = cdnUrls;
    this.mirrors = mirrors;
    this.cache = cache;
    this.retryLimit = maxRetries;

    this.language = "default";
    this.state = {};
    this.scenarios = {};
    this.dynamicPayloads = {};
    this.antiDebug = true;
    this.obfuscate = true;

    this.taskQueue = [];
    this.knowledgeBase = {};
    this.workers = {};
    this.agentRegistry = {};
  }

  switchLanguage(lang) { this.language = lang; }
  setScenario(name, config) { this.scenarios[name] = config; }

  cacheKey(path, scenario) { return `cache_${this.language}_${scenario}_${path}`; }
  async getFromCache(path, scenario) {
    try { return JSON.parse(this.cache.getItem(this.cacheKey(path, scenario))); }
    catch { return null; }
  }
  saveToCache(path, scenario, data) {
    this.cache.setItem(this.cacheKey(path, scenario), JSON.stringify(data));
  }

  detectDebugger() {
    if (this.antiDebug && window.outerHeight - window.innerHeight > 100) while (true) {}
  }

  obfuscateCode(code) { return this.obfuscate ? btoa(code) : code; }

  async fetchWithRetry(path, scenario, attempt = 0) {
    let sources = this.scenarios[scenario]?.cdnUrls?.concat(this.scenarios[scenario]?.mirrors || []) 
                  || this.cdnUrls.concat(this.mirrors);
    if (attempt >= this.retryLimit) throw new Error("Max retries reached");
    const source = sources[attempt % sources.length];
    try {
      const res = await fetch(`${source}/${path}`, { cache: "no-store" });
      if (!res.ok) throw new Error("Fetch failed");
      return await res.arrayBuffer();
    } catch {
      await new Promise(r => setTimeout(r, 200 * attempt));
      return this.fetchWithRetry(path, scenario, attempt + 1);
    }
  }

  decode(buf, msgType) {
    const type = this.root.lookupType(msgType);
    const decoded = type.decode(new Uint8Array(buf));
    return type.toObject(decoded, { longs: String, enums: String, defaults: true });
  }

  generateDynamicPayload(scenario) {
    if (!this.dynamicPayloads[scenario]) this.dynamicPayloads[scenario] = { time: Date.now(), rand: Math.random() };
    return this.dynamicPayloads[scenario];
  }

  async load(path, msgType, scenario = "default") {
    this.detectDebugger();
    this.state.currentScenario = scenario;
    const cached = await this.getFromCache(path, scenario);
    if (cached) return cached;
    const buf = await this.fetchWithRetry(path, scenario);
    const data = this.decode(buf, msgType);
    this.saveToCache(path, scenario, data);
    return data;
  }

  scheduleTask(task) {
    this.taskQueue.push(task);
    if (task.delay) setTimeout(() => task.execute(), task.delay);
    else task.execute();
  }

  registerWorker(name, fn) { this.workers[name] = fn; }
  async executeWorker(name, ...args) {
    if (!this.workers[name]) throw new Error("Worker not found");
    return await this.workers[name](...args);
  }

  registerAgent(name, agent) { this.agentRegistry[name] = agent; }
  async dispatchTask(task) {
    const agent = this.agentRegistry[task.agent];
    if (!agent) throw new Error("Agent not registered");
    if (!agent.capabilities.includes(task.capability)) throw new Error("Agent lacks capability");
    await (task.queue && agent.queue ? agent.enqueue(task) : agent.execute(task));
  }

  reflectCapabilities() { return Object.keys(this.scenarios); }

  // پایه برای send/receive ساده
  async communicate(protocol, message, binary = false) {
    if (binary) return btoa(message);
    else return `Message sent via ${protocol}`;
  }
}

export default VortexLoader;