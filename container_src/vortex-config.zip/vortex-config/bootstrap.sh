#!/bin/bash
# ===========================
# UNIVERSAL MULTI-LANG MASTER BOOTSTRAP SCRIPT
# Compatible with Master Multi-Lang Dockerfile
# Handles 40+ Languages, Logging, Audit, Recovery, Watch Mode, Self-Upgrade
# ===========================

LOG_FILE="/app/logs/bootstrap.log"
READY_FILE="/app/.ready"
MANIFEST_FILE="/app/langs.json"
AUDIT_FILE="/app/audit.json"
ACTIVE_ENV_FILE="/app/.env"

mkdir -p /app/logs
echo "========== BOOTSTRAP STARTED ==========" | tee -a $LOG_FILE
date | tee -a $LOG_FILE
echo "Working directory: $(pwd)" | tee -a $LOG_FILE

# ---------------------------
# 1. Load ENV variables
# ---------------------------
if [ -f "$ACTIVE_ENV_FILE" ]; then
    echo "Loading environment variables..." | tee -a $LOG_FILE
    source "$ACTIVE_ENV_FILE"
fi

# ---------------------------
# 2. Audit & Manifest Recovery
# ---------------------------
[ ! -f "$AUDIT_FILE" ] && echo "{}" > "$AUDIT_FILE"
[ ! -f "$MANIFEST_FILE" ] && echo "{ \"langs\": \"$LANGS\" }" > "$MANIFEST_FILE"

# ---------------------------
# 3. Auto-Detect Active Language
# ---------------------------
ACTIVE_LANG=""
for lang in $LANGS; do
    case $lang in
        python) [ -f requirements.txt ] && ACTIVE_LANG=python ;;
        nodejs) [ -f package.json ] && ACTIVE_LANG=nodejs ;;
        go) [ -f main.go ] && ACTIVE_LANG=go ;;
        php) [ -f composer.json ] && ACTIVE_LANG=php ;;
        rust) [ -f Cargo.toml ] && ACTIVE_LANG=rust ;;
        ruby) [ -f Gemfile ] && ACTIVE_LANG=ruby ;;
    esac
    [ ! -z "$ACTIVE_LANG" ] && break
done
# fallback to ENV
[ -z "$ACTIVE_LANG" ] && ACTIVE_LANG=$(grep LANG_ACTIVE $ACTIVE_ENV_FILE | cut -d'=' -f2)
echo "Detected project language: $ACTIVE_LANG" | tee -a $LOG_FILE

# ---------------------------
# 4. Language-specific setup
# ---------------------------
setup_language() {
    lang=$1
    echo "Setting up $lang environment..." | tee -a $LOG_FILE
    case $lang in
        python)
            [ -f requirements.txt ] && pip3 install --no-cache-dir -r requirements.txt
            ;;
        nodejs)
            [ -f package.json ] && npm install --legacy-peer-deps
            ;;
        go)
            [ -f go.mod ] && go mod tidy
            ;;
        php)
            [ -f composer.json ] && composer install || true
            ;;
        rust)
            [ -f Cargo.toml ] && cargo update
            ;;
        ruby)
            [ -f Gemfile ] && gem install bundler >/dev/null 2>&1 && bundle install
            ;;
        *)
            echo "No direct setup found for $lang; using generic fallback." | tee -a $LOG_FILE
            ;;
    esac
}
setup_language "$ACTIVE_LANG"

# ---------------------------
# 5. Multi-language loop fallback
# ---------------------------
echo "=== Checking all LANGS fallback ===" | tee -a $LOG_FILE
for lang in $LANGS; do
    echo "Checking $lang..." | tee -a $LOG_FILE
    case $lang in
        python) pip3 --version >/dev/null 2>&1 || echo "Python not found, skipped" ;;
        nodejs) node -v >/dev/null 2>&1 || echo "Node.js not found, skipped" ;;
        ruby) ruby -v >/dev/null 2>&1 || echo "Ruby not found, skipped" ;;
        go) go version >/dev/null 2>&1 || echo "Go not found, skipped" ;;
        php) php -v >/dev/null 2>&1 || echo "PHP not found, skipped" ;;
        rust) cargo --version >/dev/null 2>&1 || echo "Rust not found, skipped" ;;
        *) echo "$lang generic fallback check" ;;
    esac
done

# ---------------------------
# 6. Git Sync
# ---------------------------
if command -v git-sync >/dev/null 2>&1; then
    echo "Running git-sync..." | tee -a $LOG_FILE
    git-sync
fi

# ---------------------------
# 7. CI/CD
# ---------------------------
if [ "$CI_MODE" = "true" ]; then
    echo "CI/CD mode active" | tee -a $LOG_FILE
    echo "{\"ci_run\":\"$(date)\"}" >> "$AUDIT_FILE"
fi

# ---------------------------
# 8. Watch Mode
# ---------------------------
if grep -q "ENABLE_WATCH_MODE=true" "$ACTIVE_ENV_FILE"; then
    echo "Watch mode enabled..." | tee -a $LOG_FILE
    inotifywait -mr /app -e modify -e create -e delete --format '%w%f' |
    while read change; do
        echo "Change detected: $change" | tee -a $LOG_FILE
        /usr/local/bin/self-upgrade || echo "Upgrade skipped"
    done
fi &

# ---------------------------
# 9. Security Scan Simulation
# ---------------------------
echo "Simulating security scan..." | tee -a $LOG_FILE
echo "{ \"scan\": \"passed\" }" >> "$AUDIT_FILE"

# ---------------------------
# 10. Finalization
# ---------------------------
echo "Bootstrap complete for $ACTIVE_LANG" | tee -a $LOG_FILE
touch "$READY_FILE"
echo "Container ready marker created at $READY_FILE" | tee -a $LOG_FILE

# ---------------------------
# 11. Optional Runtime Execution
# ---------------------------
if [ -f "run.sh" ]; then
    echo "Executing run.sh..." | tee -a $LOG_FILE
    bash run.sh
else
    echo "No runtime script found; container ready." | tee -a $LOG_FILE
fi

echo "========== BOOTSTRAP FINISHED ==========" | tee -a $LOG_FILE

#!/bin/bash
# =============================================================
# 🌐 VortexHub Universal Multi-Language Bootstrap & CI/CD
# Author: Dr. S. M. H. Sadat / VortexHub Labs
# Purpose: GH007-proof, multi-language, watch-enabled mini-cloud
# =============================================================

LOG_FILE="/app/logs/bootstrap.log"
READY_FILE="/app/.ready"
MANIFEST_FILE="/app/langs.json"
AUDIT_FILE="/app/audit.json"
ACTIVE_ENV_FILE="/app/.env"

mkdir -p /app/logs
echo "========== BOOTSTRAP STARTED ==========" | tee -a $LOG_FILE
date | tee -a $LOG_FILE

# ENV load
if [ -f "$ACTIVE_ENV_FILE" ]; then source "$ACTIVE_ENV_FILE"; fi

# Initialize manifest and audit
[ ! -f "$AUDIT_FILE" ] && echo "{}" > "$AUDIT_FILE"
[ ! -f "$MANIFEST_FILE" ] && echo "{ \"langs\": \"$LANGS\" }" > "$MANIFEST_FILE"

# Git identity (prevent GH007)
git config user.email "${GIT_NOREPLY_EMAIL}"
git config user.name "Dr. S. M. H. Sadat"

# Detect primary active language
ACTIVE_LANG=""
for lang in $LANGS; do
  case $lang in
    python) [ -f requirements.txt ] && ACTIVE_LANG=python ;;
    nodejs) [ -f package.json ] && ACTIVE_LANG=nodejs ;;
    rust) [ -f Cargo.toml ] && ACTIVE_LANG=rust ;;
    fsharp) ls *.fs >/dev/null 2>&1 && ACTIVE_LANG=fsharp ;;
    lisp) ls *.lisp >/dev/null 2>&1 && ACTIVE_LANG=lisp ;;
  esac
  [ ! -z "$ACTIVE_LANG" ] && break
done

echo "Detected language: ${ACTIVE_LANG:-none}" | tee -a $LOG_FILE

# Language-specific setup
setup_language() {
  case $1 in
    python) pip3 install --no-cache-dir -r requirements.txt 2>/dev/null || true ;;
    nodejs) npm install --legacy-peer-deps 2>/dev/null || true ;;
    rust) cargo update 2>/dev/null || true ;;
    fsharp) for f in *.fs; do [ -f "$f" ] && fsharpi "$f"; done ;;
    lisp) for l in *.lisp; do [ -f "$l" ] && sbcl --noinform --eval "(load \"$l\")" --eval '(quit)'; done ;;
  esac
}
setup_language "$ACTIVE_LANG"

# Fallback log for language presence
for lang in $LANGS; do
  command -v $lang >/dev/null 2>&1 || echo "$lang not found" | tee -a $LOG_FILE
done

# Git sync automation
git fetch origin main || true
git add . || true
git commit -m "Auto-fetch update [skip ci]" || true
git push origin main || true

# Telemetry emission
if [ "$CI_MODE" = "true" ]; then
  echo "{\"timestamp\":\"$(date)\",\"project\":\"$PROJECT_NAME\"}" > /tmp/deploy_log.json
  curl -s -X POST -H "Content-Type: application/json" -d @/tmp/deploy_log.json $TELEMETRY_URL || echo "Telemetry failed" | tee -a $LOG_FILE
fi

# Watch mode for runtime updates
if [ "$ENABLE_WATCH_MODE" = "true" ]; then
  echo "File watch active..." | tee -a $LOG_FILE
  apt-get update -y && apt-get install -y inotify-tools 2>/dev/null || true
  inotifywait -mr /app -e modify,create,delete --format '%w%f' |
  while read change; do
    echo "Change detected: $change" | tee -a $LOG_FILE
    /usr/local/bin/self-upgrade || echo "Upgrade skipped"
  done &
fi

# Finalization
touch "$READY_FILE"
echo "Ready marker created at $READY_FILE" | tee -a $LOG_FILE
echo "========== BOOTSTRAP FINISHED ==========" | tee -a $LOG_FILE

