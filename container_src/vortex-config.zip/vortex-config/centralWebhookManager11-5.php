<?php
require ‘vendor/autoload.php’;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class WebhookManager {
    private static ?WebhookManager $instance = null;
    private SplPriorityQueue $queue;
    private float $webhookRateLimit = 50;
    private float $webhookInterval;
    private array $moduleHashes = [];
    private array $moduleFailScore = [];
    private array $moduleAgents = [];
    private array $localSecureStore = [];
    private float $systemHealth = 100;
    private float $networkScore = 100;
    private float $loadScore = 100;
    private bool $shutdown = false;
    public array $proxies = [];

    private function __construct() {
        $this->queue = new SplPriorityQueue();
        $this->webhookInterval = 1 / $this->webhookRateLimit;
    }

    public static function getInstance(): WebhookManager {
        return self::$instance ??= new WebhookManager();
    }

    public function registerAgent(string $module, array $info): void {
        $this->moduleAgents[$module] = $info;
        $this->localSecureStore[$module] = $info;
    }

    private function hashPayload(array $payload): string {
        return hash(‘sha256’, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function trigger(string $module, array $payload, int $priority = 50): void {
        $payload[‘_agent_info’] = $this->moduleAgents[$module] ?? [];
        $newHash = $this->hashPayload($payload);
        $oldHash = $this->moduleHashes[$module] ?? null;
        $this->moduleHashes[$module] = $newHash;
        if ($oldHash === $newHash) return;

        $this->queue->insert([‘module’ => $module, ‘payload’ => $payload], 100 - $priority);
    }

    public function triggerCondition(string $module, array $payload, callable $condition, int $priority = 50): void {
        if ($condition($payload)) $this->trigger($module, $payload, $priority);
    }

    public function processQueue(): void {
        $client = new Client([‘timeout’ => 8.0]);
        while (!$this->shutdown) {
            if (!$this->queue->isEmpty()) {
                $item = $this->queue->extract();
                $this->sendWebhook($client, $item[‘payload’], $item[‘module’]);
            }
            usleep((int)($this->webhookInterval * 1_000_000));
        }
    }

    private function sendWebhook(Client $client, array $payload, string $module): void {
        $urls = [];
        if (!empty($payload[‘webhook_url’])) $urls[] = $payload[‘webhook_url’];
        if (!empty($this->moduleAgents[$module][‘fallback_urls’])) $urls = array_merge($urls, $this->moduleAgents[$module][‘fallback_urls’]);
        if (empty($urls)) return;

        shuffle($urls);
        $retries = 5;
        $delay = 1;

        foreach ($urls as $url) {
            for ($attempt = 0; $attempt < $retries; $attempt++) {
                try {
                    $options = [‘json’ => $payload];
                    if (!empty($this->proxies)) $options[‘proxy’] = $this->proxies[array_rand($this->proxies)];
                    $response = $client->post($url, $options);
                    if ($response->getStatusCode() === 200) return;
                } catch (RequestException $e) {}
                sleep($delay);
                $delay = min($delay * 2, 30);
            }
        }

        $this->moduleFailScore[$module] = ($this->moduleFailScore[$module] ?? 0) + 1;
    }

    public function monitorAgents(int $interval = 30): void {
        while (!$this->shutdown) {
            $totalCPU = $totalRAM = $count = 0;
            foreach ($this->moduleAgents as $module => $info) {
                $cpu = $info[‘cpu_usage’] ?? 0;
                $ram = $info[‘ram_usage’] ?? 0;
                $totalCPU += $cpu;
                $totalRAM += $ram;
                $count += 2;
            }
            $this->systemHealth = $count ? 100 - ($totalCPU + $totalRAM) / $count : 100;
            $this->networkScore = rand(90, 100);
            $this->loadScore = rand(90, 100);

            if ($this->systemHealth < 95 || $this->networkScore < 95 || $this->loadScore < 95) $this->selfHeal();
            sleep($interval);
        }
    }

    private function selfHeal(): void {
        foreach ($this->moduleAgents as $module => $info)
            if (!empty($this->localSecureStore[$module])) $this->moduleAgents[$module] = $this->localSecureStore[$module];
        $this->systemHealth = $this->networkScore = $this->loadScore = 100;
    }

    public function stop(): void { $this->shutdown = true; }
}

// — Example —
function exampleModule(WebhookManager $mgr, string $module, string $url): void {
    $mgr->registerAgent($module, [‘webhook_url’ => $url, ‘cpu_usage’ => 0, ‘ram_usage’ => 0, ‘fallback_urls’ => []]);
    for ($i = 0; $i < 10; $i++) {
        $payload = [‘module’ => $module, ‘value’ => $i * 10, ‘webhook_url’ => $url, ‘_timestamp’ => date(‘c’), ‘_id’ => uniqid()];
        $mgr->triggerCondition($module, $payload, fn($p) => $p[‘value’] > 20, $i * 10);
        usleep(500_000);
    }
}

// — Main —
$mgr = WebhookManager::getInstance();
$mgr->proxies = [‘http://127.0.0.1:8080’, ‘http://127.0.0.1:8081’];

// Multi-process execution (CLI)
pcntl_fork() && exit; $mgr->processQueue();
pcntl_fork() && exit; $mgr->monitorAgents();
exampleModule($mgr, ‘cpu_monitor’, ‘http://localhost:8000/webhook’);
exampleModule($mgr, ‘memory_monitor’, ‘http://localhost:8000/webhook’);