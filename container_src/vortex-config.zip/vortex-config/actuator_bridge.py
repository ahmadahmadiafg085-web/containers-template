# ops_orchestrator.py
import asyncio, aiohttp, json, logging, time, uuid, random, sqlite3, hmac, hashlib
from typing import Dict, Any, Callable, List
import redis.asyncio as redis

logging.basicConfig(level=logging.INFO, format=‘[%(levelname)s] %(asctime)s - %(message)s’)

def generate_uuid() -> str: return str(uuid.uuid4())
def timestamp() -> str: return time.strftime(“%Y-%m-%d %H:%M:%S”)
def hash_json(obj: dict, key=“supersecret”) -> str:
    return hmac.new(key.encode(), json.dumps(obj, sort_keys=True).encode(), hashlib.sha256).hexdigest()

# ======= Base Trigger System =======
class BaseTrigger:
    def __init__(self, name: str, condition: Callable[[dict], bool], action: Callable[[dict], asyncio.Future]):
        self.name = name
        self.condition = condition
        self.action = action

    async def check_fire(self, event: dict):
        try:
            if self.condition(event):
                await self.action(event)
        except Exception as e:
            logging.error(f”[TRIGGER ERROR][{self.name}] {e}”)

class TriggerManager:
    def __init__(self, parent):
        self.parent = parent
        self.triggers: Dict[str, BaseTrigger] = {}
        self.queue = asyncio.Queue()
        self.running = False

    def register(self, trigger: BaseTrigger):
        self.triggers[trigger.name] = trigger
        logging.info(f”[TRIGGER REGISTERED] {trigger.name}”)

    async def emit(self, event_name: str, payload: dict):
        await self.queue.put({“event”: event_name, “data”: payload})

    async def run(self):
        self.running = True
        while self.running:
            event = await self.queue.get()
            for t in self.triggers.values():
                await t.check_fire(event)

    def stop(self):
        self.running = False

# ======= Webhook Sender with Retry =======
class WebhookSender:
    def __init__(self, proxies: List[str] = None):
        self.proxies = proxies or []

    async def send(self, urls: List[str], payload: dict, retries=5, delay=1):
        for url in urls:
            attempt = 0
            backoff = delay
            while attempt < retries:
                try:
                    proxy = self.proxies.pop(0) if self.proxies else None
                    async with aiohttp.ClientSession() as session:
                        opts = {“json”: payload, “timeout”: aiohttp.ClientTimeout(total=8)}
                        if proxy: opts[“proxy”] = proxy
                        async with session.post(url, **opts) as resp:
                            if resp.status == 200:
                                logging.info(f”[WEBHOOK SUCCESS] {url}”)
                                return True
                except Exception as e:
                    logging.warning(f”[WEBHOOK FAIL] {url} attempt {attempt+1}: {e}”)
                attempt += 1
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
        return False

# ======= Core Orchestrator =======
class OPSOrchestrator:
    def __init__(self, redis_url=“redis://localhost:6379”, db_path=“ops_orchestrator.db”):
        self.lock = asyncio.Lock()
        self.shutdown = asyncio.Event()
        self.redis = redis.Redis.from_url(redis_url)
        self.pubsub = redis.Redis.from_url(redis_url)
        self.webhook_sender = WebhookSender()
        self.triggers = TriggerManager(self)
        self.fail_score: Dict[str, int] = {}
        self.webhook_interval = 0.02

        # Queues
        self.access_queue = “access_queue”
        self.activity_queue = “activity_queue”
        self.actuator_queue = “actuator_queue”

        # Stores
        self.agents: Dict[str, dict] = {}
        self.actuators: Dict[str, dict] = {}

        # DB
        self._init_db(db_path)

    # ======= DB Init =======
    def _init_db(self, path):
        self.conn = sqlite3.connect(path)
        c = self.conn.cursor()
        # AccessVerifier logs
        c.execute(‘’’CREATE TABLE IF NOT EXISTS access_logs
                     (id TEXT PRIMARY KEY, module TEXT, payload TEXT, status TEXT, timestamp TEXT)’’’)
        # ActivityLogger logs
        c.execute(‘’’CREATE TABLE IF NOT EXISTS activity_logs
                     (id TEXT PRIMARY KEY, source TEXT, event TEXT, payload TEXT, status TEXT, timestamp TEXT)’’’)
        # ActuatorBridge logs
        c.execute(‘’’CREATE TABLE IF NOT EXISTS actuator_logs
                     (id TEXT PRIMARY KEY, actuator TEXT, command TEXT, payload TEXT, status TEXT, timestamp TEXT)’’’)
        self.conn.commit()

    def _log_db(self, table: str, record: dict):
        c = self.conn.cursor()
        if table == “access_logs”:
            c.execute(‘INSERT INTO access_logs VALUES (?, ?, ?, ?, ?)’,
                      (record[“_id”], record.get(“module”), json.dumps(record.get(“payload”)), record.get(“status”), record[“_timestamp”]))
        elif table == “activity_logs”:
            c.execute(‘INSERT INTO activity_logs VALUES (?, ?, ?, ?, ?, ?)’,
                      (record[“_id”], record.get(“source”), record.get(“event”), json.dumps(record.get(“payload”)), record.get(“status”), record[“_timestamp”]))
        elif table == “actuator_logs”:
            c.execute(‘INSERT INTO actuator_logs VALUES (?, ?, ?, ?, ?, ?)’,
                      (record[“_id”], record.get(“actuator”), record.get(“command”), json.dumps(record.get(“payload”)), record.get(“status”), record[“_timestamp”]))
        self.conn.commit()

    # ======= Agent & Actuator Management =======
    async def register_agent(self, name: str, webhook_url: str, fallback_urls: List[str] = None):
        self.agents[name] = {“webhook_url”: webhook_url, “fallback_urls”: fallback_urls or [], “cpu_usage”:0, “ram_usage”:0}
        logging.info(f”[AGENT REGISTERED] {name}”)

    async def register_actuator(self, name: str, control_urls: List[str]):
        self.actuators[name] = {“control_urls”: control_urls, “status”: “idle”}
        logging.info(f”[ACTUATOR REGISTERED] {name}”)

    # ======= Queue Push Methods =======
    async def push_access_event(self, module: str, payload: dict, priority=50):
        payload[“_id”] = generate_uuid()
        payload[“_timestamp”] = timestamp()
        await self.redis.zadd(self.access_queue, {json.dumps({“module”: module, “payload”: payload}): 100 - priority})

    async def push_activity_event(self, source: str, event: str, payload: dict, webhook_urls: List[str] = None, priority=50):
        payload[“_id”] = generate_uuid()
        payload[“_timestamp”] = timestamp()
        payload[“_source”] = source
        await self.redis.zadd(self.activity_queue, {json.dumps({“source”: source, “event”: event, “payload”: payload, “webhooks”: webhook_urls or []}): 100 - priority})

    async def push_actuator_command(self, actuator: str, command: str, payload: dict, priority=50):
        payload[“_id”] = generate_uuid()
        payload[“_timestamp”] = timestamp()
        payload[“_command”] = command
        payload[“_actuator”] = actuator
        urls = self.actuators.get(actuator, {}).get(“control_urls”, [])
        await self.redis.zadd(self.actuator_queue, {json.dumps({“actuator”: actuator, “command”: command, “payload”: payload, “urls”: urls}): 100 - priority})

    # ======= Queue Processors =======
    async def process_queue(self, queue_name: str, table_name: str, batch=5):
        while not self.shutdown.is_set():
            items = await self.redis.zrange(queue_name, 0, batch - 1)
            if items:
                for raw in items:
                    try:
                        obj = json.loads(raw)
                        urls = obj.get(“urls”) or obj.get(“payload”, {}).get(“webhook_url”) or []
                        if isinstance(urls, str): urls = [urls]
                        success = await self.webhook_sender.send(urls, obj.get(“payload”, obj))
                        obj[“status”] = “success” if success else “fail”
                        self._log_db(table_name, obj.get(“payload”, obj))
                        if not success:
                            key = obj.get(“module”) or obj.get(“source”) or obj.get(“actuator”)
                            self.fail_score[key] = self.fail_score.get(key, 0) + 1
                    except Exception as e:
                        logging.error(f”[QUEUE ERROR] {e}”)
                await self.redis.zremrangebyrank(queue_name, 0, batch - 1)
            await asyncio.sleep(self.webhook_interval)

    # ======= Self-Healing =======
    async def self_heal(self):
        async with self.lock:
            logging.info(“[SELF-HEAL] Resetting fail scores”)
            self.fail_score = {}

    # ======= Pub/Sub =======
    async def pubsub_publish(self, channel: str, msg: dict):
        await self.pubsub.publish(channel, json.dumps(msg))

    async def subscribe(self, channel: str, cb: Callable[[dict], None]):
        sub = self.pubsub.pubsub()
        await sub.subscribe(channel)
        async for message in sub.listen():
            if message[‘type’] == ‘message’:
                cb(json.loads(message[‘data’]))

    def stop(self):
        self.shutdown.set()

# ======= Default Triggers Example =======
async def trigger_log_event(event):
    logging.info(f”[TRIGGER LOG] Event: {event}”)

def build_default_triggers(orchestrator: OPSOrchestrator):
    orchestrator.triggers.register(BaseTrigger(“log_all_events”, lambda e: True, trigger_log_event))

# ======= Example Usage =======
async def example_usage(orchestrator: OPSOrchestrator):
    await orchestrator.register_agent(“cpu_monitor”, “http://localhost:8000/webhook”)
    await orchestrator.register_actuator(“valve_1”, [“http://localhost:8000/actuator”])
    # Access events
    for i in range(3):
        await orchestrator.push_access_event(“cpu_monitor”, {“value”: i*25})
        await orchestrator.push_activity_event(“example_module”, f”test_event_{i}”, {“param”: i*10}, [“http://localhost:8000/webhook”])
        await orchestrator.push_actuator_command(“valve_1”, f”open_valve_{i}”, {“mode”:”auto”,”param”:i*5})
        await asyncio.sleep(1)

# ======= Main =======
async def main():
    orchestrator = OPSOrchestrator()
    build_default_triggers(orchestrator)
    asyncio.create_task(orchestrator.triggers.run())
    asyncio.create_task(orchestrator.process_queue(orchestrator.access_queue, “access_logs”))
    asyncio.create_task(orchestrator.process_queue(orchestrator.activity_queue, “activity_logs”))
    asyncio.create_task(orchestrator.process_queue(orchestrator.actuator_queue, “actuator_logs”))
    asyncio.create_task(example_usage(orchestrator))
    try:
        while True: await asyncio.sleep(3600)
    except KeyboardInterrupt:
        orchestrator.stop()

if __name__ == “__main__”:
    asyncio.run(main())