import fnmatch, json
from datetime import datetime

# ---------------- POLICIES ----------------
POLICIES = [
    {"user":"guest","action":"read","resource":"*.txt"},
    {"user":"admin","action":"*","resource":"*"}
]

# ---------------- LOG BUFFER ----------------
LOGS = []

# ---------------- HELPERS ----------------
def now_iso(): return datetime.now().isoformat()
def log_access(user, action, resource):
    entry={"timestamp":now_iso(),"user":user,"action":action,"resource":resource}
    LOGS.append(entry)
    print(f"[POLICY LOG] {user} {action} {resource} at {entry['timestamp']}")

# ---------------- POLICY CHECK ----------------
def check_policy(user, action, resource):
    for p in POLICIES:
        if (p["user"]==user or p["user"]=="*") and (p["action"]==action or p["action"]=="*"):
            if fnmatch.fnmatch(resource,p["resource"]): return True
    return False

# ---------------- ENFORCE ----------------
def enforce_policy(user, action, resource, callback=None):
    if check_policy(user, action, resource):
        if callback: callback()
        log_access(user, action, resource)
        return True
    print(f"[ACCESS DENIED] {user} cannot {action} {resource}")
    return False

# ---------------- EXPORT LOGS ----------------
def export_logs(path="policy_logs.json"):
    with open(path,"w") as f: json.dump(LOGS,f,indent=2)
    print(f"[INFO] Logs exported → {path}")

# ---------------- EXAMPLES / USAGE ----------------
if __name__=="__main__":
    # اجرای دستوری اگر policy اجازه دهد
    enforce_policy("guest","read","file1.txt", lambda: print("File read executed"))
    enforce_policy("guest","write","file1.txt", lambda: print("This won't run"))
    enforce_policy("admin","delete","file1.txt", lambda: print("Admin deleted file"))
    export_logs()
    